"""Independent all-pair utility comparison at every rational crossing/interval."""
from pathlib import Path
from fractions import Fraction
import csv,json
H=Path(__file__).resolve().parent
p=list(csv.DictReader((H/'results/decision_points.csv').open()))
for x in p:x['C']=int(x['C']);x['L']=int(x['L'])
intervals=json.loads((H/'results/utility_envelope.json').read_text());cases=0
def winners(t):
    v=[Fraction(x['C'])-t*x['L'] for x in p];best=max(v)
    return sorted(x['policy'] for x,z in zip(p,v) if z==best)
for interval in intervals:
    lo=Fraction(interval['lambda_from']);hi=Fraction(interval['lambda_to']) if interval['lambda_to'] else None
    for t in [lo+Fraction(1,1000000),(lo+hi)/2 if hi else lo+1000000]:assert winners(t)==interval['policies'];cases+=1
for a,b in zip(intervals,intervals[1:]):
    t=Fraction(a['lambda_to']);assert t==Fraction(b['lambda_from']);assert set(a['policies']+b['policies'])<=set(winners(t));cases+=1
o=dict(status='PASS',exact_fraction_cases=cases,intervals=len(intervals),no_superpopulation_or_preference_estimation=True)
(H/'checks/decision_verification.json').write_text(json.dumps(o,indent=2)+'\n');print(o)
