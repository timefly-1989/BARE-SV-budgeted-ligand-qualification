"""Independent minimax recursion over every returned-label branch.

The recursive oracle does not call reserve() to decide feasibility. Labels of
unqueried candidates are adversarial unrestricted binary completions.
"""
from pathlib import Path
from functools import lru_cache
from itertools import product,combinations
import json,time
from certificate import reserve
H=Path(__file__).resolve().parent
def main():
    began=time.perf_counter();states=actions=batches=0;roots=[]
    for group in [(0,0,1,1),(0,0,0,1,1,1),(0,0,1,1,2,2)]:
        n=len(group);m=max(group)+1
        for costs in [tuple([1]*n),tuple(1+i%3 for i in range(n)),tuple(1+(3*i+1)%4 for i in range(n))]:
            for quota in range(1,max(group.count(j) for j in range(m))+1):
                base=tuple(i for j in range(m) for i in [k for k in range(n) if group[k]==j][:quota])
                K=sum(costs[i] for i in base)
                for ell in range(m+1):
                    def unresolved(state):
                        hits={group[i] for i,s in enumerate(state) if s==1}
                        return tuple(tuple(i for i in base if group[i]==j and state[i]<0) for j in range(m) if j not in hits)
                    @lru_cache(None)
                    def can(state,r):
                        # Terminal condition is a direct binary-completion count.
                        if sum(bool(o) for o in unresolved(state))<=ell:return True
                        for i,s in enumerate(state):
                            if s>=0 or costs[i]>r:continue
                            children=[state[:i]+(y,)+state[i+1:] for y in (0,1)]
                            if all(can(t,r-costs[i]) for t in children):return True
                        return False
                    for state in product((-1,0,1),repeat=n):
                        O=unresolved(state);v=[sum(costs[i] for i in o) for o in O];F=reserve(v,ell)
                        for r in sorted(set([0, max(0,F-1),F,min(K,F+1),K])):
                            if r>K:continue
                            exact=can(state,r);assert exact==(F<=r),(group,costs,base,ell,state,r,F)
                            states+=1
                            if not exact:continue
                            for i,s in enumerate(state):
                                if s>=0:continue
                                neg=state[:i]+(0,)+state[i+1:]
                                F0=reserve([sum(costs[k] for k in o) for o in unresolved(neg)],ell)
                                pred=costs[i]+F0<=r
                                truth=costs[i]<=r and all(can(state[:i]+(y,)+state[i+1:],r-costs[i]) for y in (0,1))
                                assert pred==truth;actions+=1
                            # Full committed-batch outcome enumeration at root
                            # and at selected one-query histories.
                            if sum(s>=0 for s in state)<=1 and r in (F,K):
                                active=[i for i,s in enumerate(state) if s<0]
                                for size in range(len(active)+1):
                                    for A in combinations(active,size):
                                        c=sum(costs[i] for i in A);neg=list(state)
                                        for i in A:neg[i]=0
                                        F0=reserve([sum(costs[k] for k in o) for o in unresolved(neg)],ell)
                                        pred=c+F0<=r;truth=c<=r
                                        if truth:
                                            for labels in product((0,1),repeat=len(A)):
                                                nxt=list(state)
                                                for i,y in zip(A,labels):nxt[i]=y
                                                if not can(tuple(nxt),r-c):truth=False;break
                                        assert pred==truth;batches+=1
                    roots.append(dict(group=group,costs=costs,quota=quota,loss_cap=ell,budget=K))
    out=dict(status='PASS',feasibility_cases=states,action_cases=actions,batch_cases=batches,configurations=len(roots),oracle='Independent full binary-branch minimax recursion, optional stopping, no reserve formula in oracle',seconds=time.perf_counter()-began)
    (H/'checks/theory_verification.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
if __name__=='__main__':main()
