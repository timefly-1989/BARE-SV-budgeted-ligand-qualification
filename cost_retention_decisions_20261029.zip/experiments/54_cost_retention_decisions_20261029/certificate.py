"""Exact bounded-loss certificate with positive, known deterministic costs.

Only reveal() accepts a queried outcome. No unselected outcome is an input.
Costs are in declared units; they are not measured chemical runtimes.
"""
import numpy as np

def reserve(v, loss_cap):
    """Cost of discharging all but at most loss_cap unresolved pools."""
    v=np.asarray(v, dtype=np.int64)
    keep=max(0, len(v)-int(loss_cap))
    return int(np.sort(v)[:keep].sum())

class CostCertificate:
    def __init__(self, score, pool, key, cost, quota, loss_cap=0, proposal='score'):
        self.score=np.asarray(score,float);self.pool=np.asarray(pool,str);self.key=np.asarray(key,str)
        self.cost=np.asarray(cost,np.int64)
        assert len(self.score)==len(self.pool)==len(self.key)==len(self.cost)
        assert np.all(self.cost>0) and int(loss_cap)==loss_cap and loss_cap>=0
        self.names=sorted(set(self.pool));self.group=np.asarray([self.names.index(j) for j in self.pool])
        self.loss_cap=int(loss_cap);self.proposal=proposal
        self.orders=[np.asarray(sorted(np.flatnonzero(self.group==j),key=lambda i:(-self.score[i],self.key[i])),int) for j in range(len(self.names))]
        self.baseline=np.zeros(len(self.score),bool)
        for order in self.orders:self.baseline[order[:quota]]=True
        self.budget=int(self.cost[self.baseline].sum());self.remaining=self.budget
        self.active=np.ones(len(self.score),bool);self.hits=set();self.selected=[];self.labels=[]
        self.fixed=np.asarray(sorted(range(len(self.score)),key=lambda i:(-self.score[i],self.pool[i],self.key[i])),int)
        self.ranks=np.empty(len(self.score),int);self.ranks[self.fixed]=np.arange(len(self.score))
        self._allowed=None
    def obligations(self):
        return self.active & self.baseline & ~np.isin(self.group,list(self.hits))
    def mask(self):
        if self._allowed is not None:return self._allowed
        O=self.obligations();v=np.bincount(self.group[O],weights=self.cost[O],minlength=len(self.names)).astype(np.int64)
        F=reserve(v,self.loss_cap);assert F<=self.remaining
        # Outside obligations, a negative branch leaves the reserve unchanged.
        need=np.full(len(self.score),F,dtype=np.int64)
        for j in range(len(self.names)):
            indices=np.flatnonzero(O & (self.group==j))
            for c in np.unique(self.cost[indices]):
                after=v.copy();after[j]-=int(c)
                need[indices[self.cost[indices]==c]]=reserve(after,self.loss_cap)
        self._allowed=self.active & (self.cost+need<=self.remaining)
        return self._allowed
    def action(self):
        allowed=np.flatnonzero(self.mask())
        if not len(allowed):
            assert reserve(np.bincount(self.group[self.obligations()],weights=self.cost[self.obligations()],minlength=len(self.names)).astype(int),self.loss_cap)==0
            return None
        value=self.score/self.cost if self.proposal=='density' else self.score
        best=float(value[allowed].max());ties=allowed[value[allowed]>=best-1e-12]
        return int(ties[np.argmin(self.ranks[ties])])
    def reveal(self,i,y):
        assert self.active[i] and self.mask()[i] and y in (0,1)
        self.remaining-=int(self.cost[i]);self.active[i]=False;self.selected.append(int(i));self.labels.append(int(y))
        if y:self.hits.add(int(self.group[i]))
        self._allowed=None
    def run(self,y):
        # Labels are accessed strictly after action selection.
        while True:
            i=self.action()
            if i is None:break
            self.reveal(i,int(y[i]))
        ix=np.asarray(self.selected,int);basehit=set(self.group[self.baseline & (np.asarray(y)==1)])
        lost=len(basehit-self.hits);assert lost<=self.loss_cap
        return dict(C=int(sum(self.labels)),baseline_lost=lost,coverage=len(self.hits),baseline_coverage=len(basehit),checks=len(ix),cost=self.budget-self.remaining,budget=self.budget,unspent=self.remaining),ix
