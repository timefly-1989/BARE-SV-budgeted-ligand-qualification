"""Restore official source labels and verify every cost/loss-cap policy value."""
from pathlib import Path
import argparse,hashlib,json,gzip,tarfile,time
import pandas as pd,numpy as np
from rdkit import Chem,RDLogger
from certificate import CostCertificate
H=Path(__file__).resolve().parent;R=H.parents[1]
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--toxcast',required=True,type=Path);ap.add_argument('--fsmol',required=True,type=Path);a=ap.parse_args();start=time.perf_counter();RDLogger.DisableLog('rdApp.*')
    plan=json.loads((H/'analysis_plan.json').read_text())
    for p,h in plan['code_hashes'].items():assert sha(H/p)==h
    assert sha(a.toxcast)=='02c8b96da666884a13746e4891fc10b4f81f51fa14e0060df1db7da0223b46c6'
    assert sha(a.fsmol)=='528a9c4e8d74c4287acda79536eecbf91418d6d0ac2c55918b270d78c2333ebc'
    f=R/'experiments/50_discovery_allocation_20261028';e=R/'experiments/52_multisource_randomized_20261028'
    maps=pd.read_csv(f/'data/partition_rows.csv');wanted={(r.assay,int(r.source_row)):r.key for r in maps[maps.role.eq('query')].itertuples()};members=pd.read_csv(f/'sources/test_member_checksums.csv').set_index('assay').member.to_dict();labels=[]
    with tarfile.open(a.fsmol) as archive:
        for assay in sorted(maps.assay.unique()):
            for row,line in enumerate(gzip.decompress(archive.extractfile(members[assay]).read()).splitlines(),1):
                if (assay,row) in wanted:labels.append(dict(assay=assay,key=wanted[(assay,row)],y=int(float(json.loads(line)['Property']))))
    assert len(labels)==5498
    fs=pd.read_csv(f/'data/new_test_scores_before_labels.csv').merge(pd.DataFrame(labels),on=['assay','key'],validate='many_to_one')
    raw=pd.read_csv(a.toxcast);first={}
    for row,smiles in raw.smiles.items():
        mol=Chem.MolFromSmiles(smiles)
        if mol is None:continue
        Chem.RemoveStereochemistry(mol);key=hashlib.sha256(Chem.MolToSmiles(mol,canonical=True,isomericSmiles=False).encode()).hexdigest()
        if key not in first:first[key]=row
    lookup=raw.loc[list(first.values())].copy();lookup.index=list(first.keys());tox=pd.read_csv(e/'data/scores_before_labels.csv');tox['y']=[int(lookup.loc[k,assay]) for k,assay in zip(tox.key,tox.assay)];tox['campaign']=tox.unit;tox['method']='Morgan2048_RF';tox['seed']=11
    expected=pd.read_csv(H/'results/cost_retention_policies.csv');count=0;identical_sets=0
    # Independent comparison with the earlier static DPQR, not just a saved count.
    import sys
    sys.path.insert(0,str(f));from policies import simulate
    for dataset,d in [('ToxCast',tox),('FS_Mol',fs)]:
        for (method,seed,campaign),g in d.groupby(['method','seed','campaign'],sort=True):
            g=g.sort_values(['assay','key']).reset_index(drop=True)
            costs=np.array([[1,2,4][int(hashlib.sha256(('cost54|'+str(j)+'|'+str(k)).encode()).hexdigest(),16)%3] for j,k in zip(g.assay,g.key)],int)
            z=expected[expected.dataset.eq(dataset)&expected.method.eq(method)&expected.seed.eq(seed)&expected.campaign.eq(campaign)]
            for row in z.itertuples():
                cost=np.ones(len(g),int) if row.cost_profile=='unit' else costs
                obj=CostCertificate(g.score,g.assay,g.key,cost,int(row.B),int(row.loss_cap),row.proposal);out,ix=obj.run(g.y.to_numpy())
                for k in ['C','baseline_lost','coverage','baseline_coverage','checks','cost','budget','unspent']:assert out[k]==getattr(row,k),(dataset,method,seed,campaign,k)
                if row.cost_profile=='unit' and row.loss_cap==0:
                    _,old,_=simulate(g.score,g.assay,g.key,g.y,int(row.B),'recycling',int(seed));assert set(ix)==set(old);identical_sets+=1
                count+=1
            print('REPLAY',dataset,method,seed,campaign,count,flush=True)
    out=dict(status='PASS',source_query_labels_reconstructed=70137,policy_values_replayed=count,unit_zero_loss_selected_sets_match_old_DPQR=identical_sets,synthetic_costs_not_measured_times=True,no_new_confirmatory_tests=True,seconds=time.perf_counter()-start)
    (H/'checks').mkdir(exist_ok=True);(H/'checks/public_replay.json').write_text(json.dumps(out,indent=2)+'\n');print(out)
if __name__=='__main__':main()
