"""Research-exposed sensitivity, never a new independent test.

Synthetic known cost is an identity hash in {1,2,4}, not an observed runtime.
Every policy sees the same candidate costs, baseline and budget in a setting.
"""
from pathlib import Path
import json,hashlib,datetime,sys,time
import pandas as pd,numpy as np
from certificate import CostCertificate
H=Path(__file__).resolve().parent;R=H.parents[1]
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def main():
    plan=json.loads((H/'analysis_plan.json').read_text())
    for p,h in plan['code_hashes'].items():assert sha(H/p)==h
    ext=R/'experiments/52_multisource_randomized_20261028';fs=R/'experiments/50_discovery_allocation_20261028'
    t=pd.read_csv(ext/'data/scores_before_labels.csv').merge(pd.read_csv(ext/'data/query_labels.csv'),on=['assay','key'],validate='one_to_one');t['method']='Morgan2048_RF';t['campaign']=t.unit;t['seed']=11
    f=pd.read_csv(fs/'data/new_test_scores_before_labels.csv').merge(pd.read_csv(fs/'data/new_test_query_labels.csv'),on=['assay','key'],validate='many_to_one');f['provider']='FS_Mol'
    old=pd.read_csv(R/'experiments/53_constrained_policy_audit_20261028/results/policies.csv')
    records=[];selections=[]
    for dataset,d in [('ToxCast',t),('FS_Mol',f)]:
        for (method,seed,campaign),g in d.groupby(['method','seed','campaign'],sort=True):
            g=g.sort_values(['assay','key']).reset_index(drop=True);J=g.assay.nunique()
            hashed=np.array([[1,2,4][int(hashlib.sha256(('cost54|'+str(a)+'|'+str(k)).encode()).hexdigest(),16)%3] for a,k in zip(g.assay,g.key)],int)
            for B in [4,16,32]:
                for profile,cost in [('unit',np.ones(len(g),int)),('hash124',hashed)]:
                    bas=None
                    for ell in sorted(set([0,1,2,J])):
                        for proposal in (['score'] if profile=='unit' else ['score','density']):
                            obj=CostCertificate(g.score,g.assay,g.key,cost,B,ell,proposal)
                            start=time.perf_counter();res,ix=obj.run(g.y.to_numpy());seconds=time.perf_counter()-start
                            baseline_C=int(g.y.to_numpy()[obj.baseline].sum());baseline_cov=len(set(g.assay[obj.baseline & g.y.eq(1).to_numpy()]))
                            assert res['cost']<=res['budget'] and res['baseline_coverage']==baseline_cov
                            if profile=='unit' and ell==0 and seed==11:
                                row=old[(old.dataset==dataset)&(old.method==method)&(old.campaign==campaign)&old.B.eq(B)&old.algorithm.eq('recycling')].iloc[0]
                                assert res['C']==row.C and res['checks']==row.K
                            records.append(dict(dataset=dataset,method=method,seed=seed,campaign=campaign,provider=g.provider.iloc[0],B=B,cost_profile=profile,loss_cap=ell,proposal=proposal,baseline_C=baseline_C,baseline_cost=obj.budget,baseline_checks=int(obj.baseline.sum()),seconds=seconds,**res))
                    # Record identity-hash costs without any source outcomes.
            pd.DataFrame(records).to_csv(H/'results/cost_retention_policies.csv',index=False)
            print(dataset,method,seed,campaign,'values',len(records),flush=True)
    for p,h in json.loads((H/'checks/frozen_guards.json').read_text()).items():assert sha(R/p)==h
    out=dict(status='PASS',policy_values=len(records),no_query_labels_used_for_costs=True,all_cost_budgets_respected=True,all_terminal_loss_caps_respected=True,unit_zero_cap_matches_previous_DPQR=True,synthetic_costs_not_measured_times=True,new_independent_tests=0,new_p_values=0,finished=datetime.datetime.now().astimezone().isoformat())
    (H/'checks/cost_audit.json').write_text(json.dumps(out,indent=2)+'\n');print(out)
if __name__=='__main__':main()
