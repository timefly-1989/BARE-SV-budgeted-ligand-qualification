# Known-cost / bounded discovery-loss certificate, 29 October 2026

Research-exposed extension, not a new independent test. All previous locked
scores, outcomes, assignments and primary tests are unchanged. No unsubmitted
manuscript, TOC, raw molecular structures or individual source activities is
published in this numerical archive.

The exact certificate allows at most ell lost baseline-discovered pools per
campaign, under every unrestricted binary outcome completion. Known positive
deterministic costs are allowed. Minimum worst-case remaining cost is the sum
of unresolved pool costs after removing the ell largest costs. An action or a
committed batch is admissible exactly when its cost plus the reserve after an
all-negative return fits the remaining budget. Positive returns only reduce
that reserve. The model/score is replaceable; this does not claim to invent
shielding, cost-sensitive search, dynamic programming or an optimal heuristic.

Independent minimax recursion verifies 126053 feasibility cases, 226104 action
cases and 46608 committed-batch cases. There are 4500 policy values using frozen
ToxCast RF seed11 and FS-Mol RF/CatBoost/active-neighbour seeds11/23/37 at quotas
4/16/32. Loss allowances are0/1/2/number-of-pools per campaign, deduplicated.
Unit cost is compared with SYNTHETIC identity-hash costs1/2/4; these are NOT
measured laboratory, route-planning, docking or wall-clock costs. Every policy
shares baseline and cost budget within its setting; unspent cost is reported.

ToxCast unit-cost quota32: zero/one/two loss-cap rules recover3876/3968/4039,
with actual aggregate losses0/28/49; unrestricted scoring4044/loss67. Per-library
loss caps do not imply an aggregate panel cap of one or two. Synthetic-cost
zero-loss score/density ranking gives3904/4393 with budget34746; density leaves
one unit unspent. Neither relaxed allowance nor any fixed proposal uniformly
improves recovery. FS-Mol RF unit-cost quota32 remains an adverse DPQR budget:
uniform654, staticDPQR632, shieldedUCB671 (previous audit).

The fixed-panel equal-programme-value envelope C-lambda*loss has exact crossings
5/18,87/38,76/11 among the archived controls and added unit-cost cap rules.
This estimates no real organizational price, new-campaign effect or laboratory
population benefit. An observed zero loss is distinct from a universal proof.

## Official data and reproduction
ToxCast: https://deepchemdata.s3-us-west-1.amazonaws.com/datasets/toxcast_data.csv.gz
SHA256 02c8b96da666884a13746e4891fc10b4f81f51fa14e0060df1db7da0223b46c6
FS-Mol: https://ndownloader.figshare.com/files/31345321
SHA256 528a9c4e8d74c4287acda79536eecbf91418d6d0ac2c55918b270d78c2333ebc
FS-Mol DOI10.6084/m9.figshare.16941100.v1, CC-BY4. Source terms/attribution apply.
ToxCast response calls include toxicity and are not therapeutic binding hits.
Wu etal., MoleculeNet, Chem.Sci.2018 doi10.1039/C7SC02664A;
Stanley etal., FS-Mol, NeurIPS Datasets/Benchmarks2021.

Run from extracted root:
```
uv run --no-project --python 3.12 --with-requirements experiments/50_discovery_allocation_20261028/requirements.txt python experiments/54_cost_retention_decisions_20261029/verify_theory.py
uv run --no-project --python 3.12 --with-requirements experiments/50_discovery_allocation_20261028/requirements.txt python experiments/54_cost_retention_decisions_20261029/verify_decisions.py
uv run --no-project --python 3.12 --with-requirements experiments/50_discovery_allocation_20261028/requirements.txt python experiments/54_cost_retention_decisions_20261029/replay_public.py --toxcast /path/toxcast_data.csv.gz --fsmol /path/fsmol.tar
```
The last command reconstructs70137 official query labels, replays all4500
values and compares381 unit-cost zero-loss terminal sets with old static DPQR.
run_cost_audit.py is the original workspace runner; it expects local prior
outcome CSVs/guards. replay_public.py is the standalone public verification
entry point. Repeated seeds and quotas are not independent experiments.
