"""Nested stage-observed calibration screen. All previous outcomes are exposed.

Only double-exclusion OOF predictions train an outer-fold calibrator. Source
checkpoints, predictions, splits and endpoint files are read-only. No test-set
or historical-cohort parameter search is performed.
"""
import os
for _n in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','VECLIB_MAXIMUM_THREADS']:
    os.environ[_n]='1'
from pathlib import Path
import hashlib, importlib.util, json, time
import numpy as np
import pandas as pd
from scipy.optimize import minimize
from scipy.special import expit, logit
from sklearn.metrics import brier_score_loss, log_loss

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
EX=ROOT/'experiments'
sp=importlib.util.spec_from_file_location('calibration_common',EX/'11_algorithm_optimization_20261025/run_experiments.py')
common=importlib.util.module_from_spec(sp);sp.loader.exec_module(common)

def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(p,o): Path(p).write_text(json.dumps(o,indent=2,allow_nan=False)+'\n')

def base(excluded,d):
    """Return all query-fold probabilities, never training-in-sample scores."""
    a,q=common.isolated_indices(d,tuple(excluded))
    if len(excluded)==1:
        vals=[]
        for stage in ['route','downstream']:
            f=np.load(EX/f'16_molecular_foundation_20261025/cache/fold{excluded[0]}_chemeleon_{stage}_seed11.npz')
            assert np.array_equal(f['context_index'],a if stage=='route' else a[d.D.to_numpy()[a]==1])
            vals.append(f['values'])
        p=np.column_stack(vals)
    else:
        f=np.load(EX/('17_stage_evidence_20261025/cache/exclude_'+'_'.join(map(str,excluded))+'.npz'))
        assert np.array_equal(f['train'],a) and np.array_equal(f['query'],q)
        p=np.column_stack([f['pD'][:,1],f['pR'][:,1]])
    assert p.shape==(len(q),2) and np.isfinite(p).all()
    return a,q,p

def design(frame,p):
    """Pool means use complete query pools, before chemically eligible subsetting."""
    l=logit(np.clip(p,1e-6,1-1e-6))
    code,ids=pd.factorize(frame.pocket_id,sort=True)
    mean=np.column_stack([np.bincount(code,weights=l[:,s])/np.bincount(code) for s in range(2)])
    return [np.column_stack([np.ones(len(l)),l[:,s],mean[code,s]]) for s in range(2)]

def trainbank(outer,d):
    a,_=common.isolated_indices(d,(outer,))
    parts=[]; pp=[];xx=[[],[]];audit=[]
    for inner in range(5):
        if inner==outer: continue
        e=tuple(sorted([outer,inner])); context,q,p=base(e,d)
        x=design(d.iloc[q],p)
        keep=np.isin(q,a)&d.fold.to_numpy()[q].__eq__(inner)
        parts.append(q[keep]);pp.append(p[keep])
        for s in range(2): xx[s].append(x[s][keep])
        assert not set(d.iloc[context].cluster30)&set(d.iloc[q].cluster30)
        audit.append(dict(outer=outer,inner=inner,context_rows=len(context),
                          complete_query_rows=len(q),calibration_rows=int(keep.sum()),
                          outer_labels_used=False,training_in_sample_predictions_used=False))
    ix=np.concatenate(parts)
    assert set(ix)==set(a) and len(ix)==len(a)
    return ix,np.concatenate(pp),[np.concatenate(z) for z in xx],audit

def fit(frame,x,context,countweight):
    D=frame.D.to_numpy(float); y=frame.y.to_numpy(float); n=len(D)
    ix=3 if context else 2
    x=[z[:,:ix] for z in x]
    code,_=pd.factorize(frame.pocket_id,sort=True)
    P=np.bincount(code,weights=y)
    ridge=.01
    def fun(t):
        t=t.reshape(2,ix)
        # Identity-centered coefficients retain the base score without data.
        eta=[x[s][:,1]+x[s]@t[s] for s in range(2)]
        d,r=map(expit,eta); joint=d*r
        loss=np.mean(np.logaddexp(0,eta[0])-D*eta[0]+D*(np.logaddexp(0,eta[1])-y*eta[1]))
        gd=(d-D)/n; gr=D*(r-y)/n
        mu=np.bincount(code,weights=joint)
        if countweight:
            # Poisson quasi-likelihood for the first moment, not independence.
            loss+=countweight*np.sum(mu-P*np.log(np.maximum(mu,1e-12)))/n
            dl=countweight*(1-P/np.maximum(mu,1e-12))[code]/n
            gd+=dl*joint*(1-d);gr+=dl*joint*(1-r)
        loss+=ridge*np.sum(t*t)/2
        grad=np.stack([x[0].T@gd,x[1].T@gr])+ridge*t
        return loss,grad.ravel()
    bounds=[(-6,6),(-.9,9)]+([(-3,3)] if context else [])
    res=minimize(fun,np.zeros((2,ix)).ravel(),method='L-BFGS-B',jac=True,
                 bounds=bounds*2,options=dict(maxiter=500,ftol=1e-12,gtol=1e-8))
    assert res.success, res.message
    t=res.x.reshape(2,ix)
    return t,dict(success=bool(res.success),iterations=res.nit,loss=float(res.fun),
                  coefficients=t.tolist(),free_parameters=2*ix,gradient_max=float(np.max(np.abs(res.jac))))

def predict(x,t):
    return np.column_stack([expit(z[:,1]+z[:,:t.shape[1]]@t[s]) for s,z in enumerate(x)])

def measure(frame,score,method):
    result=[]
    for fold,part in frame.groupby('fold',sort=True):
        idx=part.index.to_numpy();q=score[idx]
        for B in [1,2,4,8,16,32]:
            selected=[]
            for _,g in part.groupby('pocket_id',sort=True):
                z=g.index.to_numpy(); selected.extend(z[np.lexsort((frame.candidate_id.to_numpy()[z],-score[z]))[:B]])
            for policy,sel in [('uniform',np.array(selected)),('global',idx[np.lexsort((part.candidate_id.to_numpy(),part.pocket_id.to_numpy(),-q))[:len(selected)]])]:
                f=frame.loc[sel]
                result.append(dict(method=method,fold=int(fold),budget=B,policy=policy,K=len(sel),
                    C=int(f.y.sum()),Cov=int(f.groupby('pocket_id').y.sum().gt(0).sum())))
    return result

def main():
    start=time.perf_counter()
    d,_,_=common.load_development();d=d.reset_index(drop=True)
    protocol=json.loads((HERE/'protocol.json').read_text())
    assert protocol['stage_calibration_screen']['primary']=='stage_pool_count'
    methods={'stage_platt':(False,0.),'stage_count':(False,1.),
             'stage_pool':(True,0.),'stage_pool_count':(True,1.)}
    scores={k:np.zeros(len(d)) for k in methods}
    probs={k:np.zeros((len(d),2)) for k in methods}
    raw=np.zeros((len(d),2));fits=[];audits=[];losses=[]
    for outer in range(5):
        a,p,x,au=trainbank(outer,d);audits.extend(au)
        _,q,pq=base((outer,),d);xq=design(d.iloc[q],pq);raw[q]=pq
        for key,(context,cw) in methods.items():
            t,fitlog=fit(d.iloc[a],x,context,cw)
            out=predict(xq,t);probs[key][q]=out
            scores[key][q]=out.prod(1)*d.reference_success.to_numpy()[q]
            fits.append(dict(fold=outer,method=key,calibration_rows=len(a),**fitlog))
        print('FOLD',outer,'fits complete',flush=True)
    scores['CheMeleon_full_full']=raw.prod(1)*d.reference_success
    reference=pd.read_csv(EX/'35_stage_evidence_upgrade_20261027/results/analysis_scores.csv')
    reference=reference[reference.cohort.eq('development')].reset_index(drop=True)
    assert np.array_equal(reference[['pocket_id','candidate_id']].to_numpy(),d[['pocket_id','candidate_id']].to_numpy())
    for col in ['morgan_direct','morgan_conditional','chemeleon_direct','chemeleon_compact_qualification',
                'strict_catboost_conditional','strict_catboost_joint','strict_CFE','rf_joint']:
        scores[col]=reference[col].to_numpy()
    per=[]
    for key,s in scores.items():
        assert np.isfinite(s).all()
        per.extend(measure(d,s,key))
        losses.append(dict(method=key,stage='joint',N=len(d),Brier=brier_score_loss(d.y,s),NLL=log_loss(d.y,np.clip(s,1e-9,1-1e-9))))
    for key,p in dict(CheMeleon_full_full=raw,**probs).items():
        for s,(name,label,mask) in enumerate([('route',d.D,np.ones(len(d),bool)),('conditional',d.y,d.D.eq(1).to_numpy())]):
            losses.append(dict(method=key,stage=name,N=int(mask.sum()),Brier=brier_score_loss(label[mask],p[mask,s]),NLL=log_loss(label[mask],p[mask,s])))
    out=d[['pocket_id','candidate_id','fold','cluster30','D','y','reference_success']].copy()
    for key,v in scores.items():out[key]=v
    out.to_csv(HERE/'results/development_scores.csv',index=False)
    f=pd.DataFrame(per);f.to_csv(HERE/'results/fold_results.csv',index=False)
    summary=f.groupby(['method','budget','policy'],sort=False)[['K','C','Cov']].sum().reset_index()
    summary.to_csv(HERE/'results/summary.csv',index=False)
    pd.DataFrame(losses).to_csv(HERE/'results/losses.csv',index=False)
    save(HERE/'checks/fits.json',fits);save(HERE/'checks/nesting.json',audits)
    primary=f[f.budget.eq(1)&f.policy.eq('global')]
    controls=[k for k in scores if k not in methods]
    totals=primary.groupby('method').C.sum()
    strongest=max(controls,key=lambda k:totals[k])
    a=primary[primary.method.eq('stage_pool_count')].set_index('fold')
    b=primary[primary.method.eq(strongest)].set_index('fold')
    delta=a.C-b.C
    passed=int(totals['stage_pool_count'])>=int(totals[strongest])+5 and int(delta.gt(0).sum())>=3 and a.Cov.sum()>=b.Cov.sum()-1
    save(HERE/'results/promotion.json',dict(primary='global K=one candidate per original pocket',
       proposed='stage_pool_count',C=int(totals['stage_pool_count']),strongest_fixed_control=strongest,
       control_C=int(totals[strongest]),fold_differences=delta.to_dict(),passed=bool(passed),
       decision='eligible for a new independently frozen evaluation' if passed else 'do not promote as a performance improvement',
       exposed_development=True,confirmatory_superiority=False,seconds=time.perf_counter()-start))
    print(summary[summary.budget.isin([1,8,32])].to_string(index=False),flush=True)
    print('PROMOTION',passed,'vs',strongest,totals.to_dict(),flush=True)

if __name__=='__main__': main()
