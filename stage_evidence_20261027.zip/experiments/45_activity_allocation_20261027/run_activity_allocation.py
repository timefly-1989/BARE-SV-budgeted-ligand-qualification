"""Research-exposed real-activity evaluation of the allocation component.

No route labels are invented; no model is fitted; seed repetitions are not
independent target replicates. All saved methods/conditions are retained.
"""
from pathlib import Path
import datetime,hashlib,json,heapq
import numpy as np,pandas as pd
H=Path(__file__).resolve().parent;E=H.parent

def allocations(g,m,B,alg):
 queues=[]
 for p,q in g.groupby('assay',sort=True):queues.append(q.sort_values([m,'key'],ascending=[False,True]).index.to_numpy())
 ptr=np.zeros(len(queues),int);pids=sorted(set(g.assay));K=sum(min(B,len(q)) for q in queues);scores=g[m].to_numpy(float);y=g.y.to_numpy(int);chosen=[];found=set();nohit=np.ones(len(queues))
 def query(j):
  i=int(queues[j][ptr[j]]);ptr[j]+=1;chosen.append(i);return int(y[i])
 if alg=='uniform':return [int(i) for q in queues for i in q[:min(B,len(q))]]
 if alg=='recycling':
  while True:
   available=[j for j,q in enumerate(queues) if j not in found and ptr[j]<min(B,len(q))]
   if not available:break
   j=min(available,key=lambda j:(ptr[j],pids[j]));hit=query(j)
   if hit:found.add(j)
 for _ in range(K-len(chosen)):
  available=[j for j,q in enumerate(queues) if ptr[j]<len(q)]
  def value(j):
   base=scores[queues[j][ptr[j]]]
   if alg=='forecast_coverage4':return base*(1+4*nohit[j])
   if alg=='observed_coverage4':return base*(1 if j in found else 5)
   return base
  j=min(available,key=lambda j:(-value(j),pids[j],str(g.key.iloc[queues[j][ptr[j]]])))
  i=int(queues[j][ptr[j]]);hit=query(j)
  if hit:found.add(j)
  if alg=='forecast_coverage4':nohit[j]*=1-scores[i]
 return chosen

def main():
 score=E/'36_external_activity_benchmark_20261027/results/scores_before_labels.csv';labels=E/'36_external_activity_benchmark_20261027/data/evaluation_labels.csv'
 cfg=dict(timestamp_local=datetime.datetime.now().astimezone().isoformat(),scope='Retrospective policy-component evaluation on activity data already exposed in experiment36; no full D/V/Q or dual-context validation',policies=['uniform','global','forecast_coverage4','observed_coverage4','recycling'],budgets=[4,8,16,32,64,128,256],primary_display_budget=32,all_saved_methods_conditions_seeds=True,no_new_training=True,no_confirmatory_significance_test=True,source_sha256={str(p.relative_to(E.parents[0])):hashlib.sha256(p.read_bytes()).hexdigest() for p in [score,labels,Path(__file__)]})
 (H/'protocol.json').write_text(json.dumps(cfg,indent=2)+'\n')
 s=pd.read_csv(score);y=pd.read_csv(labels);methods=[c for c in s if c not in ['assay','key','protocol','seed']];z=s.merge(y,on=['assay','key'],validate='many_to_one');rows=[];per=[]
 for (condition,seed),x in z.groupby(['protocol','seed'],sort=True):
  g=x.sort_values(['assay','key']).reset_index(drop=True)
  for m in methods:
   for B in cfg['budgets']:
    baseline=None
    for a in cfg['policies']:
     ix=allocations(g,m,B,a);q=g.iloc[ix];hits=set(q[q.y.eq(1)].assay)
     if a=='uniform':baseline=hits
     if a=='recycling':assert baseline<=hits
     rows.append(dict(protocol=condition,seed=seed,method=m,B=B,algorithm=a,K=len(ix),C=int(q.y.sum()),coverage=len(hits),assays=g.assay.nunique()))
     if B==32:
      for assay,v in q.groupby('assay'):per.append(dict(protocol=condition,seed=seed,method=m,B=B,algorithm=a,assay=assay,C=int(v.y.sum()),calls=len(v)))
  print('ACTIVITY_CAMPAIGN_COMPLETE',condition,seed,flush=True)
 out=pd.DataFrame(rows);out.to_csv(H/'results/activity_policy_summary.csv',index=False);pd.DataFrame(per).to_csv(H/'results/activity_policy_per_assay.csv',index=False)
 p=out[out.B.eq(32)&out.seed.eq(11)];print(p[['protocol','method','algorithm','C','coverage','K']].to_string(index=False),flush=True)
 report=dict(status='COMPLETE',source_validation_records=len(y),actives=int(y.y.sum()),assays=y.assay.nunique(),policy_evaluations=len(out),models_refitted=0,route_or_downstream_labels_created=0,independent_test=False,discovery_set_preservation_checks=int(sum(out.algorithm.eq('recycling'))))
 (H/'results/activity_policy_audit.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report),flush=True)
if __name__=='__main__':main()
