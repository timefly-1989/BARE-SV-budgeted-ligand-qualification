"""Cross-implementation policy check over exhaustive small label tables."""
from pathlib import Path
import sys,itertools,json
import pandas as pd
H=Path(__file__).resolve().parent;sys.path.insert(0,str(H));sys.path.insert(0,str(H.parent/'44_moad_allocation_test_20261027'))
from run_activity_allocation import allocations
from allocation import allocate
n=0
for y in itertools.product([0,1],repeat=6):
 g=pd.DataFrame(dict(assay=['a']*3+['b']*3,key=['0','1','2']*2,score=[.9,.8,.7,.3,.2,.1],y=y))
 for B in [1,2,3]:
  for a in ['uniform','global','forecast_coverage4','observed_coverage4','recycling']:
   fast=allocations(g,'score',B,a);original=allocate(g.score,g.assay,g.key,B,a,lambda i:y[i]);assert fast==original,(B,a,y,fast,original);n+=1
r=dict(status='PASS',exact_sequence_comparisons=n,all_binary_outcomes=True,independent_policy_implementations=True);(H/'checks/fast_policy.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
