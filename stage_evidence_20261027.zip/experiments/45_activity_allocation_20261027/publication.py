"""Complete method table and decision-component tradeoff figures."""
from pathlib import Path
import pandas as pd
import matplotlib;matplotlib.use('Agg');import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
H=Path(__file__).resolve().parent;(H/'figures').mkdir(exist_ok=True)
labels={'CheMeleon_PCA24_TabICLv2':'CheMeleon--TabICLv2','CheMeleon_PCA24_CatBoost':'CheMeleon--CatBoost','CheMeleon_PCA24_RF':'CheMeleon--RF','Morgan_SVD24_TabICLv2':'Morgan--TabICLv2','Morgan2048_CatBoost':'Morgan--CatBoost','Morgan2048_RF':'Morgan--RF','ECFP4_max_training_active_Tanimoto':'Active-neighbour'}
x=pd.read_csv(H/'results/activity_policy_summary.csv');p=x[x.B.eq(32)&x.seed.eq(11)]
lines=[r'\begin{table}[!htbp]\centering\small',r'\caption{Real-activity allocation-component reanalysis at 224 candidate checks (32 per assay under uniform allocation), using seed 11. Entries show recovered actives / assays with a discovery. All seven saved predictors are retained. Both chemical-exclusion conditions use the same validation labels. These are research-exposed, activity-supervised comparisons.}',r'\label{tab:activity-allocation}',r'\begin{tabular}{lrrrrr}\toprule Predictor & Uniform & Global & Forecast & Observed & Recycling\\\midrule']
for protocol,title in [('identity_clean','Identity exclusion'),('scaffold_blocked','Additional scaffold exclusion')]:
 lines.append(r'\multicolumn{6}{l}{\textit{'+title+r'}}\\')
 for m,label in labels.items():
  g=p[p.protocol.eq(protocol)&p.method.eq(m)].set_index('algorithm');values=[f'{int(g.loc[a,"C"])}/{int(g.loc[a,"coverage"])}' for a in ['uniform','global','forecast_coverage4','observed_coverage4','recycling']];lines.append(label+' & '+' & '.join(values)+r'\\')
lines +=[r'\bottomrule\end{tabular}\end{table}'];s='\n'.join(lines)+'\n';(H/'results/activity_allocation_table.tex').write_text(s)
z=s.replace('Real-activity allocation-component reanalysis at 224 candidate checks (32 per assay under uniform allocation), using seed 11. Entries show recovered actives / assays with a discovery. All seven saved predictors are retained. Both chemical-exclusion conditions use the same validation labels. These are research-exposed, activity-supervised comparisons.','实测活性预算分配组件再分析，总预算224次（统一分配时每测定32次），种子11。数值为活性回收/发现测定数，保留全部七个已保存预测器。两种化学排除条件共用相同验证标签；这些是研究已暴露的活性监督比较。').replace('Predictor & Uniform & Global & Forecast & Observed & Recycling','预测器 & 统一 & 全局 & 预测覆盖 & 观测覆盖 & 回收').replace('Identity exclusion','身份排除').replace('Additional scaffold exclusion','额外骨架排除').replace('Active-neighbour','活性近邻')
(H/'results/activity_allocation_table_zh.tex').write_text(z)
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10.5,'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42,'svg.fonttype':'none'})
fig,axes=plt.subplots(1,2,figsize=(7.4,3.7));methods=[('CheMeleon_PCA24_TabICLv2','CheMeleon + TabICLv2','#24557a'),('Morgan2048_RF','Morgan + RF','#c16a24')];policies=[('uniform','Uniform','s'),('global','Global','o'),('forecast_coverage4','Forecast','D'),('observed_coverage4','Observed','X'),('recycling','Recycling','^')]
for ax,protocol,title in zip(axes,['identity_clean','scaffold_blocked'],['(a) Identity exclusion','(b) Scaffold exclusion']):
 for m,label,color in methods:
  for alg,pl,mark in policies:
   g=x[x.B.eq(32)&x.protocol.eq(protocol)&x.method.eq(m)&x.algorithm.eq(alg)];ax.scatter(g.coverage,g.C,c=color,marker=mark,s=38,alpha=.75,edgecolor='white',lw=.35)
 ax.set_xlim(0,7.4);ax.set_xticks(range(0,8));ax.set_ylim(0,67);ax.set_xlabel('Assays with an active discovery');ax.set_title(title);ax.grid(alpha=.13)
axes[0].set_ylabel('Recovered experimental actives')
handles=[Line2D([],[],marker='o',color=c,lw=0,label=l,ms=6) for _,l,c in methods]+[Line2D([],[],marker=mark,color='.45',lw=0,label=l,ms=6) for _,l,mark in policies]
fig.legend(handles=handles,loc='lower center',ncol=4,frameon=False,fontsize=8.5);fig.tight_layout(rect=(0,.23,1,1))
for ext in ['pdf','svg','png']:fig.savefig(H/'figures'/('activity_allocation.'+ext),dpi=200,bbox_inches='tight')
plt.close(fig)
# A numerical claim check for the primary display: do not imply seed runs are
# independent biological test populations.
w=x[x.B.eq(32)].pivot(index=['protocol','seed','method'],columns='algorithm',values='C');print('B32_RECYCLING_GAIN_RANGE',int((w.recycling-w.uniform).min()),int((w.recycling-w.uniform).max()),'cases',len(w))
