"""Read-only numerical replay of all saved activity policy values."""
from pathlib import Path
import json
import pandas as pd
from run_activity_allocation import allocations
H=Path(__file__).resolve().parent;E=H.parent
s=pd.read_csv(E/'36_external_activity_benchmark_20261027/results/scores_before_labels.csv');y=pd.read_csv(E/'36_external_activity_benchmark_20261027/data/evaluation_labels.csv');z=s.merge(y,on=['assay','key'],validate='many_to_one');saved=pd.read_csv(H/'results/activity_policy_summary.csv');count=0
for (condition,seed),x in z.groupby(['protocol','seed'],sort=True):
 g=x.sort_values(['assay','key']).reset_index(drop=True)
 for r in saved[saved.protocol.eq(condition)&saved.seed.eq(seed)].itertuples():
  ix=allocations(g,r.method,r.B,r.algorithm);q=g.iloc[ix]
  assert len(ix)==r.K and q.y.sum()==r.C and q.groupby('assay').y.sum().gt(0).sum()==r.coverage,(condition,seed,r.method,r.B,r.algorithm)
  count+=1
print(json.dumps(dict(status='PASS',numerical_policy_values=count,source_protocol_and_inputs_unchanged=True,models_refitted=0)))
