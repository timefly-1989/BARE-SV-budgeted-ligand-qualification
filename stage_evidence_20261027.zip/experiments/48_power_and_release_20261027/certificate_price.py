"""Exact score opportunity cost and a dependent-outcome counterexample.

These are mathematical diagnostics; no new optimum or calibration guarantee
is claimed. Marginal calibration alone does not justify adaptive performance.
"""
from pathlib import Path
import importlib.util,json,itertools
import numpy as np,pandas as pd
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1];EX=ROOT/'experiments'
spec=importlib.util.spec_from_file_location('allocation44',EX/'44_moad_allocation_test_20261027/allocation.py')
alloc=importlib.util.module_from_spec(spec);spec.loader.exec_module(alloc)

def one(frame,u,B,cohort,fold):
    pid=frame.pocket_id.to_numpy();cid=frame.candidate_id.to_numpy();y=frame.y.to_numpy(int)
    M=[]
    def reveal(i):M.append(i);return y[i]
    S=alloc.allocate(u,pid,cid,B,'recycling',reveal)
    G=alloc.allocate(u,pid,cid,B,'global');U=alloc.allocate(u,pid,cid,B,'uniform')
    forced=set(M)-set(G);removed=set(G)-set(S)
    direct=float(np.sum(u[G])-np.sum(u[S]))
    identity=float(np.sum(u[list(removed)])-np.sum(u[list(forced)]))
    assert len(forced)==len(removed) and direct>=-1e-10 and abs(direct-identity)<1e-9
    residual_gap=float(np.sum((y-u)[G])-np.sum((y-u)[S]))
    assert abs(int(y[G].sum()-y[S].sum())-direct-residual_gap)<1e-9
    return dict(cohort=cohort,fold=fold,budget=B,K=len(S),pilot=len(M),
       forced_outside_global=len(forced),score_opportunity_cost=direct,
       C_uniform=int(y[U].sum()),C_global=int(y[G].sum()),C_recycling=int(y[S].sum()),
       Cov_uniform=int(frame.iloc[U].groupby('pocket_id').y.sum().gt(0).sum()),
       Cov_recycling=int(frame.iloc[S].groupby('pocket_id').y.sum().gt(0).sum()),
       observed_residual_difference=residual_gap)

def main():
    d=pd.read_csv(EX/'35_stage_evidence_upgrade_20261027/results/analysis_scores.csv');rows=[]
    for cohort,g in d.groupby('cohort',sort=False):
        for fold,f in (g.groupby('fold',sort=True) if cohort=='development' else [(-1,g)]):
            f=f.reset_index(drop=True);u=f.chemeleon_compact_qualification.to_numpy(float)
            for B in [1,2,4,8,16,32]: rows.append(one(f,u,B,cohort,int(fold)))
    pd.DataFrame(rows).to_csv(HERE/'results/certificate_opportunity_cost.csv',index=False)
    summary=pd.DataFrame(rows).groupby(['cohort','budget'],sort=False).sum(numeric_only=True).drop(columns='fold').reset_index()
    summary.to_csv(HERE/'results/certificate_price_summary.csv',index=False)
    checks=0
    # Finite-set identity with nonuniform utilities and every binary assignment.
    for labels in itertools.product([0,1],repeat=6):
        f=pd.DataFrame(dict(pocket_id=['A']*3+['B']*3,candidate_id=list('abcdef'),y=labels))
        for B in [1,2,3]: one(f,np.array([.9,.8,.7,.3,.2,.1]),B,'toy',0);checks+=1
    Y=np.array([[1,0,1,0],[0,1,0,1]]);p=np.array([.5,.5]);u=p@Y
    static=sum(p[s]*Y[s,:2].sum() for s in range(2))
    adaptive=sum(p[s]*(Y[s,0]+Y[s,2 if Y[s,0] else 3]) for s in range(2))
    assert np.all(u==.5) and static==1 and adaptive==1.5
    check=dict(exhaustive_price_identities=checks,
       correlated_counterexample=dict(outcome_vectors=Y.tolist(),state_probabilities=p.tolist(),
           perfect_initial_marginals=u.tolist(),static_two_checks_expected_recovery=static,
           adaptive_two_checks_expected_recovery=adaptive,
           policy='query0; if y0=1 query2, else query3',
           conclusion='Perfect initial marginal probabilities do not remove value of dependent-label feedback.'),
       probability_scope='The bound in the manuscript uses conditional probabilities at each action history; it does not infer them from saved scores or Brier loss.',
       empirical_score_cost_not_recovery_guarantee=True)
    (HERE/'checks/certificate_price.json').write_text(json.dumps(check,indent=2)+'\n')
    print(summary[summary.budget.eq(8)].to_string(index=False));print(json.dumps(check,indent=2))

if __name__=='__main__':main()
