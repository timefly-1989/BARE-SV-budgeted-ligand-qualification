"""Exact prospective sign-test power sensitivity; no observed-power claim."""
from pathlib import Path
import json,math,tarfile
import numpy as np,pandas as pd
from scipy.stats import binom
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]

def conditional_power(max_n,w,alpha=.025):
    m=np.arange(max_n+1)
    # Reject both tails of the exact fair-sign binomial, without mid-p values.
    k=binom.ppf(alpha/2,m,.5).astype(int)
    k=np.where(binom.cdf(k,m,.5)<=alpha/2+1e-15,k,k-1)
    p=binom.cdf(k,m,w)+binom.sf(m-k-1,m,w)
    p[0]=0
    return np.minimum(p,1.)

def power(n,discordance,cp):
    m=np.arange(n+1)
    return float(binom.pmf(m,n,discordance)@cp[:n+1])

def required(d,w,target=.8,maximum=20000):
    cp=conditional_power(maximum,w)
    if power(maximum,d,cp)<target:return None
    # Exact tests have lattice oscillations; report first grid-independent
    # integer crossing, not a continuous normal approximation or smooth root.
    normal_rough=((2.24+.842)**2)/max(d*(2*w-1)**2,1e-10)
    lower=max(1,int(normal_rough*.25));upper=min(maximum,int(normal_rough*2)+100)
    while upper<maximum and power(upper,d,cp)<target: upper=min(maximum,upper*2)
    for n in range(lower,upper+1):
        v=power(n,d,cp)
        if v>=target:
            # Check the skipped prefix explicitly, preserving exactness.
            for k in range(1,lower):
                z=power(k,d,cp)
                if z>=target:return k,z
            return n,v
    return None

def main():
    rows=[]
    for d in [.1,.25,.5,1.]:
        for w in [.6,.65,.7,.8]:
            r=required(d,w)
            cp=conditional_power(20000,w)
            rows.append(dict(discordance_probability=d,win_given_nonzero=w,planning_alpha=.025,target_power=.8,
                independent_units_for_first_80pct_crossing=r[0] if r else None,
                exact_power_at_crossing=r[1] if r else None,
                expected_nonzero_at_crossing=d*r[0] if r else None,
                power_with_50_independent_units=power(50,d,cp),
                power_with_100_independent_units=power(100,d,cp)))
    pd.DataFrame(rows).to_csv(HERE/'results/exact_sign_power.csv',index=False)
    sensitivity=[]
    for m in [1,3,4,7,10,20,30,50,80,100]:
        for w in [.6,.7,.8,1.]:
            cp=conditional_power(m,w)
            sensitivity.append(dict(nonzero_pairs=m,win_probability=w,power=float(cp[m]),minimum_two_sided_p=2.**(1-m)))
    pd.DataFrame(sensitivity).to_csv(HERE/'results/nonzero_sign_power.csv',index=False)
    prev=ROOT/'experiments/36_external_activity_benchmark_20261027'
    with tarfile.open(prev/'raw/AVE_unbiased.tgz') as z:
        assays=sorted({n.split('/')[0] for n in z.getnames() if n.endswith('active_V.smi')})
    used=json.loads((prev/'protocol_addendum.json').read_text())['assays']
    metadata=json.loads((ROOT/'experiments/46_stage_calibration_upgrade_20261027/sources/fsmol_metadata.json').read_text())
    status=dict(official_LIT_PCBA_assays=len(assays),previously_evaluated=used,not_evaluated=sorted(set(assays)-set(used)),
       unused_assay_labels_scored_here=False,FS_Mol_official_split={'train':4938,'valid':40,'test':157},
       FS_Mol_data_bytes=metadata['files'][0]['size'],FS_Mol_DOI=metadata['doi'],
       biological_independence_not_certified=True,
       why_not_count_157_as_independent='Assay separation does not establish independent targets/families, and shared compound panels induce dependence.',
       complete_dual_context_validation=False,
       acquisition_decision='No new qualification acquisition after both development promotion gates failed; retain unused activity outcomes for a later frozen mechanism.',
       test_design='Fixed per-pool quota comparisons use source/target-family groups; global allocation comparisons require independent complete campaigns, not treating coupled pocket recoveries as independent replicates.',
       assumptions='Unit differences independent; M~Binomial(N,d), wins|M~Binomial(M,w); d,w are planning assumptions, not estimates of future efficacy.',
       min_nonzero_at_two_sided_alpha_025=7,
       examples=[r for r in rows if r['discordance_probability']==.5 and r['win_given_nonzero'] in [.7,.8]])
    (HERE/'results/next_data_and_design.json').write_text(json.dumps(status,indent=2)+'\n')
    # Exact calibration of the rejection region under the fair-sign null.
    cp=conditional_power(250,.5)
    assert np.max(cp)<=.025+1e-12
    assert np.all(conditional_power(6,1.)==0)
    assert conditional_power(7,1.)[-1]==1
    (HERE/'checks/power_checks.json').write_text(json.dumps(dict(exact_null_size_max=float(cp.max()),
       max_nonzero_six_never_rejects=True,seven_all_wins_rejects=True,
       binomial_mixture_normalized=bool(np.allclose(binom.pmf(np.arange(101),100,.25).sum(),1))),indent=2)+'\n')
    print(pd.DataFrame(rows).to_string(index=False));print(json.dumps(status,indent=2))

if __name__=='__main__': main()
