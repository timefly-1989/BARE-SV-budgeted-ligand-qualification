"""Replay and causality checks for the two added development screens."""
from pathlib import Path
import importlib.util,itertools,json
import numpy as np,pandas as pd
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1];EX=ROOT/'experiments'
spec=importlib.util.spec_from_file_location('kernel47',EX/'47_stage_kernel_feedback_20261027/run_kernel.py')
k=importlib.util.module_from_spec(spec);spec.loader.exec_module(k)

def main():
    count=0
    for folder in ['46_stage_calibration_upgrade_20261027','47_stage_kernel_feedback_20261027']:
        p=EX/folder
        for rel,h in json.loads((p/'checks'/('screen_freeze.json' if folder.startswith('46') else 'implementation_freeze.json')).read_text()).items():
            source=Path(rel)
            if folder.startswith('47') and source.name=='run_kernel.py':source=p/'checks/run_kernel_scored.py'
            assert k.prior.sha(source)==h;count+=1
        r=json.loads((p/'results/promotion.json').read_text());assert not r['passed'];count+=1
    f=pd.DataFrame(dict(pocket_id=['A','A','A','B','B','B'],candidate_id=list('abcdef'),reference_success=1))
    p=np.array([[.8,.5],[.7,.6],[.5,.8],[.9,.2],[.3,.8],[.6,.3]])
    sim=np.array([[1,.8,.2,.1,.2,.3],[.8,1,.3,.2,.1,.2],[.2,.3,1,.4,.2,.1],
                  [.1,.2,.4,1,.8,.6],[.2,.1,.2,.8,1,.7],[.3,.2,.1,.6,.7,1]])
    # Every binary joint table consistent with D=1 is replayed. A second policy
    # with the same observed transcript must select the same next action.
    for labels in itertools.product([0,1],repeat=6):
        for mode in ['stage','joint']:
            a=k.Policy(f,p,sim,mode,1,2);b=k.Policy(f,p,sim,mode,1,2)
            for _ in range(4):
                i=a.action();assert i==b.action()
                feedback=dict(y=labels[i]) if mode=='joint' else dict(D=1,R=labels[i])
                a.observe(i,**feedback);b.observe(i,**feedback);count+=1
    a=k.Policy(f,p,sim,'stage',1,2)
    before=a.n[:,1].copy(),a.den[:,1].copy()
    a.observe(0,D=0,R=None)
    assert np.array_equal(before[0],a.n[:,1]) and np.array_equal(before[1],a.den[:,1]);count+=1
    try:a.observe(1,D=0,R=0)
    except AssertionError:count+=1
    else:raise AssertionError('Route-failed downstream pseudo-label accepted')
    logs=pd.read_csv(EX/'47_stage_kernel_feedback_20261027/results/selected_feedback.csv')
    assert logs.loc[logs.D.eq(0),'R'].isna().all();count+=1
    assert not logs.duplicated(['method','fold','budget','pocket_id','candidate_id']).any();count+=1
    for (_,_,_),g in logs.groupby(['method','fold','budget']):
        assert np.array_equal(g.t.to_numpy(),np.arange(1,len(g)+1))
        assert np.array_equal(g.C.to_numpy(),g.y.cumsum().to_numpy());count+=2
    (HERE/'checks/new_mechanism_checks.json').write_text(json.dumps(dict(status='PASS',checks=count,
       labels_owned_by_evaluator=True,route_failed_R_remains_missing=True,duplicate_queries=False),indent=2)+'\n')
    print('PASS',count,'mechanism checks')

if __name__=='__main__':main()
