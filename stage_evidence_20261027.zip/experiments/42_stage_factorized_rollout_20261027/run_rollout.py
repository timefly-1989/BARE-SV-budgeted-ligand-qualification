"""Nested empirical-Bayes priors and stage-factorized global one-step rollout."""
import os
for key in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','VECLIB_MAXIMUM_THREADS']:os.environ[key]='1'
from pathlib import Path
import copy,hashlib,importlib.util,json,time
import numpy as np,pandas as pd
from scipy.special import expit,logit,logsumexp
from scipy.optimize import minimize
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1];EX=ROOT/'experiments'
spec=importlib.util.spec_from_file_location('s38',EX/'38_stage_posterior_allocation_20261027/run_screen.py');screen=importlib.util.module_from_spec(spec);spec.loader.exec_module(screen)
KEYS=['pocket_id','candidate_id'];NODES=21
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(p,j):p.write_text(json.dumps(j,indent=2,allow_nan=False)+'\n')
def normal_grid(mu,sd):
    x,w=np.polynomial.hermite.hermgauss(NODES);return mu+np.sqrt(2)*sd*x,w/np.sqrt(np.pi)
def outer_training(d,f):
    q=d[d.fold.eq(f)];scaf=set(q.scaffold.dropna())-{''}
    return np.flatnonzero(~d.fold.eq(f)&~d.smiles.isin(q.smiles)&~d.scaffold.isin(scaf))
def inner_probabilities(d,f):
    a=outer_training(d,f);pD=np.full((len(d),2),np.nan);pR=pD.copy();deps={}
    for inner in range(5):
        if inner==f:continue
        excluded=sorted([f,inner]);path=EX/'17_stage_evidence_20261025/cache'/('exclude_'+'_'.join(map(str,excluded))+'.npz');c=np.load(path)
        query=np.flatnonzero(d.fold.isin(excluded));assert np.array_equal(c['query'],query)
        assert not d.iloc[c['train']].fold.isin(excluded).any()
        qf=d.iloc[query];scaf=set(qf.scaffold.dropna())-{''}
        expected=np.flatnonzero(~d.fold.isin(excluded)&~d.smiles.isin(qf.smiles)&~d.scaffold.isin(scaf))
        assert np.array_equal(c['train'],expected)
        take=a[d.fold.to_numpy()[a]==inner];positions=pd.Index(query).get_indexer(take);assert (positions>=0).all()
        pD[take]=c['pD'][positions][:,[1,0]];pR[take]=c['pR'][positions][:,[1,0]];deps[str(path.relative_to(ROOT))]=sha(path)
    assert np.isfinite(pD[a]).all() and np.isfinite(pR[a]).all();return a,pD[a],pR[a],deps
def fit_prior(prob,labels,groups):
    logits=logit(np.clip(prob,1e-6,1-1e-6));parts=[np.flatnonzero(groups==g) for g in np.unique(groups)];x,w=normal_grid(0,1);lw=np.log(w)
    def objective(theta):
        mu,logsigma=theta;linear=logits[:,None]+mu+np.exp(logsigma)*x
        lp=labels[:,None]*(-np.logaddexp(0,-linear))+(1-labels[:,None])*(-np.logaddexp(0,linear))
        return -sum(logsumexp(lw+lp[ix].sum(0)) for ix in parts)+(mu*mu+logsigma*logsigma)/8
    fits=[minimize(objective,[0,np.log(s)],method='L-BFGS-B',bounds=[(-6,6),(-3,2)],options={'maxiter':150,'ftol':1e-10}) for s in [.5,1,2]]
    best=min(fits,key=lambda v:v.fun);assert np.isfinite(best.fun)
    return dict(mu=float(best.x[0]),sigma=float(np.exp(best.x[1])),objective=float(best.fun),rows=len(prob),positives=int(labels.sum()),pools=len(parts),optimizer_success=bool(best.success),message=str(best.message))
def priors():
    d=pd.read_csv(EX/'01_development84/data/development_manifest.csv');rows={};deps={}
    for f in range(5):
        a,D,R,source=inner_probabilities(d,f);deps.update(source);frame=d.iloc[a];passed=frame.D.eq(1).to_numpy()
        for column,base in enumerate(['chemeleon','morgan']):
            path=HERE/'cache'/f'prior_fold{f}_{base}.json'
            input_hash=hashlib.sha256(b''.join(v.tobytes() for v in [a,D[:,column],R[:,column],frame.D.to_numpy(),frame.y.to_numpy()])).hexdigest()
            if path.exists():value=json.loads(path.read_text());assert value['input_signature']==input_hash
            else:
                value=dict(input_signature=input_hash,outer_fold=f,base=base,train_index=a.tolist(),
                    D=fit_prior(D[:,column],frame.D.to_numpy(int),frame.pocket_id.to_numpy()),
                    R=fit_prior(R[passed,column],frame.y.to_numpy(int)[passed],frame.pocket_id.to_numpy()[passed]),outer_labels_used=False)
                save(path,value)
            rows[(f,base)]=value;print('PRIOR',f,base,value['D']['mu'],value['D']['sigma'],value['R']['mu'],value['R']['sigma'],flush=True)
    save(HERE/'checks/inner_source_hashes.json',deps);return rows
class Belief:
    def __init__(self,D,R,reference,parameters,feedback):
        gD,w=normal_grid(parameters['D']['mu'],parameters['D']['sigma']);gR,_=normal_grid(parameters['R']['mu'],parameters['R']['sigma'])
        self.D=expit(logit(np.clip(D,1e-6,1-1e-6))[:,None]+gD);self.R=expit(logit(np.clip(R,1e-6,1-1e-6))[:,None]+gR)*reference[:,None]
        self.wD=w.copy();self.wR=w.copy();self.W=np.outer(w,w);self.feedback=feedback
    def predict(self):
        if self.feedback=='joint':return np.sum((self.D@self.W)*self.R,axis=1)
        return (self.D@self.wD)*(self.R@self.wR)
    def reveal(self,a,outcome):
        if self.feedback=='joint':
            p=np.outer(self.D[a],self.R[a]);self.W*=p if outcome else 1-p;self.W/=self.W.sum()
        else:
            D,R=outcome;assert D or R is None
            self.wD*=self.D[a] if D else 1-self.D[a];self.wD/=self.wD.sum()
            if D:self.wR*=self.R[a] if R else 1-self.R[a];self.wR/=self.wR.sum()
    def possible_updates(self,ix):
        d=self.D[ix];r=self.R[ix]
        if self.feedback=='joint':
            feature=(d[:,:,None]*r[:,None,:]).reshape(len(ix),-1);w=self.W.ravel();mu=feature@w;second=(feature*w)@feature.T
            post1=np.divide(second,mu[:,None],out=np.zeros_like(second),where=mu[:,None]>1e-15)
            post0=np.divide(mu[None,:]-second,1-mu[:,None],out=np.zeros_like(second),where=(1-mu[:,None])>1e-15)
            return mu,np.stack([1-mu,mu],axis=1),[post0,post1]
        mD=d@self.wD;mR=r@self.wR;secondD=(d*self.wD)@d.T;secondR=(r*self.wR)@r.T
        d1=np.divide(secondD,mD[:,None],out=np.zeros_like(secondD),where=mD[:,None]>1e-15)
        d0=np.divide(mD[None,:]-secondD,1-mD[:,None],out=np.zeros_like(secondD),where=(1-mD[:,None])>1e-15)
        r1=np.divide(secondR,mR[:,None],out=np.zeros_like(secondR),where=mR[:,None]>1e-15)
        r0=np.divide(mR[None,:]-secondR,1-mR[:,None],out=np.zeros_like(secondR),where=(1-mR[:,None])>1e-15)
        return mD*mR,np.stack([1-mD,mD*(1-mR),mD*mR],axis=1),[d0*mR[None,:],d1*r0,d1*r1]
    def values(self,ix,outside,remaining):
        mu,probability,updates=self.possible_updates(ix)
        if remaining==1:return mu
        tmin=max(0,remaining-1-len(outside));tmax=min(len(ix)-1,remaining-1);counts=np.arange(tmin,tmax+1)
        outside_prefix=np.r_[0,np.cumsum(np.sort(outside)[::-1])];values=mu.copy()
        for state,updated in enumerate(updates):
            updated=np.clip(updated,0,1);np.fill_diagonal(updated,-np.inf)
            inside_prefix=np.c_[np.zeros(len(ix)),np.cumsum(np.sort(updated,axis=1)[:,::-1],axis=1)]
            future=np.max(inside_prefix[:,counts]+outside_prefix[remaining-1-counts][None,:],axis=1)
            values+=probability[:,state]*future
        return values
class Allocator:
    def __init__(self,predictions,base,parameters,feedback='stage',rollout=False,static=False,raw=False):
        assert not {'D','y','V','Q','VQ'}&set(predictions.columns)
        self.frame=predictions;self.feedback=feedback;self.rollout=rollout;self.static=static;self.active=np.ones(len(predictions),bool);self.score=np.empty(len(predictions));self.groups={};self.local=np.empty(len(predictions),int)
        for pid,g in predictions.groupby('pocket_id',sort=False):
            ix=g.index.to_numpy();self.local[ix]=np.arange(len(ix));b=Belief(g[base+'_D'].to_numpy(),g[base+'_R'].to_numpy(),g.reference_success.to_numpy(),parameters,feedback)
            self.groups[pid]=(ix,b);self.score[ix]=g[base+'_D']*g[base+'_R']*g.reference_success if raw else b.predict()
    def action(self,remaining):
        if not self.rollout:values=np.where(self.active,self.score,-np.inf)
        else:
            values=np.full(len(self.frame),-np.inf)
            for pid,(indices,b) in self.groups.items():
                inside=indices[self.active[indices]]
                if not len(inside):continue
                outside=self.active.copy();outside[indices]=False
                values[inside]=b.values(self.local[inside],self.score[outside],remaining)
        maximum=values.max();tolerance=1e-10*max(1,abs(maximum));return int(np.flatnonzero(values>=maximum-tolerance)[0]),float(maximum)
    def reveal(self,index,observation):
        assert self.active[index];self.active[index]=False
        if not self.static:
            pid=self.frame.pocket_id.iloc[index];ix,b=self.groups[pid];b.reveal(self.local[index],observation);self.score[ix]=b.predict()
def algebra_checks():
    rng=np.random.default_rng(42);cases=0
    parameter={'D':{'mu':-.2,'sigma':1.2},'R':{'mu':.1,'sigma':.8}}
    for n in [3,7]:
        D=rng.uniform(.05,.95,n);R=rng.uniform(.05,.95,n);reference=np.ones(n);outside=np.array([.1,.3]);ix=np.arange(n)
        b=Belief(D,R,reference,parameter,'stage');j=Belief(D,R,reference,parameter,'joint')
        for k in [1,2,n+len(outside)]:
            fast=b.values(ix,outside,k);joint=j.values(ix,outside,k);slow=[]
            mu,prob,states=b.possible_updates(ix)
            for a in ix:
                total=mu[a]
                for state,observation in enumerate([(0,None),(1,0),(1,1)]):
                    changed=copy.deepcopy(b);changed.reveal(a,observation);p=changed.predict();p[a]=-np.inf
                    total+=prob[a,state]*np.sort(np.r_[outside,p])[-(k-1):].sum() if k>1 else 0
                slow.append(total)
            assert np.allclose(fast,slow,atol=1e-10) and (fast+1e-10>=joint).all()
            baseline=np.sort(np.r_[outside,b.predict()])[-k:].sum();assert fast.max()+1e-10>=baseline
            if k==n+len(outside):assert np.ptp(fast)<1e-10
            cases+=1
    save(HERE/'checks/rollout_algebra.json',dict(status='PASS',cases=cases,sorted_merge_matches_brute_posterior=True,stage_information_value_ge_joint_same_belief=True,max_rollout_value_ge_fixed_completion=True,guarantee_scope='Specified discrete latent model only, not empirical recovery'))
def run():
    algebra_checks();fitted=priors();z=screen.inputs();rows=[];traces=[];start=time.perf_counter()
    methods={'raw_pooling':dict(static=True,raw=True),'prior_static':dict(static=True),'stage_greedy':{},'joint_greedy':dict(feedback='joint'),'stage_rollout':dict(rollout=True),'joint_rollout':dict(feedback='joint',rollout=True)}
    for fold,g in z.groupby('fold'):
        g=g.sort_values(KEYS).reset_index(drop=True);J=g.pocket_id.nunique();pred=g.drop(columns=['D','y','sa_score'])
        for base in ['chemeleon','morgan']:
            for method,options in methods.items():
                t=time.perf_counter();policy=Allocator(pred,base,fitted[(fold,base)],**options);chosen=[]
                for step in range(1,J+1):
                    a,value=policy.action(J-step+1);r=g.iloc[a];prediction=float(policy.score[a]);chosen.append(a)
                    observation=int(r.y) if policy.feedback=='joint' else (int(r.D),int(r.y) if r.D else None)
                    policy.reveal(a,observation)
                    traces.append(dict(fold=fold,base=base,method=method,step=step,pocket_id=r.pocket_id,candidate_id=r.candidate_id,D=int(r.D),y=int(r.y),predicted_probability=prediction,action_value=value))
                selected=g.iloc[chosen];row=dict(fold=fold,base=base,method=method,K=J,C=int(selected.y.sum()),coverage=int(selected.groupby('pocket_id').y.sum().gt(0).sum()),seconds=time.perf_counter()-t)
                rows.append(row);print('CAMPAIGN',row,flush=True)
    per=pd.DataFrame(rows);per.to_csv(HERE/'results/rollout_campaigns.csv',index=False);pd.DataFrame(traces).to_csv(HERE/'results/rollout_actions.csv',index=False)
    summary=per.groupby(['base','method'],sort=False).agg(C=('C','sum'),coverage=('coverage','sum'),K=('K','sum'),seconds=('seconds','sum')).reset_index();summary.to_csv(HERE/'results/rollout_summary.csv',index=False)
    controls=pd.read_csv(EX/'40_stage_state_context_20261027/results/state_global_summary.csv');controls=controls[controls.budget_per_pool.eq(1)&~controls.method.str.endswith('_state')];best=int(controls.C.max())
    s=summary[summary.base.eq('chemeleon')].set_index('method');wide=per[per.base.eq('chemeleon')].pivot(index='fold',columns='method',values='C');delta=wide.stage_rollout-wide.raw_pooling
    passed=bool(s.loc['stage_rollout','C']>=best+5 and s.loc['stage_rollout','C']>=s.loc['prior_static','C']+2 and s.loc['stage_rollout','C']>s.loc['stage_greedy','C'] and s.loc['stage_rollout','C']>s.loc['joint_rollout','C'] and (delta>0).sum()>=3 and s.loc['stage_rollout','coverage']>=s.loc['raw_pooling','coverage'])
    record=dict(status='COMPLETE',primary_C=int(s.loc['stage_rollout','C']),best_fixed_C=best,prior_static_C=int(s.loc['prior_static','C']),stage_greedy_C=int(s.loc['stage_greedy','C']),joint_rollout_C=int(s.loc['joint_rollout','C']),coverage=int(s.loc['stage_rollout','coverage']),by_fold_C_vs_raw={str(k):int(v) for k,v in delta.items()},promotion_gate_pass=passed,independent_test=False,new_chemical_endpoints=0,wall_seconds=time.perf_counter()-start)
    save(HERE/'results/rollout_decision.json',record);print(summary.to_string(index=False));print(json.dumps(record),flush=True)
if __name__=='__main__':run()
