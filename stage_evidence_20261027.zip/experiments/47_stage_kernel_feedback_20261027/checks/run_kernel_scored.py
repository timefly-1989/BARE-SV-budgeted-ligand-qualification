"""Nested development test of chemical-neighbour stage feedback.

The policy owns only covariates/predictions; an environment reveals a selected
route label and, only after a route pass, its downstream label. This is a
kernel pseudo-count smoother, not a claim of an exact Bayesian posterior.
"""
import os
for _n in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','VECLIB_MAXIMUM_THREADS']:
    os.environ[_n]='1'
from pathlib import Path
import hashlib,importlib.util,json,time
import numpy as np,pandas as pd
from scipy.sparse import csr_matrix
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1];EX=ROOT/'experiments'
spec=importlib.util.spec_from_file_location('stage_calibration46',EX/'46_stage_calibration_upgrade_20261027/run_calibration.py')
prior=importlib.util.module_from_spec(spec);spec.loader.exec_module(prior)

def save(p,x):Path(p).write_text(json.dumps(x,indent=2,allow_nan=False)+'\n')
def kernel(fp):
    x=csr_matrix(fp.astype(np.float32));dot=(x@x.T).toarray();n=np.asarray(x.sum(1)).ravel()
    return np.divide(dot,n[:,None]+n[None,:]-dot,out=np.zeros_like(dot),where=(n[:,None]+n[None,:]-dot)>0)

class Policy:
    def __init__(self,inputs,prob,sim,mode,tau,power):
        assert not {'D','y','VQ','V','Q'}&set(inputs.columns)
        self.p=prob.copy();self.n=tau*prob.copy();self.den=np.full_like(prob,tau)
        self.K=np.power(sim,power)
        group=inputs.pocket_id.to_numpy();self.local=(group[:,None]==group[None,:])
        self.ref=inputs.reference_success.to_numpy(float);self.mode=mode
        self.available=np.ones(len(inputs),bool)
        self.nY=tau*prob.prod(1);self.denY=np.full(len(inputs),tau)
        self.ident=np.lexsort((inputs.candidate_id.to_numpy(),group));self.tie=np.argsort(self.ident)
    def action(self):
        p=self.n/self.den
        u=(self.nY/self.denY if self.mode=='joint' else p.prod(1))*self.ref
        u[~self.available]=-np.inf
        return int(np.lexsort((self.tie,-u))[0])
    def observe(self,i,**feedback):
        assert self.available[i];self.available[i]=False
        if self.mode=='joint':
            assert set(feedback)=={'y'}
            w=self.K[:,i]*self.local[:,i]
            self.nY+=w*feedback['y'];self.denY+=w
        else:
            assert set(feedback)=={'D','R'} and (feedback['D']==1 or feedback['R'] is None)
            w=self.K[:,i]
            self.n[:,0]+=w*feedback['D'];self.den[:,0]+=w
            if feedback['D']:
                w=w*self.local[:,i]
                self.n[:,1]+=w*feedback['R'];self.den[:,1]+=w

def episode(frame,p,sim,mode,tau,power,budget,log=False):
    # Private evaluator; no unselected labels are passed to Policy.
    inputs=frame[['pocket_id','candidate_id','reference_success']].reset_index(drop=True)
    pol=Policy(inputs,p,sim,mode,tau,power)
    labels=frame[['D','y']].to_numpy(int)
    K=sum(min(budget,len(g)) for _,g in frame.groupby('pocket_id',sort=False))
    rows=[];C=0;covered=set()
    for t in range(K):
        i=pol.action();D,y=map(int,labels[i]);C+=y
        if y:covered.add(inputs.pocket_id.iloc[i])
        if mode=='joint':pol.observe(i,y=y)
        else:pol.observe(i,D=D,R=y if D else None)
        if log:rows.append(dict(t=t+1,index=i,pocket_id=inputs.pocket_id.iloc[i],candidate_id=inputs.candidate_id.iloc[i],D=D,
                                R=y if D else None,y=y,C=C,Cov=len(covered)))
    return dict(C=C,Cov=len(covered),K=K),rows

def main():
    start=time.perf_counter();d,fp,_=prior.common.load_development()
    protocol=json.loads((HERE/'protocol.json').read_text());assert protocol['primary_mode']=='stage'
    grid=[(t,p) for t in [.25,1.,4.] for p in [2,4]]
    choices=[];res=[];logs=[];inner=[];audits=[]
    for outer in range(5):
        eligible,_=prior.common.isolated_indices(d,(outer,))
        banks=[]
        for infold in range(5):
            if infold==outer:continue
            context,q,p=prior.base(tuple(sorted([outer,infold])),d)
            keep=np.isin(q,eligible)&d.fold.to_numpy()[q].__eq__(infold)
            qi=q[keep];frame=d.iloc[qi].reset_index(drop=True)
            banks.append((frame,p[keep],kernel(fp[qi])))
            audits.append(dict(outer=outer,inner=infold,context_rows=len(context),query_rows=len(qi),outer_outcomes_used=False))
        for mode in ['stage','joint']:
            criterion={}
            for tau,power in grid:
                summaries=[episode(f,p,k,mode,tau,power,1)[0] for f,p,k in banks]
                c=sum(v['C'] for v in summaries);cov=sum(v['Cov'] for v in summaries)
                criterion[(tau,power)]=(c,cov)
                inner.append(dict(outer=outer,mode=mode,tau=tau,power=power,C=c,Cov=cov))
            # Fixed stable grid order resolves ties, without outer labels.
            best=max(grid,key=lambda c:criterion[c]);tau,power=best
            choices.append(dict(outer=outer,mode=mode,tau=tau,power=power,inner_C=criterion[best][0]))
            _,q,p=prior.base((outer,),d);f=d.iloc[q].reset_index(drop=True);k=kernel(fp[q])
            for B in [1,2,4,8,16,32]:
                m,step=episode(f,p,k,mode,tau,power,B,log=True)
                res.append(dict(method='kernel_'+mode,fold=outer,budget=B,**m))
                for row in step:logs.append(dict(method='kernel_'+mode,fold=outer,budget=B,**row))
            print('FOLD',outer,mode,'tau,power',best,flush=True)
    prior_results=pd.read_csv(EX/'46_stage_calibration_upgrade_20261027/results/fold_results.csv')
    fixed=prior_results[prior_results.policy.eq('global')].drop(columns='policy')
    result=pd.concat([pd.DataFrame(res),fixed],ignore_index=True)
    result.to_csv(HERE/'results/fold_results.csv',index=False)
    summary=result.groupby(['method','budget'],sort=False)[['K','C','Cov']].sum().reset_index()
    summary.to_csv(HERE/'results/summary.csv',index=False)
    pd.DataFrame(logs).to_csv(HERE/'results/selected_feedback.csv',index=False)
    pd.DataFrame(inner).to_csv(HERE/'results/inner_selection.csv',index=False)
    save(HERE/'checks/nesting.json',audits);save(HERE/'checks/selected_hyperparameters.json',choices)
    p=result[result.budget.eq(1)]
    totals=p.groupby('method').C.sum()
    controls=[k for k in totals.index if k not in ['kernel_stage']]
    best=max(controls,key=lambda k:totals[k]);a=p[p.method.eq('kernel_stage')].set_index('fold');b=p[p.method.eq(best)].set_index('fold')
    delta=a.C-b.C
    passed=totals['kernel_stage']>=totals[best]+5 and delta.gt(0).sum()>=3 and a.Cov.sum()>=b.Cov.sum()-1
    decision=dict(primary='global K equal to number of pockets per held-out fold',C=int(totals['kernel_stage']),control=best,
                  control_C=int(totals[best]),fold_differences=delta.to_dict(),passed=bool(passed),
                  secondary_budgets_not_used_for_selection=True,development_only=True,seconds=time.perf_counter()-start)
    save(HERE/'results/promotion.json',decision)
    print(summary.to_string(index=False));print('PROMOTION',decision)

if __name__=='__main__':main()
