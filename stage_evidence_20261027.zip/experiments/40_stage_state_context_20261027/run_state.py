"""Matched state-label contextual inference on grouped development queries."""
import os
for name in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','VECLIB_MAXIMUM_THREADS']:os.environ[name]='1'
from pathlib import Path
import gc,hashlib,importlib.util,json,time
import numpy as np,pandas as pd,joblib,torch
from catboost import CatBoostClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import average_precision_score,brier_score_loss,roc_auc_score
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1];EX=ROOT/'experiments';torch.set_num_threads(4)
spec=importlib.util.spec_from_file_location('foundation40',EX/'16_molecular_foundation_20261025/run_foundation.py');f=importlib.util.module_from_spec(spec);spec.loader.exec_module(f)
common=f.common;KEYS=common.KEYS
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def signature(*arrays):return hashlib.sha256(b''.join(str((x.shape,x.dtype)).encode()+np.ascontiguousarray(x).tobytes() for x in arrays)).hexdigest()
def predict(x,y,q,tag):
    path=HERE/'cache'/(tag+'.npz');sig=signature(x,y,q)
    if path.exists():
        a=np.load(path);assert str(a['signature'])==sig;return a['values'],float(a['seconds'])
    from tabicl import TabICLClassifier
    params=json.loads((EX/'16_molecular_foundation_20261025/tabicl_params.json').read_text());params.update(random_state=11,model_path=str(f.CHECKPOINT))
    start=time.perf_counter();model=TabICLClassifier(**params);model.fit(x,y);p=model.predict_proba(q)
    p=p[:,[list(model.classes_).index(k) for k in [0,1,2]]];f.sync();seconds=time.perf_counter()-start
    assert np.allclose(p.sum(1),1,atol=1e-6) and np.isfinite(p).all()
    np.savez_compressed(path,values=p,signature=sig,seconds=seconds);del model;gc.collect();f.cleanup()
    print('PREDICT',tag,len(y),len(q),round(seconds,3),flush=True);return p,seconds
def run():
    d,fp,prior=common.load_development();raw=f.embeddings_for(d);labels=np.where(d.D.eq(0),0,np.where(d.y.eq(1),2,1)).astype(int)
    assert np.array_equal(labels==2,d.y.to_numpy(bool)) and np.array_equal(labels>0,d.D.to_numpy(bool))
    parts=[];timing=[];names=joblib.load(EX/'01_development84/models/full/preprocessing.joblib')['names'];assert len(names)==229
    clean=np.clip(np.nan_to_num(d[names].to_numpy(float),nan=0,posinf=0,neginf=0),-1e6,1e6)
    for fold in range(5):
        a,q=common.isolated_indices(d,[fold]);out=d.iloc[q][KEYS+['fold','cluster30','D','y','reference_success']].copy()
        for representation in ['chemeleon','morgan']:
            state=joblib.load(EX/'16_molecular_foundation_20261025/transforms'/f'fold{fold}_{representation}.joblib');assert np.array_equal(a,state['train_index'])
            if representation=='chemeleon':graph=state['transform'].transform(state['scaler'].transform(raw))
            else:graph=state['transform'].transform(fp)
            x=np.c_[common.clean(d),graph[:,:24],prior];assert x.shape==(4647,55)
            p,seconds=predict(x[a],labels[a],x[q],f'fold{fold}_{representation}_state')
            out[representation+'_state']=p[:,2]*out.reference_success.to_numpy()
            out[representation+'_state_D']=p[:,1]+p[:,2];out[representation+'_state_R']=np.divide(p[:,2],p[:,1]+p[:,2],out=np.zeros(len(q)),where=(p[:,1]+p[:,2])>0)
            timing.append(dict(fold=fold,model=representation+'_state',seconds=seconds,training_rows=len(a),query_rows=len(q)))
            if representation=='morgan':large=np.c_[clean,graph,prior]
        assert large.shape==(4647,279)
        for modeltype,seeds in [('catboost',[11,23]),('rf',[11,23,37])]:
            allp=[]
            for seed in seeds:
                path=HERE/'cache'/f'fold{fold}_{modeltype}_{seed}.npz';sig=signature(large[a],labels[a],large[q])
                if path.exists():cache=np.load(path);assert str(cache['signature'])==sig;p=cache['values'];seconds=float(cache['seconds'])
                else:
                    start=time.perf_counter()
                    if modeltype=='catboost':model=CatBoostClassifier(iterations=250,depth=4,learning_rate=.05,l2_leaf_reg=10,loss_function='MultiClass',thread_count=4,random_seed=seed,verbose=False,allow_writing_files=False)
                    else:model=RandomForestClassifier(n_estimators=500,min_samples_leaf=2,max_features='sqrt',class_weight='balanced_subsample',n_jobs=4,random_state=seed)
                    model.fit(large[a],labels[a]);p=model.predict_proba(large[q])[:,[list(model.classes_).index(k) for k in [0,1,2]]];seconds=time.perf_counter()-start
                    np.savez_compressed(path,values=p,signature=sig,seconds=seconds)
                allp.append(p);timing.append(dict(fold=fold,model=modeltype+'_state',seed=seed,seconds=seconds,training_rows=len(a),query_rows=len(q)))
            out[modeltype+'_state']=np.mean(allp,axis=0)[:,2]*out.reference_success.to_numpy()
        parts.append(out);print('FOLD_COMPLETE',fold,flush=True)
    z=pd.concat(parts,ignore_index=True);old=pd.read_csv(EX/'35_stage_evidence_upgrade_20261027/results/analysis_scores.csv');old=old[old.cohort.eq('development')]
    fixed=['chemeleon_compact_qualification','chemeleon_conditional','chemeleon_direct','morgan_conditional','morgan_direct','strict_catboost_conditional','strict_catboost_joint','rf_joint','strict_CFE']
    z=z.merge(old[KEYS+fixed],on=KEYS,validate='one_to_one');z.to_csv(HERE/'results/state_scores.csv',index=False);pd.DataFrame(timing).to_csv(HERE/'results/timing.csv',index=False)
    per=[];globalrows=[];metrics=[]
    methods=[r+'_state' for r in ['chemeleon','morgan','catboost','rf']]+fixed
    for method in methods:
        for pid,g in z.groupby('pocket_id',sort=False):
            order=g.sort_values([method,'candidate_id'],ascending=[False,True]);P=int(g.y.sum())
            for b in [4,8,16,32]:
                C=int(order.head(b).y.sum());per.append(dict(method=method,pocket_id=pid,fold=int(g.fold.iloc[0]),budget=b,C=C,P=P,hit=int(C>0),recall=C/P if P else np.nan))
        for fold,g in z.groupby('fold'):
            J=g.pocket_id.nunique();ordered=g.sort_values([method,'pocket_id','candidate_id'],ascending=[False,True,True])
            for b in [1,4,8]:
                s=ordered.head(b*J);globalrows.append(dict(method=method,fold=fold,budget_per_pool=b,total_budget=b*J,C=int(s.y.sum()),coverage=int(s.groupby('pocket_id').y.sum().gt(0).sum())))
        metrics.append(dict(method=method,Brier=brier_score_loss(z.y,z[method]),AP=average_precision_score(z.y,z[method]),AUC=roc_auc_score(z.y,z[method])))
    per=pd.DataFrame(per);glob=pd.DataFrame(globalrows);per.to_csv(HERE/'results/state_per_pocket.csv',index=False);glob.to_csv(HERE/'results/state_global_campaigns.csv',index=False)
    summary=per.groupby(['method','budget']).agg(C=('C','sum'),coverage=('hit','sum'),macro_recall=('recall','mean')).reset_index();summary.to_csv(HERE/'results/state_uniform_summary.csv',index=False)
    gs=glob.groupby(['method','budget_per_pool']).agg(C=('C','sum'),coverage=('coverage','sum'),total_budget=('total_budget','sum')).reset_index();gs.to_csv(HERE/'results/state_global_summary.csv',index=False)
    pd.DataFrame(metrics).to_csv(HERE/'results/state_probability.csv',index=False)
    u=summary[summary.budget.eq(8)].set_index('method');u32=summary[summary.budget.eq(32)].set_index('method');g=gs[gs.budget_per_pool.eq(1)].set_index('method');bestu=int(u.loc[fixed].C.max());bestg=int(g.loc[fixed].C.max());best32=int(u32.loc[fixed].C.max())
    uf=per[per.budget.eq(8)].groupby(['fold','method']).C.sum().unstack();gf=glob[glob.budget_per_pool.eq(1)].pivot(index='fold',columns='method',values='C')
    du=uf.chemeleon_state-uf.morgan_conditional;dg=gf.chemeleon_state-gf.chemeleon_direct
    uniform=bool(u.loc['chemeleon_state','C']>=bestu+5 and (du>0).sum()>=3 and u32.loc['chemeleon_state','C']>=best32-1)
    global_pass=bool(g.loc['chemeleon_state','C']>=bestg+5 and (dg>0).sum()>=3 and g.loc['chemeleon_state','coverage']>=g.loc['chemeleon_direct','coverage'])
    result=dict(status='COMPLETE',uniform_C8=int(u.loc['chemeleon_state','C']),best_control_C8=bestu,uniform_gate_pass=uniform,global_C_J=int(g.loc['chemeleon_state','C']),best_pooled_control_C_J=bestg,global_gate_pass=global_pass,by_fold_uniform_vs_morgan={str(k):int(v) for k,v in du.items()},by_fold_global_vs_binaryjoint={str(k):int(v) for k,v in dg.items()},independent_test=False,new_chemical_endpoints=0)
    (HERE/'results/state_decision.json').write_text(json.dumps(result,indent=2)+'\n');print(summary.to_string(index=False));print(gs.to_string(index=False));print(json.dumps(result),flush=True)
if __name__=='__main__':run()
