"""Input-only target/source grouping, with no activity value use."""
from pathlib import Path
import json,hashlib,urllib.request,urllib.parse,datetime
import pandas as pd
HERE=Path(__file__).resolve().parent

def main():
    targets=[]
    for f in sorted((HERE/'sources').glob('target_[0-9]*.json')):
        if f.stem.endswith('_source'):continue
        targets.extend(json.loads(f.read_text())['targets'])
    comps=sorted({str(c['component_id']) for t in targets for c in t['target_components']})
    records=[]
    for off in range(0,len(comps),70):
        p=HERE/f'sources/target_components_{off}.json'
        url='https://www.ebi.ac.uk/chembl/api/data/target_component.json?'+urllib.parse.urlencode({'component_id__in':','.join(comps[off:off+70]),'limit':1000})
        if not p.exists():
            with urllib.request.urlopen(url,timeout=45) as r:b=r.read()
            p.write_bytes(b)
            p.with_name(p.stem+'_source.json').write_text(json.dumps(dict(url=url,retrieved_local=datetime.datetime.now().astimezone().isoformat(),
                sha256=hashlib.sha256(b).hexdigest()),indent=2)+'\n')
        records.extend(json.loads(p.read_text())['target_components'])
    byid={r['component_id']:r for r in records}
    table=pd.read_csv(HERE/'results/heldout_input_audit.csv').fillna('')
    seq=[];classes=[]
    for row in targets:
        cc=[byid[c['component_id']] for c in row['target_components']]
        sequences=[c.get('sequence') or '' for c in cc]
        seq.append(dict(target_chembl_id=row['target_chembl_id'],sequence_set_sha256=hashlib.sha256('|'.join(sorted(sequences)).encode()).hexdigest() if all(sequences) and sequences else ''))
        for c in cc:
            for cl in c['protein_classifications']:
                classes.append(dict(target_chembl_id=row['target_chembl_id'],accession=c['accession'],**cl))
    table=table.drop(columns='sequence_set_sha256').merge(pd.DataFrame(seq),on='target_chembl_id',validate='many_to_one')
    pd.DataFrame(classes).to_csv(HERE/'results/protein_class_metadata.csv',index=False)
    n=len(table);parent=list(range(n))
    def root(i):
        while parent[i]!=i: parent[i]=parent[parent[i]];i=parent[i]
        return i
    def join(a,b):
        a,b=root(a),root(b)
        if a!=b:parent[b]=a
    for col in ['document_chembl_id','input_panel_signature','sequence_set_sha256']:
        for value,idx in table.groupby(col).groups.items():
            if not value:continue
            indices=list(idx)
            for i in indices[1:]:join(indices[0],i)
    roots=sorted(set(root(i) for i in range(n)));names={r:'source_panel_group_'+str(j+1).zfill(3) for j,r in enumerate(roots)}
    table['source_panel_group']=[names[root(i)] for i in range(n)]
    table.to_csv(HERE/'results/heldout_input_audit.csv',index=False)
    groups=table.groupby('source_panel_group').agg(assays=('assay','size'),names=('assay',lambda x:'|'.join(x)),documents=('document_chembl_id','nunique')).reset_index()
    groups.to_csv(HERE/'results/provenance_groups.csv',index=False)
    p=HERE/'results/readiness.json';summary=json.loads(p.read_text())
    summary.update(distinct_exact_target_sequence_sets=int(table.loc[table.sequence_set_sha256.ne(''),'sequence_set_sha256'].nunique()),
                   target_sequences_missing=int(table.sequence_set_sha256.eq('').sum()),source_documents=int(table.document_chembl_id.nunique()),
                   source_panel_groups=len(groups),largest_source_panel_group_assays=int(groups.assays.max()),
                   grouping_rule='Connected components of same source document, identical canonical input panel or identical full target sequence set.',
                   group_independence='Conservative provenance groups, not certified independent biological families; partial panels, common scaffolds and homologous proteins may connect groups further.',
                   encoder_pretraining_overlap='Unknown; FS-Mol derives from ChEMBL and cannot be assumed disjoint from encoder pretraining.',
                   official_classification_endpoint='IC50/EC50 values binarized by assay median subject to fixed pXC ranges; official tasks select 30%-70% actives; not a naturally sparse HTS forward-screening population.',
                   fixed_biological_threshold_not_selected_or_evaluated_here=True)
    p.write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))

if __name__=='__main__':main()
