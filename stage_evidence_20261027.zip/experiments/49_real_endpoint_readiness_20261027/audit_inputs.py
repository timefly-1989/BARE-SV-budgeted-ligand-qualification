"""Input-only readiness audit of official FS-Mol held-out assays.

The reader projects SMILES/Assay_ID before any activity value is retained.
No activity distribution, model scores, hit counts or validation metrics are
computed. This is public experimental-activity data preparation, not a new
qualification experiment or independent performance claim.
"""
from pathlib import Path
from functools import lru_cache
import gzip,hashlib,json,tarfile,urllib.request,urllib.parse,datetime,time
import numpy as np,pandas as pd
from rdkit import Chem,RDLogger
from rdkit.Chem.Scaffolds import MurckoScaffold
HERE=Path(__file__).resolve().parent

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
@lru_cache(maxsize=150000)
def graph(s):
    m=Chem.MolFromSmiles(s)
    if m is None:return None
    for a in m.GetAtoms():a.SetAtomMapNum(0)
    m=Chem.RemoveHs(m)
    conn=Chem.MolToSmiles(m,isomericSmiles=False)
    return conn,MurckoScaffold.MurckoScaffoldSmiles(mol=m,includeChirality=False)

def batch(endpoint,field,values):
    records=[]
    for offset in range(0,len(values),70):
        v=values[offset:offset+70]
        url='https://www.ebi.ac.uk/chembl/api/data/'+endpoint+'.json?'+urllib.parse.urlencode({field+'__in':','.join(v),'limit':1000})
        dest=HERE/f'sources/{endpoint}_{offset}.json'
        if not dest.exists():
            last=None
            for attempt in range(3):
                try:
                    with urllib.request.urlopen(url,timeout=35) as r:body=r.read()
                    obj=json.loads(body);dest.write_bytes(body);break
                except Exception as e:last=e
            else:raise last
            (HERE/f'sources/{endpoint}_{offset}_source.json').write_text(json.dumps(dict(url=url,
                retrieved_local=datetime.datetime.now().astimezone().isoformat(),sha256=sha(dest)),indent=2)+'\n')
        obj=json.loads(dest.read_text());key='assays' if endpoint=='assay' else 'targets'
        records.extend(obj[key])
    return records

def main():
    start=time.perf_counter();RDLogger.DisableLog('rdApp.*')
    tasks=json.loads((HERE/'sources/fsmol_tasks.json').read_text());expected=set(tasks['test'])
    rows=[];members=[];counts=[]
    with tarfile.open(HERE/'raw/fsmol.tar') as z:
        selected=[m for m in z.getmembers() if '/test/' in m.name and m.isfile() and Path(m.name).name.split('.')[0] in expected]
        assert len(selected)==157
        for number,m in enumerate(sorted(selected,key=lambda m:m.name)):
            assay=Path(m.name).name.split('.')[0];n=invalid=0;keys=[]
            compressed=z.extractfile(m).read()
            members.append(dict(assay=assay,member=m.name,bytes=len(compressed),sha256=hashlib.sha256(compressed).hexdigest()))
            for n,line in enumerate(gzip.decompress(compressed).splitlines(),1):
                obj=json.loads(line)
                # Explicitly project inputs only; never store activity fields.
                s=obj['SMILES'];assert obj['Assay_ID']==assay
                g=graph(s)
                if g is None:invalid+=1;continue
                conn,scaf=g;h=hashlib.sha256(conn.encode()).hexdigest();keys.append(h)
                rows.append(dict(assay=assay,source_row=n,smiles=s,connectivity=conn,scaffold=scaf,graph_key=h))
            signature=hashlib.sha256('\n'.join(sorted(set(keys))).encode()).hexdigest()
            counts.append(dict(assay=assay,source_rows=n,invalid_graphs=invalid,input_graph_unique=len(set(keys)),
                               duplicate_connectivity_rows=len(keys)-len(set(keys)),input_panel_signature=signature))
            if number%25==0:print('INPUT',number+1,'of157',flush=True)
    frame=pd.DataFrame(rows);frame.to_csv(HERE/'data/test_inputs_only.csv',index=False)
    pd.DataFrame(members).to_csv(HERE/'sources/test_member_checksums.csv',index=False)
    assay_meta=batch('assay','assay_chembl_id',sorted(expected))
    meta=pd.DataFrame([dict(assay=o['assay_chembl_id'],target_chembl_id=o.get('target_chembl_id'),
             assay_type=o.get('assay_type'),confidence_score=o.get('confidence_score'),
             document_chembl_id=o.get('document_chembl_id'),description=o.get('description')) for o in assay_meta])
    assert set(meta.assay)==expected
    targets=batch('target','target_chembl_id',sorted(set(meta.target_chembl_id.dropna())))
    targetrows=[]
    for t in targets:
        components=t.get('target_components',[])
        seq=[o.get('sequence','') for o in components]
        targetrows.append(dict(target_chembl_id=t['target_chembl_id'],pref_name=t.get('pref_name'),
              target_type=t.get('target_type'),organism=t.get('organism'),component_count=len(components),
              sequence_set_sha256=hashlib.sha256('|'.join(sorted(seq)).encode()).hexdigest() if all(seq) and seq else '',
              accessions='|'.join(str(o.get('accession','')) for o in components)))
    targetframe=pd.DataFrame(targetrows)
    table=pd.DataFrame(counts).merge(meta,on='assay',validate='one_to_one').merge(targetframe,on='target_chembl_id',validate='many_to_one')
    table.to_csv(HERE/'results/heldout_input_audit.csv',index=False)
    # Assays sharing an entire input panel cannot be counted as unrelated
    # screening libraries, even when their protein identifiers differ.
    panel=table.groupby('input_panel_signature').agg(assays=('assay','size'),
                 names=('assay',lambda x:'|'.join(x)),rows=('input_graph_unique','first')).reset_index()
    panel.to_csv(HERE/'results/shared_input_panels.csv',index=False)
    summary=dict(status='INPUTS_PREPARED_ONLY',official_test_assays=len(table),input_records=len(frame),
       unique_connectivities=frame.graph_key.nunique(),distinct_target_ids=table.target_chembl_id.nunique(),
       distinct_exact_target_sequence_sets=table.loc[table.sequence_set_sha256.ne(''),'sequence_set_sha256'].nunique(),
       target_type_counts=table.target_type.value_counts().to_dict(),
       distinct_input_panels=table.input_panel_signature.nunique(),largest_identical_panel_assays=int(panel.assays.max()),
       assay_rows_with_duplicated_input_panel=int(table.input_panel_signature.duplicated(False).sum()),
       family_independence='Not certified; exact target or sequence distinction is weaker than protein-family separation.',
       labels_used_for_prediction_or_selection=False,experimental_activity_values_exported=False,
       activity_positive_pools_not_counted=True,qualification_DVQ_labels_not_acquired=True,
       method_tested=False,primary_comparator_not_selected_from_test=True,
       current_ChEMBL_metadata_not_assumed_identical_to_ChEMBL27=True,
       source_checksum='Official entire-archive MD5 verified in sources/acquisition.json',seconds=time.perf_counter()-start)
    (HERE/'results/readiness.json').write_text(json.dumps(summary,indent=2)+'\n')
    print(json.dumps(summary,indent=2),flush=True)

if __name__=='__main__':main()
