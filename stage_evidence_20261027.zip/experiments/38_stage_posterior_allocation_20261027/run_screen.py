"""Development-only, no-fitting screen of stage-factorized global allocation.

The policy stores predictions and beliefs; only the environment owns outcomes.
"""
import os
for name in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','VECLIB_MAXIMUM_THREADS']:os.environ[name]='1'
from pathlib import Path
import hashlib,json,time
import numpy as np,pandas as pd
from scipy.special import expit,logit
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1];EX=ROOT/'experiments'
BASES=['chemeleon','morgan','catboost'];POLICIES=['raw_pooling','prior_static','joint_feedback','stage_feedback']
KEYS=['pocket_id','candidate_id'];BUDGETS=[4,8,16]
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(p,j):p.write_text(json.dumps(j,indent=2,allow_nan=False)+'\n')
def inputs():
    d=pd.read_csv(EX/'01_development84/data/development_manifest.csv');parts=[];deps=set()
    for fold in range(5):
        q=np.flatnonzero(d.fold.eq(fold));z=d.iloc[q][KEYS+['fold','cluster30','D','y','reference_success']].copy()
        for base in ['chemeleon','morgan']:
            for stage,label in [('D','route'),('R','downstream')]:
                p=EX/'16_molecular_foundation_20261025/cache'/f'fold{fold}_{base}_{label}_seed11.npz';deps.add(p);f=np.load(p)
                assert len(f['values'])==len(q);z[base+'_'+stage]=f['values']
        for stage,label in [('D','route'),('R','qualification')]:
            values=[]
            for seed in [11,23]:
                p=EX/'25_reconstruction_20261026/fair_control_cache'/f'fold{fold}_{label}_{seed}.npz';deps.add(p);f=np.load(p)
                assert np.array_equal(q,f['query']);values.append(f['values'])
            z['catboost_'+stage]=np.mean(values,axis=0)
        parts.append(z)
    z=pd.concat(parts,ignore_index=True)
    old=pd.read_csv(EX/'35_stage_evidence_upgrade_20261027/results/analysis_scores.csv');old=old[old.cohort.eq('development')]
    z=z.merge(old[KEYS+['chemeleon_compact_qualification','chemeleon_direct','chemeleon_conditional','morgan_conditional','strict_catboost_conditional','strict_catboost_joint','rf_joint','strict_CFE']],on=KEYS,validate='one_to_one')
    for base,field in [('chemeleon','chemeleon_conditional'),('morgan','morgan_conditional'),('catboost','strict_catboost_conditional')]:
        assert np.max(np.abs(z[base+'_D']*z[base+'_R']*z.reference_success-z[field]))<1e-12,base
    z=z.merge(d[KEYS+['sa_score']],on=KEYS,validate='one_to_one')
    z['historical_route_prior']=np.load(EX/'01_development84/data/development_prior.npy')[:,0][d.set_index(KEYS).index.get_indexer(pd.MultiIndex.from_frame(z[KEYS]))]
    z['SA']=-z.sa_score
    deps|={EX/'01_development84/data/development_manifest.csv',EX/'01_development84/data/development_prior.npy',EX/'35_stage_evidence_upgrade_20261027/results/analysis_scores.csv'}
    frozen=HERE/'checks/screen_inputs.json';record={str(p.relative_to(ROOT)):sha(p) for p in sorted(deps)}
    if frozen.exists():assert json.loads(frozen.read_text())==record
    else:save(frozen,record)
    return z
class PocketBelief:
    def __init__(self,D,R,reference,mode,nodes=21,sd=1.):
        grid,w=np.polynomial.hermite.hermgauss(nodes);offset=np.sqrt(2)*sd*grid;self.prior=w/np.sqrt(np.pi)
        self.D=expit(logit(np.clip(D,1e-6,1-1e-6))[:,None]+offset)
        self.R=expit(logit(np.clip(R,1e-6,1-1e-6))[:,None]+offset)*reference[:,None]
        self.wD=self.prior.copy();self.wR=self.prior.copy();self.W=np.outer(self.prior,self.prior);self.mode=mode
    def predict(self):
        if self.mode=='joint_feedback':return np.sum((self.D@self.W)*self.R,axis=1)
        return (self.D@self.wD)*(self.R@self.wR)
    def reveal_stage(self,index,D,R):
        assert self.mode=='stage_feedback' and (D or R is None)
        self.wD*=self.D[index] if D else 1-self.D[index];self.wD/=self.wD.sum()
        if D:
            self.wR*=self.R[index] if R else 1-self.R[index];self.wR/=self.wR.sum()
    def reveal_joint(self,index,y):
        assert self.mode=='joint_feedback';lik=np.outer(self.D[index],self.R[index]);self.W*=lik if y else 1-lik;self.W/=self.W.sum()
class Allocator:
    def __init__(self,predictions,base,mode):
        assert not {'D','y','V','Q','VQ'}&set(predictions.columns)
        self.data=predictions;self.mode=mode;self.base=base;self.active=np.ones(len(predictions),bool);self.scores=np.empty(len(predictions));self.pools={}
        self.local=np.empty(len(predictions),int)
        for pid,g in predictions.groupby('pocket_id',sort=False):
            ix=g.index.to_numpy();b=PocketBelief(g[base+'_D'].to_numpy(),g[base+'_R'].to_numpy(),g.reference_success.to_numpy(),mode)
            self.pools[pid]=(ix,b);self.local[ix]=np.arange(len(ix))
            self.scores[ix]=g[base+'_D'].to_numpy()*g[base+'_R'].to_numpy()*g.reference_success.to_numpy() if mode=='raw_pooling' else b.predict()
    def action(self):
        scores=np.where(self.active,self.scores,-np.inf);maximum=scores.max()
        return int(np.flatnonzero(scores>=maximum-1e-12)[0])
    def finish(self,index,D=None,R=None,y=None):
        assert self.active[index];self.active[index]=False
        pid=self.data.pocket_id.iloc[index];ix,b=self.pools[pid];local=self.local[index]
        if self.mode=='stage_feedback':b.reveal_stage(local,D,R)
        elif self.mode=='joint_feedback':b.reveal_joint(local,y)
        if self.mode.endswith('feedback'):self.scores[ix]=b.predict()
def screen():
    protocol=json.loads((HERE/'protocol.json').read_text());assert protocol['phase_A']['training'].startswith('No added fitting')
    z=inputs();all_results=[];traces=[];static=[];start=time.perf_counter()
    fixed=['chemeleon_compact_qualification','chemeleon_direct','chemeleon_conditional','morgan_conditional','strict_catboost_conditional','strict_catboost_joint','rf_joint','strict_CFE','historical_route_prior','SA']
    for fold,g in z.groupby('fold',sort=True):
        g=g.sort_values(KEYS).reset_index(drop=True);J=g.pocket_id.nunique();total=int(g.y.sum());positive=int(g.groupby('pocket_id').y.sum().gt(0).sum())
        for field in fixed:
            order=np.lexsort((g.candidate_id.to_numpy(str),g.pocket_id.to_numpy(str),-g[field].to_numpy()))
            for b in BUDGETS:
                s=g.iloc[order[:b*J]];static.append(dict(fold=fold,base=field,policy='fixed_pooling',budget_per_pool=b,total_budget=b*J,J=J,C=int(s.y.sum()),coverage=int(s.groupby('pocket_id').y.sum().gt(0).sum()),P=total,positive_pools=positive))
        predictions=g.drop(columns=['D','y','sa_score'])
        for base in BASES:
            for mode in POLICIES:
                policy=Allocator(predictions,base,mode);chosen=[];t=time.perf_counter()
                for step in range(1,16*J+1):
                    index=policy.action();row=g.iloc[index];predicted=float(policy.scores[index]);chosen.append(index)
                    D=int(row.D);y=int(row.y);R=y if D else None
                    if mode=='stage_feedback':policy.finish(index,D=D,R=R)
                    elif mode=='joint_feedback':policy.finish(index,y=y)
                    else:policy.finish(index)
                    traces.append(dict(fold=fold,base=base,policy=mode,step=step,pocket_id=row.pocket_id,candidate_id=row.candidate_id,D=D,R=R,y=y,predicted_probability=predicted))
                    if step in [b*J for b in BUDGETS]:
                        s=g.iloc[chosen];all_results.append(dict(fold=fold,base=base,policy=mode,budget_per_pool=step//J,total_budget=step,J=J,C=int(s.y.sum()),coverage=int(s.groupby('pocket_id').y.sum().gt(0).sum()),P=total,positive_pools=positive,decision_seconds=time.perf_counter()-t))
                print('CAMPAIGN',fold,base,mode,'complete',round(time.perf_counter()-t,3),flush=True)
    results=pd.concat([pd.DataFrame(all_results),pd.DataFrame(static)],ignore_index=True);results.to_csv(HERE/'results/screen_campaigns.csv',index=False)
    pd.DataFrame(traces).to_csv(HERE/'results/screen_actions.csv',index=False)
    summary=results.groupby(['base','policy','budget_per_pool'],sort=False).agg(C=('C','sum'),coverage=('coverage','sum'),P=('P','sum'),positive_pools=('positive_pools','sum'),total_budget=('total_budget','sum')).reset_index()
    summary.to_csv(HERE/'results/screen_summary.csv',index=False)
    primary=results[results.base.eq('chemeleon')&results.budget_per_pool.eq(4)].pivot(index='fold',columns='policy',values='C')
    delta=primary.stage_feedback-primary.raw_pooling
    s=summary[summary.budget_per_pool.eq(4)];best=int(s[s.policy.isin(['fixed_pooling','raw_pooling'])].C.max())
    new=int(s[s.base.eq('chemeleon')&s.policy.eq('stage_feedback')].C.iloc[0]);joint=int(primary.joint_feedback.sum());prior=int(primary.prior_static.sum())
    raw_cov=int(s[s.base.eq('chemeleon')&s.policy.eq('raw_pooling')].coverage.iloc[0]);new_cov=int(s[s.base.eq('chemeleon')&s.policy.eq('stage_feedback')].coverage.iloc[0])
    record=dict(status='COMPLETE',primary_C=new,matched_raw_C=int(primary.raw_pooling.sum()),matched_prior_C=prior,matched_joint_feedback_C=joint,best_static_C=best,
        by_fold_vs_raw={str(k):int(v) for k,v in delta.items()},coverage=new_cov,raw_coverage=raw_cov,
        followup_gate_pass=bool(delta.sum()>=3 and (delta>0).sum()>=3),promotion_gate_pass=bool(new>=best+5 and new>=prior+5 and new>joint and new_cov>=raw_cov),
        independent_test=False,new_chemical_endpoints=0,wall_seconds=time.perf_counter()-start)
    save(HERE/'results/screen_decision.json',record);print(summary[summary.budget_per_pool.eq(4)].to_string(index=False));print(json.dumps(record),flush=True)
def checks():
    rng=np.random.default_rng(38)
    for n in [3,17]:
        D=rng.uniform(.01,.99,n);R=rng.uniform(.01,.99,n);reference=np.ones(n)
        a=PocketBelief(D,R,reference,'stage_feedback');b=PocketBelief(D,R,reference,'joint_feedback')
        assert np.allclose(a.predict(),b.predict(),atol=1e-14)
        for i,obs in enumerate([(0,None),(1,0),(1,1)]):
            a.reveal_stage(i,*obs)
            # Full two-dimensional stage posterior provides a reference calculation.
            likelihood=(1-b.D[i])[:,None] if obs[0]==0 else np.outer(b.D[i],b.R[i] if obs[1] else 1-b.R[i])
            b.W*=likelihood;b.W/=b.W.sum()
            assert np.allclose(a.predict(),b.predict(),atol=1e-14)
    save(HERE/'checks/posterior_algebra.json',dict(status='PASS',stage_factorization_matches_full_2D_posterior=True,D0_has_no_conditional_label=True,initial_stage_joint_predictions_equal=True,stage_quadrature_cost='O(NL)',joint_quadrature_cost='O(NL^2)',real_world_superiority_guaranteed=False))
if __name__=='__main__':checks();screen()
