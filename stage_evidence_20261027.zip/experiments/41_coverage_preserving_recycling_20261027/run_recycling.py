"""Pathwise coverage-preserving discovery pilot and quota recycling.

Both policy phases operate on predictions and returned selected outcomes only.
"""
from pathlib import Path
import itertools,json,time
import numpy as np,pandas as pd
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1];EX=ROOT/'experiments'
PRIMARY='chemeleon_compact_qualification'
METHODS=[PRIMARY,'chemeleon_conditional','chemeleon_direct','morgan_conditional','strict_catboost_conditional','strict_catboost_joint','rf_joint','strict_CFE']
class Recycling:
    def __init__(self,frame,field,cap):
        assert not {'D','y','V','Q','VQ'}&set(frame.columns)
        self.frame=frame;self.score=frame[field].to_numpy(float);self.active=np.ones(len(frame),bool);self.cap=cap
        self.orders={p:g.sort_values([field,'candidate_id'],ascending=[False,True]).index.to_numpy() for p,g in frame.groupby('pocket_id',sort=True)}
        self.pointers={p:0 for p in self.orders};self.found=set();self.pilot_done=False;self.last_pilot=None
    def action(self):
        if not self.pilot_done:
            eligible=[p for p,ix in self.orders.items() if p not in self.found and self.pointers[p]<min(self.cap,len(ix))]
            if eligible:
                pid=min(eligible,key=lambda p:(self.pointers[p],p));self.last_pilot=pid;return int(self.orders[pid][self.pointers[pid]])
            self.pilot_done=True;self.last_pilot=None
        values=np.where(self.active,self.score,-np.inf);return int(np.flatnonzero(values>=values.max()-1e-12)[0])
    def reveal(self,index,y):
        assert self.active[index];self.active[index]=False;pid=self.frame.pocket_id.iloc[index]
        if self.last_pilot is not None:
            assert pid==self.last_pilot;self.pointers[pid]+=1
        if y:self.found.add(pid)
def order(g,m):return g.sort_values([m,'pocket_id','candidate_id'],ascending=[False,True,True]).index.to_numpy()
def fixed_pilot_order(g,m):
    first=g.sort_values([m,'candidate_id'],ascending=[False,True]).groupby('pocket_id',sort=True).head(1).index.to_numpy()
    first=sorted(first,key=lambda i:g.pocket_id.iloc[i]);chosen=set(first)
    return np.r_[first,[i for i in order(g,m) if i not in chosen]]
def coverage_greedy(g,m,lam,K):
    active=np.ones(len(g),bool);scores=g[m].to_numpy();found=set();selected=[];ids=g.pocket_id.to_numpy()
    for _ in range(K):
        values=np.where(active,scores*np.array([1 if p in found else 1+lam for p in ids]),-np.inf)
        index=int(np.flatnonzero(values>=values.max()-1e-12)[0]);selected.append(index);active[index]=False
        if int(g.y.iloc[index]):found.add(ids[index])
    return selected
def evaluate_campaign(g,fold):
    g=g.sort_values(['pocket_id','candidate_id']).reset_index(drop=True);rows=[];actions=[];thresholds=[]
    predictions=g.drop(columns=['D','y','fold','cluster30','reference_success','cohort'],errors='ignore')
    for method in METHODS:
        orders={p:x.sort_values([method,'candidate_id'],ascending=[False,True]).index.to_numpy() for p,x in g.groupby('pocket_id')}
        uniform32=np.concatenate([ix[:min(32,len(ix))] for ix in orders.values()]);targetC=int(g.y.iloc[uniform32].sum());targetCov=int(g.iloc[uniform32].groupby('pocket_id').y.sum().gt(0).sum())
        for cap in [4,8,16,32]:
            budget=sum(min(cap,len(ix)) for ix in orders.values());uniform=np.concatenate([ix[:min(cap,len(ix))] for ix in orders.values()])
            uniform_hits={p for p,ix in orders.items() if g.y.iloc[ix[:min(cap,len(ix))]].sum()>0}
            policy=Recycling(predictions,method,cap);selected=[];pilot_calls=0;pilot_found=set()
            # Run complete ordering to obtain label-known thresholds; the same
            # pilot is retained, with a fixed frozen-utility continuation.
            for step in range(1,len(g)+1):
                index=policy.action();in_pilot=not policy.pilot_done;y=int(g.y.iloc[index]);policy.reveal(index,y);selected.append(index)
                if in_pilot:pilot_calls+=1;pilot_found=set(policy.found)
                actions.append(dict(fold=fold,method=method,cap=cap,step=step,pocket_id=g.pocket_id.iloc[index],candidate_id=g.candidate_id.iloc[index],pilot=in_pilot,y=y))
            assert pilot_found==uniform_hits,(fold,method,cap)
            expected=0
            for pid,ix in orders.items():
                hit=np.flatnonzero(g.y.iloc[ix[:min(cap,len(ix))]].to_numpy())
                expected+=int(hit[0]+1) if len(hit) else min(cap,len(ix))
            assert pilot_calls==expected
            allocations={'cpqr':selected[:budget],'uniform':uniform,'pooled':order(g,method)[:budget],'fixed_pilot1':fixed_pilot_order(g,method)[:budget]}
            for lam in [0,1,2,4,8,16]:allocations['coverage_greedy_'+str(lam)]=coverage_greedy(g,method,lam,budget)
            for algorithm,ix in allocations.items():
                s=g.iloc[ix];C=int(s.y.sum());cov=int(s.groupby('pocket_id').y.sum().gt(0).sum())
                if algorithm=='cpqr':assert cov>=len(uniform_hits)
                rows.append(dict(fold=fold,method=method,algorithm=algorithm,cap=cap,K=budget,C=C,coverage=cov,pilot_calls=pilot_calls if algorithm=='cpqr' else np.nan,recycled_calls=budget-pilot_calls if algorithm=='cpqr' else np.nan))
            for algorithm,ix in [('cpqr',selected),('pooled',order(g,method)),('fixed_pilot1',fixed_pilot_order(g,method))]:
                total=0;hit=set();threshold=None
                for k,i in enumerate(ix,1):
                    y=int(g.y.iloc[i]);total+=y
                    if y:hit.add(g.pocket_id.iloc[i])
                    if total>=targetC and len(hit)>=targetCov:threshold=k;break
                thresholds.append(dict(fold=fold,method=method,algorithm=algorithm,cap=cap,target_C32=targetC,target_cov32=targetCov,uniform32_calls=len(uniform32),calls_for_both=threshold))
    return rows,actions,thresholds
def toy_checks():
    count=0
    # Exhaust every label assignment for two small pools; policies get no labels.
    for labels in itertools.product([0,1],repeat=6):
        g=pd.DataFrame({'pocket_id':['a']*3+['b']*3,'candidate_id':['0','1','2']*2,'score':[.9,.5,.1,.7,.4,.2]})
        for cap in [1,2,3]:
            p=Recycling(g,'score',cap);selected=[];pilot=[]
            for _ in range(2*cap):
                i=p.action();was_pilot=not p.pilot_done;p.reveal(i,labels[i]);selected.append(i)
                if was_pilot:pilot.append(i)
            baseline={pool for pool,ix in [('a',range(cap)),('b',range(3,3+cap))] if any(labels[i] for i in ix)}
            found={g.pocket_id.iloc[i] for i in selected if labels[i]}
            assert baseline<=found and len(set(selected))==2*cap;count+=1
    (HERE/'checks/coverage_theorem.json').write_text(json.dumps(dict(status='PASS',exhaustive_cases=count,baseline_coverage_preserved=True,oracle_labels_in_policy=False,universal_recovery_superiority=False),indent=2)+'\n')
def main():
    toy_checks();z=pd.read_csv(EX/'35_stage_evidence_upgrade_20261027/results/analysis_scores.csv');z=z[z.cohort.eq('development')].copy()
    rows=[];actions=[];thresholds=[]
    for fold,g in z.groupby('fold'):
        a,b,c=evaluate_campaign(g,int(fold));rows+=a;actions+=b;thresholds+=c;print('CAMPAIGN_COMPLETE',fold,flush=True)
    per=pd.DataFrame(rows);per.to_csv(HERE/'results/recycling_campaigns.csv',index=False);pd.DataFrame(actions).to_csv(HERE/'results/recycling_actions.csv',index=False)
    th=pd.DataFrame(thresholds);th.to_csv(HERE/'results/recycling_target_budgets.csv',index=False)
    summary=per.groupby(['method','algorithm','cap'],sort=False).agg(C=('C','sum'),coverage=('coverage','sum'),K=('K','sum'),pilot_calls=('pilot_calls','sum'),recycled_calls=('recycled_calls','sum')).reset_index()
    summary.to_csv(HERE/'results/recycling_summary.csv',index=False)
    q=summary[summary.cap.eq(8)];r=q[q.method.eq(PRIMARY)].set_index('algorithm');new=r.loc['cpqr'];controls=q[q.algorithm.ne('cpqr')]
    dominates=controls[(controls.C>=new.C)&(controls.coverage>=new.coverage)&((controls.C>new.C)|(controls.coverage>new.coverage))]
    p=per[per.method.eq(PRIMARY)&per.cap.eq(8)].pivot(index='fold',columns='algorithm',values='C');delta=p.cpqr-p.uniform
    passed=bool(new.C>=r.loc['uniform','C']+20 and (delta>0).sum()>=3 and len(dominates)==0)
    decision=dict(status='COMPLETE',primary_cap8_C=int(new.C),primary_coverage=int(new.coverage),uniform_C=int(r.loc['uniform','C']),uniform_coverage=int(r.loc['uniform','coverage']),pooled_C=int(r.loc['pooled','C']),pooled_coverage=int(r.loc['pooled','coverage']),pilot_calls=int(new.pilot_calls),recycled_calls=int(new.recycled_calls),
        by_fold_C_vs_uniform={str(k):int(v) for k,v in delta.items()},Pareto_dominating_controls=dominates[['method','algorithm','C','coverage']].to_dict('records'),promotion_gate_pass=passed,independent_test=False)
    (HERE/'results/recycling_decision.json').write_text(json.dumps(decision,indent=2)+'\n');print(q.to_string(index=False));print(json.dumps(decision),flush=True)
if __name__=='__main__':main()
