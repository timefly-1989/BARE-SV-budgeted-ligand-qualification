"""Match the same observed discovery utility across fixed and Bayesian policies."""
from pathlib import Path
import importlib.util,json
import numpy as np,pandas as pd
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
spec=importlib.util.spec_from_file_location('screen38',ROOT/'experiments/38_stage_posterior_allocation_20261027/run_screen.py')
base=importlib.util.module_from_spec(spec);spec.loader.exec_module(base)
def main():
    cfg=json.loads((HERE/'protocol.json').read_text());z=base.inputs();rows=[];trace=[]
    for fold,g in z.groupby('fold'):
        g=g.sort_values(base.KEYS).reset_index(drop=True);J=g.pocket_id.nunique();pred=g.drop(columns=['D','y','sa_score'])
        for expert in base.BASES:
            for mode in base.POLICIES:
                for lam in cfg['lambdas']:
                    policy=base.Allocator(pred,expert,mode);found=set();chosen=[]
                    for step in range(1,8*J+1):
                        weight=np.array([1 if pid in found else 1+lam for pid in pred.pocket_id])
                        utility=np.where(policy.active,policy.scores*weight,-np.inf)
                        index=int(np.flatnonzero(utility>=utility.max()-1e-12)[0]);r=g.iloc[index]
                        chosen.append(index);D=int(r.D);y=int(r.y)
                        if mode=='stage_feedback':policy.finish(index,D=D,R=y if D else None)
                        elif mode=='joint_feedback':policy.finish(index,y=y)
                        else:policy.finish(index)
                        if y:found.add(r.pocket_id)
                        trace.append(dict(fold=fold,base=expert,policy=mode,lambda_=lam,step=step,pocket_id=r.pocket_id,candidate_id=r.candidate_id,D=D,y=y))
                        if step in [4*J,8*J]:
                            s=g.iloc[chosen];C=int(s.y.sum());rows.append(dict(fold=fold,base=expert,policy=mode,lambda_=lam,budget_per_pool=step//J,C=C,coverage=len(found),utility=C+lam*len(found),total_budget=step))
        print('CAMPAIGN',fold,'complete',flush=True)
    rows=pd.DataFrame(rows);rows.to_csv(HERE/'results/coverage_campaigns.csv',index=False);pd.DataFrame(trace).to_csv(HERE/'results/coverage_actions.csv',index=False)
    summary=rows.groupby(['base','policy','lambda_','budget_per_pool'],sort=False).agg(C=('C','sum'),coverage=('coverage','sum'),utility=('utility','sum'),total_budget=('total_budget','sum')).reset_index()
    summary.to_csv(HERE/'results/coverage_summary.csv',index=False)
    p=summary[summary.lambda_.eq(4)&summary.budget_per_pool.eq(4)];r=p[p.base.eq('chemeleon')].set_index('policy');best=int(p[p.policy.eq('raw_pooling')].utility.max())
    effects=rows[rows.base.eq('chemeleon')&rows.lambda_.eq(4)&rows.budget_per_pool.eq(4)].pivot(index='fold',columns='policy',values='utility');delta=effects.stage_feedback-effects.raw_pooling
    passed=bool(r.loc['stage_feedback','utility']>=best+8 and r.loc['stage_feedback','utility']>r.loc['joint_feedback','utility'] and r.loc['stage_feedback','coverage']>=r.loc['raw_pooling','coverage'] and r.loc['stage_feedback','C']>=r.loc['raw_pooling','C']-2 and (delta>0).sum()>=3)
    decision=dict(status='COMPLETE',primary_C=int(r.loc['stage_feedback','C']),primary_coverage=int(r.loc['stage_feedback','coverage']),primary_U=int(r.loc['stage_feedback','utility']),best_raw_U=best,matched_joint_U=int(r.loc['joint_feedback','utility']),by_fold_U_vs_raw={str(k):int(v) for k,v in delta.items()},passed=passed,independent_test=False)
    (HERE/'results/coverage_decision.json').write_text(json.dumps(decision,indent=2)+'\n');print(p.to_string(index=False));print(json.dumps(decision))
if __name__=='__main__':main()
