"""Budget policies; an oracle discloses only the selected candidate label."""
import numpy as np

def ordering(score,pid,cid):return np.lexsort((np.asarray(cid,str),np.asarray(pid,str),-np.asarray(score,float)))
def allocate(score,pid,cid,B,algorithm,reveal=None):
 score=np.asarray(score,float);pid=np.asarray(pid,str);cid=np.asarray(cid,str);n=len(score)
 groups={p:np.flatnonzero(pid==p) for p in sorted(set(pid))}
 ranks={p:ix[ordering(score[ix],pid[ix],cid[ix])] for p,ix in groups.items()}
 K=sum(min(B,len(ix)) for ix in ranks.values());global_order=ordering(score,pid,cid)
 if algorithm=='global':return list(global_order[:K])
 if algorithm=='uniform':return [int(i) for ix in ranks.values() for i in ix[:min(B,len(ix))]]
 if algorithm=='recycling':
  assert reveal is not None;chosen=[];found=set();ptr={p:0 for p in ranks}
  while True:
   available=[p for p in ranks if p not in found and ptr[p]<min(B,len(ranks[p]))]
   if not available:break
   p=min(available,key=lambda p:(ptr[p],p));i=int(ranks[p][ptr[p]]);ptr[p]+=1;chosen.append(i)
   if reveal(i):found.add(p)
  used=set(chosen)
  chosen += [int(i) for i in global_order if i not in used][:K-len(chosen)]
  return chosen
 assert algorithm in ['forecast_coverage4','observed_coverage4']
 if algorithm=='observed_coverage4':assert reveal is not None
 nohit={p:1. for p in ranks};active=np.ones(n,bool);chosen=[]
 for step in range(K):
  value=np.where(active,score*np.array([1+4*nohit[p] for p in pid]),-np.inf)
  # Numeric ties use the same pocket/candidate lexical order as global pooling.
  order=ordering(value,pid,cid);i=int(order[0]);chosen.append(i);active[i]=False;p=pid[i]
  if algorithm=='forecast_coverage4':nohit[p]*=1-score[i]
  elif reveal(i):nohit[p]=0.
 return chosen
