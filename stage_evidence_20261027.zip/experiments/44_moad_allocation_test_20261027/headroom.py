"""Separate allocation capacity from fixed-score ranking on exposed outcomes."""
from pathlib import Path
import json,datetime
import pandas as pd,numpy as np
H=Path(__file__).resolve().parent;E=H.parent

def evaluate(g,score,B):
 K=sum(min(B,len(x)) for _,x in g.groupby('pocket_id'))
 U=g.sort_values([score,'candidate_id'],ascending=[False,True]).groupby('pocket_id').head(B)
 G=g.sort_values([score,'pocket_id','candidate_id'],ascending=[False,True,True]).head(K)
 Ustar=int(sum(min(B,int(x.y.sum())) for _,x in g.groupby('pocket_id')));Gstar=min(K,int(g.y.sum()))
 CU=int(U.y.sum());CG=int(G.y.sum())
 assert CG-CU==(Gstar-Ustar)+(Ustar-CU)-(Gstar-CG)
 return dict(K=K,uniform_C=CU,global_C=CG,uniform_ceiling=Ustar,global_ceiling=Gstar,capacity_gap=Gstar-Ustar,uniform_ranking_gap=Ustar-CU,global_ranking_gap=Gstar-CG,uniform_coverage=int(U.groupby('pocket_id').y.sum().gt(0).sum()),global_coverage=int(G.groupby('pocket_id').y.sum().gt(0).sum()))

def main():
 rows=[];x=pd.read_csv(E/'35_stage_evidence_upgrade_20261027/results/analysis_scores.csv')
 for cohort,g in x.groupby('cohort',sort=False):
  campaigns=list(g.groupby('fold')) if cohort=='development' else [(0,g)]
  for B in [4,8,16,32]:
   vals=[evaluate(q,'chemeleon_compact_qualification',B) for _,q in campaigns]
   rows.append(dict(cohort=cohort,B=B,pools=int(g.pocket_id.nunique()),positives=int(g.y.sum()),**{k:sum(v[k] for v in vals) for k in vals[0]}))
 for exp,label in [('37_independent_qualification_20261027','CrossDocked_frozen'),('44_moad_allocation_test_20261027','MOAD_frozen')]:
  p=E/exp/'data/independent_outcomes.csv'
  if not p.exists():continue
  q=pd.read_csv(E/exp/'data/scores_before_outcomes.csv').merge(pd.read_csv(p),on=['pocket_id','candidate_id'],validate='one_to_one')
  for B in [4,8,16,32]:rows.append(dict(cohort=label,B=B,pools=int(q.pocket_id.nunique()),positives=int(q.y.sum()),**evaluate(q,'chemeleon_dual_full_compact',B)))
 out=pd.DataFrame(rows);out.to_csv(H/'results/allocation_headroom.csv',index=False);print(out[out.B.eq(8)].to_string(index=False))
if __name__=='__main__':main()
