"""Enumerate all depth-four binary decision tables for two ordered pools.

This is a finite implementation/theorem check, not a proof of scientific
originality or empirical yield superiority. Policies see selected binary labels.
"""
from pathlib import Path
import datetime,hashlib,itertools,json
import numpy as np
H=Path(__file__).resolve().parent

def main():
 q=np.array([.9,.8,.7,.3,.2,.1]);Y=np.array(list(itertools.product([0,1],repeat=6)),dtype=np.int8);ymask=(Y*(1<<np.arange(6))).sum(1).astype(np.uint8)
 tables=np.arange(1<<15,dtype=np.int32)[:,None];shape=(len(tables),len(Y));pa=np.zeros(shape,np.int8);pb=pa.copy();node=np.zeros(shape,np.int32);selected=np.zeros(shape,np.uint8);hits=np.zeros(shape,np.uint8)
 for _ in range(4):
  arm=((tables>>node)&1).astype(np.int8);arm=np.where(pa==3,1,np.where(pb==3,0,arm));index=np.where(arm==0,pa,3+pb)
  value=Y[np.arange(len(Y))[None,:],index];selected|=(1<<index).astype(np.uint8);hits|=np.where(value,1<<arm,0).astype(np.uint8)
  pa+=(arm==0);pb+=(arm==1);node=2*node+1+value
 required=np.where(Y[:,:2].any(1),1,0)|np.where(Y[:,3:5].any(1),2,0)
 safe=((hits&required)==required).all(1)
 M=np.uint8(1|8)+np.where(Y[:,0]==0,2,0).astype(np.uint8)+np.where(Y[:,3]==0,16,0).astype(np.uint8)
 assert ((selected[safe]&M)==M).all()
 order=np.argsort(-q,kind='stable');cp=[]
 for mandatory in M:
  chosen=int(mandatory)
  for i in order:
   if chosen.bit_count()>=4:break
   if not chosen&(1<<int(i)):chosen|=1<<int(i)
  cp.append(chosen)
 cp=np.array(cp,dtype=np.uint8);utility=np.array([sum(q[i] for i in range(6) if z&(1<<i)) for z in range(64)])
 assert (utility[cp][None,:]>=utility[selected[safe]]-1e-12).all()
 count=np.array([z.bit_count() for z in range(64)]);weights=np.prod(np.where(Y,q,1-q),axis=1)
 expected=count[selected[safe]&ymask].dot(weights);cp_expected=float(count[cp&ymask].dot(weights))
 assert float(expected.max())<=cp_expected+1e-12
 result=dict(status='PASS',timestamp_local=datetime.datetime.now().astimezone().isoformat(),decision_tables=int(len(tables)),binary_outcome_configurations=len(Y),universally_discovery_safe_tables=int(safe.sum()),budget=4,uniform_per_pool_quota=2,mandatory_pilot_necessary=True,pointwise_predicted_utility_optimal_within_class=True,independent_Bernoulli_expected_recovery_cpqr=cp_expected,best_safe_table_expected_recovery=float(expected.max()),uniform_expected_recovery=float(q[[0,1,3,4]].sum()),unconstrained_global_expected_recovery=float(np.sort(q)[-4:].sum()),scope='Nonanticipating, fixed-prefix-respecting binary-label policies; terminal discovery-set inclusion for every binary outcome assignment. No additional logically known labels; no claim of optimality over unrestricted or model-updating policies.',source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
 (H/'checks/restricted_optimality.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
if __name__=='__main__':main()
