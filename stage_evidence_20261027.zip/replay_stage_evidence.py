"""Read-only replay of the public stage-evidence numerical archive."""
from pathlib import Path
import hashlib,importlib.util,json
import numpy as np,pandas as pd
ROOT=Path(__file__).resolve().parent
EX=ROOT/'experiments'

def load_module(name,p):
    s=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m

def main():
    hashes=json.loads((ROOT/'SHA256SUMS.json').read_text());checks=0
    for name,expected in hashes.items():
        assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==expected,name;checks+=1
    d=pd.read_csv(EX/'35_stage_evidence_upgrade_20261027/results/analysis_scores.csv')
    key='chemeleon_compact_qualification'
    for cohort,total in [('development',188),('first48',128),('later23',35),('fresh16',62)]:
        g=d[d.cohort.eq(cohort)];c=0
        for _,f in g.groupby('pocket_id'):
            s=f.sort_values([key,'candidate_id'],ascending=[False,True]).iloc[:32];c+=int(s.y.sum())
        assert c==total,(cohort,c,total);checks+=1
    alloc=load_module('allocation44',EX/'44_moad_allocation_test_20261027/allocation.py')
    for label,directory,n,positives in [('crossdocked','37_independent_qualification_20261027',704,8),('moad','44_moad_allocation_test_20261027',576,1)]:
        base=EX/directory
        s=pd.read_csv(base/'data/scores_before_outcomes.csv');y=pd.read_csv(base/'data/independent_outcomes.csv')
        z=s.merge(y,on=['pocket_id','candidate_id'],validate='one_to_one')
        assert len(z)==n and z.y.sum()==positives
        assert z.loc[z.D.eq(0),['V','Q']].isna().all().all();checks+=2
        if label=='crossdocked':
            for name,total in [('chemeleon_dual_full_compact',5),('chemeleon_dual_full_full',8),('chemeleon_joint_full',8),('catboost_conditional279',5)]:
                ix=alloc.allocate(z[name],z.pocket_id,z.candidate_id,32,'uniform')
                assert z.iloc[ix].y.sum()==total;checks+=1
        else:
            saved=pd.read_csv(base/'results/allocation_summary.csv')
            # Publication table is the evaluator's complete frozen-policy output.
            for r in saved.itertuples():
                B=int(r.B) if hasattr(r,'B') else int(r.budget)
                method=r.method;alg=r.algorithm
                oracle=lambda i:int(z.y.iloc[i])
                ix=alloc.allocate(z[method],z.pocket_id,z.candidate_id,B,alg,oracle)
                assert len(ix)==int(r.K) and int(z.iloc[ix].y.sum())==int(r.C);checks+=1
    power=load_module('power48',EX/'48_power_and_release_20261027/power_plan.py')
    saved=pd.read_csv(EX/'48_power_and_release_20261027/results/exact_sign_power.csv')
    for row in saved.itertuples():
        n=int(row.independent_units_for_first_80pct_crossing);cp=power.conditional_power(n,row.win_given_nonzero)
        value=power.power(n,row.discordance_probability,cp)
        assert abs(value-row.exact_power_at_crossing)<1e-12;checks+=1
    cal=pd.read_csv(EX/'46_stage_calibration_upgrade_20261027/results/summary.csv')
    v=cal[cal.method.eq('stage_pool_count')&cal.budget.eq(1)&cal.policy.eq('global')].iloc[0]
    assert int(v.C)==67;checks+=1
    ker=pd.read_csv(EX/'47_stage_kernel_feedback_20261027/results/summary.csv')
    assert int(ker[ker.method.eq('kernel_stage')&ker.budget.eq(1)].iloc[0].C)==69;checks+=1
    print(json.dumps(dict(status='PASS',checks=checks,independent_computational_outcomes=1280,
         new_chemical_calls=0,neural_models_refitted=0,original_numerical_data_read_only=True)))

if __name__=='__main__':main()
