"""Refit/replay the two recorded development mechanisms from numerical inputs."""
from pathlib import Path
import json,sys
import numpy as np,pandas as pd
HERE=Path(__file__).resolve().parent
INPUT=HERE/'adapter_inputs'
sys.path.insert(0,str(INPUT))
from adapter_definitions import fit,predict,kernel,episode

def main():
    root=HERE.parent if HERE.name=='replay' else HERE
    d=pd.read_csv(INPUT/'development_numeric.csv');packed=np.load(INPUT/'fingerprints_packed.npy')
    fp=np.unpackbits(packed,axis=1)
    ex=root/'experiments'
    cal=ex/'46_stage_calibration_upgrade_20261027';ker=ex/'47_stage_kernel_feedback_20261027'
    saved=pd.read_csv(cal/'results/development_scores.csv')
    old_inner=pd.read_csv(ker/'results/inner_selection.csv')
    old_outer=pd.read_csv(ker/'results/fold_results.csv')
    checks=0;maximum_error=0.
    methods={'stage_platt':(False,0.),'stage_count':(False,1.),'stage_pool':(True,0.),'stage_pool_count':(True,1.)}
    grid=[(t,p) for t in [.25,1.,4.] for p in [2,4]]
    for outer in range(5):
        bank=np.load(INPUT/f'fold{outer}.npz');a=bank['train_index'];q=bank['query_index']
        frame=d.iloc[a];x=[bank['xD'],bank['xR']];xq=[bank['xqD'],bank['xqR']]
        for key,(context,cw) in methods.items():
            t,log=fit(frame,x,context,cw)
            score=predict(xq,t).prod(1)*d.reference_success.to_numpy()[q]
            error=float(np.max(np.abs(score-saved[key].to_numpy()[q])))
            assert error<1e-10,(outer,key,error)
            maximum_error=max(error,maximum_error);checks+=1
        banks=[]
        for infold in range(5):
            take=d.fold.to_numpy()[a]==infold
            if not take.any():continue
            ia=a[take];banks.append((d.iloc[ia].reset_index(drop=True),bank['train_prob'][take],kernel(fp[ia])))
        for mode in ['stage','joint']:
            criteria={}
            for tau,power in grid:
                values=[episode(f,p,k,mode,tau,power,1)[0] for f,p,k in banks]
                c=sum(v['C'] for v in values);cov=sum(v['Cov'] for v in values);criteria[(tau,power)]=(c,cov)
                old=old_inner[old_inner.outer.eq(outer)&old_inner['mode'].eq(mode)&old_inner.tau.eq(tau)&old_inner.power.eq(power)].iloc[0]
                assert c==old.C and cov==old.Cov;checks+=1
            tau,power=max(grid,key=lambda c:criteria[c])
            f=d.iloc[q].reset_index(drop=True);p=bank['query_prob'];k=kernel(fp[q])
            for B in [1,2,4,8,16,32]:
                value,_=episode(f,p,k,mode,tau,power,B)
                old=old_outer[old_outer.fold.eq(outer)&old_outer.method.eq('kernel_'+mode)&old_outer.budget.eq(B)].iloc[0]
                assert all(value[key]==int(old[key]) for key in ['C','Cov','K']);checks+=1
    result=dict(status='PASS',checks=checks,calibrator_fits_recomputed=20,
          nested_kernel_configurations_replayed=60,kernel_outer_policy_values=60,
          maximum_score_difference=maximum_error,neural_models_refitted=0,chemical_calls=0)
    print(json.dumps(result))

if __name__=='__main__':main()
