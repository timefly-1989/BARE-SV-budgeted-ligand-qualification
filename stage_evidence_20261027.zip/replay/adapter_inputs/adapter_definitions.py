"""Verbatim numerical definitions extracted from the recorded experiments.
No external checkpoints, raw molecules or outcome acquisition required.
"""
import numpy as np
import pandas as pd
from scipy.optimize import minimize
from scipy.special import expit,logit
from scipy.sparse import csr_matrix
from sklearn.metrics import brier_score_loss
def fit(frame,x,context,countweight):
    D=frame.D.to_numpy(float); y=frame.y.to_numpy(float); n=len(D)
    ix=3 if context else 2
    x=[z[:,:ix] for z in x]
    code,_=pd.factorize(frame.pocket_id,sort=True)
    P=np.bincount(code,weights=y)
    ridge=.01
    def fun(t):
        t=t.reshape(2,ix)
        # Identity-centered coefficients retain the base score without data.
        eta=[x[s][:,1]+x[s]@t[s] for s in range(2)]
        d,r=map(expit,eta); joint=d*r
        loss=np.mean(np.logaddexp(0,eta[0])-D*eta[0]+D*(np.logaddexp(0,eta[1])-y*eta[1]))
        gd=(d-D)/n; gr=D*(r-y)/n
        mu=np.bincount(code,weights=joint)
        if countweight:
            # Poisson quasi-likelihood for the first moment, not independence.
            loss+=countweight*np.sum(mu-P*np.log(np.maximum(mu,1e-12)))/n
            dl=countweight*(1-P/np.maximum(mu,1e-12))[code]/n
            gd+=dl*joint*(1-d);gr+=dl*joint*(1-r)
        loss+=ridge*np.sum(t*t)/2
        grad=np.stack([x[0].T@gd,x[1].T@gr])+ridge*t
        return loss,grad.ravel()
    bounds=[(-6,6),(-.9,9)]+([(-3,3)] if context else [])
    res=minimize(fun,np.zeros((2,ix)).ravel(),method='L-BFGS-B',jac=True,
                 bounds=bounds*2,options=dict(maxiter=500,ftol=1e-12,gtol=1e-8))
    assert res.success, res.message
    t=res.x.reshape(2,ix)
    return t,dict(success=bool(res.success),iterations=res.nit,loss=float(res.fun),
                  coefficients=t.tolist(),free_parameters=2*ix,gradient_max=float(np.max(np.abs(res.jac))))

def predict(x,t):
    return np.column_stack([expit(z[:,1]+z[:,:t.shape[1]]@t[s]) for s,z in enumerate(x)])

def kernel(fp):
    x=csr_matrix(fp.astype(np.float32));dot=(x@x.T).toarray();n=np.asarray(x.sum(1)).ravel()
    return np.divide(dot,n[:,None]+n[None,:]-dot,out=np.zeros_like(dot),where=(n[:,None]+n[None,:]-dot)>0)

class Policy:
    def __init__(self,inputs,prob,sim,mode,tau,power):
        assert not {'D','y','VQ','V','Q'}&set(inputs.columns)
        tau=float(tau)
        self.p=prob.copy();self.n=tau*prob.copy();self.den=np.full_like(prob,tau)
        self.K=np.power(sim,power)
        group=inputs.pocket_id.to_numpy();self.local=(group[:,None]==group[None,:])
        self.ref=inputs.reference_success.to_numpy(float);self.mode=mode
        self.available=np.ones(len(inputs),bool)
        self.nY=tau*prob.prod(1);self.denY=np.full(len(inputs),tau)
        self.ident=np.lexsort((inputs.candidate_id.to_numpy(),group));self.tie=np.argsort(self.ident)
    def action(self):
        p=self.n/self.den
        u=(self.nY/self.denY if self.mode=='joint' else p.prod(1))*self.ref
        u[~self.available]=-np.inf
        return int(np.lexsort((self.tie,-u))[0])
    def observe(self,i,**feedback):
        assert self.available[i];self.available[i]=False
        if self.mode=='joint':
            assert set(feedback)=={'y'}
            w=self.K[:,i]*self.local[:,i]
            self.nY+=w*feedback['y'];self.denY+=w
        else:
            assert set(feedback)=={'D','R'} and (feedback['D']==1 or feedback['R'] is None)
            w=self.K[:,i]
            self.n[:,0]+=w*feedback['D'];self.den[:,0]+=w
            if feedback['D']:
                w=w*self.local[:,i]
                self.n[:,1]+=w*feedback['R'];self.den[:,1]+=w

def episode(frame,p,sim,mode,tau,power,budget,log=False):
    # Private evaluator; no unselected labels are passed to Policy.
    inputs=frame[['pocket_id','candidate_id','reference_success']].reset_index(drop=True)
    pol=Policy(inputs,p,sim,mode,tau,power)
    labels=frame[['D','y']].to_numpy(int)
    K=sum(min(budget,len(g)) for _,g in frame.groupby('pocket_id',sort=False))
    rows=[];C=0;covered=set()
    for t in range(K):
        i=pol.action();D,y=map(int,labels[i]);C+=y
        if y:covered.add(inputs.pocket_id.iloc[i])
        if mode=='joint':pol.observe(i,y=y)
        else:pol.observe(i,D=D,R=y if D else None)
        if log:rows.append(dict(t=t+1,index=i,pocket_id=inputs.pocket_id.iloc[i],candidate_id=inputs.candidate_id.iloc[i],D=D,
                                R=y if D else None,y=y,C=C,Cov=len(covered)))
    return dict(C=C,Cov=len(covered),K=K),rows
