"""Independent exhaustive safe-path oracle and model-dependent Bellman checks."""
from pathlib import Path
from functools import lru_cache
import itertools,json,numpy as np
from constrained import hindsight_value
H=Path(__file__).resolve().parent

def main():
 cases=0;full=[]
 for groups in [(0,0,0,1,1,1),(0,0,1,1,2,2)]:
  g=np.array(groups);n=len(g);names=sorted(set(g));parts=[np.flatnonzero(g==j) for j in names]
  for quotas in itertools.product(*(range(1,len(z)+1) for z in parts)):
   base=np.zeros(n,bool)
   for z,b in zip(parts,quotas):base[z[:b]]=True
   K=int(base.sum())
   for ys in itertools.product([0,1],repeat=n):
    y=np.array(ys)
    @lru_cache(None)
    def oracle(selected):
     t=sum(selected);r=K-t
     if not r:return 0
     state=np.where(selected,y,-1);hits=set(g[state==1]);O=(state<0)&base&~np.isin(g,list(hits));h=int(O.sum())
     if h>r:return -100
     ix=np.flatnonzero((state<0)&((h<r)|O));return max(int(y[i])+oracle(tuple(v or i==k for k,v in enumerate(selected))) for i in ix)
    for selected in itertools.product([False,True],repeat=n):
     if sum(selected)>K:continue
     state=np.where(selected,y,-1);hits=set(g[state==1]);h=int(((state<0)&base&~np.isin(g,list(hits))).sum());r=K-sum(selected)
     if h>r:continue
     assert hindsight_value(g,base,state,r,y)==oracle(selected),(groups,quotas,ys,selected);cases+=1
    full.append(dict(groups=list(groups),quotas=list(quotas),y=list(ys),safe_path_oracle=oracle((False,)*n)))
 # Exact Bayesian values under a supplied joint law, including a correlated witness.
 g=np.array([0,0,0,1,1,1]);base=np.array([1,1,0,1,1,0],bool);K=4;n=6;worlds=np.array(list(itertools.product([0,1],repeat=n)));rng=np.random.default_rng(531028)
 witness=np.zeros(64);w1=np.array([1,0,1,0,0,1]);w2=np.array([0,0,0,1,1,0]);witness[np.flatnonzero((worlds==w1).all(axis=1))[0]]=.4;witness[np.flatnonzero((worlds==w2).all(axis=1))[0]]=.6
 laws=[witness]+[rng.dirichlet(np.full(64,.15)) for _ in range(20)];models=[]
 for model_index,law in enumerate(laws):
  @lru_cache(None)
  def value(state,kind):
   state=np.array(state);active=state<0;r=K-int((~active).sum())
   if not r:return 0.
   possible=np.all((worlds==state)|active,axis=1);prob=law*possible;mass=prob.sum()
   if mass==0:return 0.
   prob/=mass;q=prob@worlds;hits=set(g[state==1]);O=active&base&~np.isin(g,list(hits));h=int(O.sum());allowed=np.flatnonzero(active&((h<r)|O))
   if kind=='pilot_opt' and h:
    allowed=np.array([int(np.flatnonzero(O&(g==j))[0]) for j in [0,1] if np.any(O&(g==j))])
   if kind=='posterior_greedy':allowed=np.array([int(min(allowed,key=lambda i:(-q[i],i)))])
   vals=[]
   for i in allowed:
    s0=state.copy();s1=state.copy();s0[i]=0;s1[i]=1;v=q[i]+(1-q[i])*value(tuple(s0),'safe_opt' if kind=='safe_opt' else kind)+q[i]*value(tuple(s1),'safe_opt' if kind=='safe_opt' else kind);vals.append(v)
   return max(vals)
  init=(-1,)*n;safe=value(init,'safe_opt');pilot=value(init,'pilot_opt');greedy=value(init,'posterior_greedy');oracle=sum(float(w)*hindsight_value(g,base,np.full(n,-1),K,y) for w,y in zip(law,worlds));assert safe>=pilot-1e-12 and oracle>=safe-1e-12
  models.append(dict(model=model_index,law=law.tolist(),safe_Bellman=safe,optimal_pilot_first=pilot,posterior_greedy=greedy,hindsight_path_expectation=oracle))
 assert abs(models[0]['safe_Bellman']-2.4)<1e-12;assert abs(models[0]['optimal_pilot_first']-2.)<1e-12
 out=dict(status='PASS',safe_path_histories=cases,root_outcome_tables=len(full),model_cases=len(models),strict_witness=models[0],models=models)
 (H/'checks/oracle_verification.json').write_text(json.dumps(out,indent=2)+'\n');print({k:v for k,v in out.items() if k not in ['strict_witness','models']})
if __name__=='__main__':main()
