"""Replay all new constrained policies using labels restored from official archives."""
from pathlib import Path
import argparse,json,gzip,tarfile,hashlib,time
import numpy as np,pandas as pd
from rdkit import Chem,RDLogger
from constrained import simulate,hindsight_value
H=Path(__file__).resolve().parent;R=H.parents[1]
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def main():
 a=argparse.ArgumentParser();a.add_argument('--toxcast',required=True,type=Path);a.add_argument('--fsmol',required=True,type=Path);args=a.parse_args();RDLogger.DisableLog('rdApp.*');start=time.perf_counter()
 plan=json.loads((H/'analysis_plan.json').read_text())
 for name,value in plan['source_hashes'].items():assert sha(H/name)==value
 f=R/'experiments/50_discovery_allocation_20261028';e=R/'experiments/52_multisource_randomized_20261028';p=json.loads((e/'protocol_lock.json').read_text());assert sha(args.toxcast)==p['raw_sha256']
 maps=pd.read_csv(f/'data/partition_rows.csv');wanted={(r.assay,int(r.source_row)):r.key for r in maps[maps.role.eq('query')].itertuples()};members=pd.read_csv(f/'sources/test_member_checksums.csv').set_index('assay').member.to_dict();labs=[]
 with tarfile.open(args.fsmol) as z:
  for assay in sorted(maps.assay.unique()):
   for row,line in enumerate(gzip.decompress(z.extractfile(members[assay]).read()).splitlines(),1):
    if (assay,row) in wanted:labs.append(dict(assay=assay,key=wanted[(assay,row)],y=int(float(json.loads(line)['Property']))))
 assert len(labs)==5498
 fs=pd.read_csv(f/'data/new_test_scores_before_labels.csv');fs=fs[fs.seed.eq(11)].merge(pd.DataFrame(labs),on=['assay','key'],validate='many_to_one');fs['provider']='FS_Mol'
 raw=pd.read_csv(args.toxcast);first={}
 for n,sm in raw.smiles.items():
  mol=Chem.MolFromSmiles(sm)
  if mol is None:continue
  Chem.RemoveStereochemistry(mol);key=hashlib.sha256(Chem.MolToSmiles(mol,canonical=True,isomericSmiles=False).encode()).hexdigest()
  if key not in first:first[key]=n
 bykey=raw.loc[list(first.values())].copy();bykey.index=list(first.keys());tox=pd.read_csv(e/'data/scores_before_labels.csv');tox['y']=[int(bykey.loc[k,assay]) for k,assay in zip(tox.key,tox.assay)];tox['campaign']=tox.unit;tox['method']='Morgan2048_RF';tox['seed']=11
 expected=pd.read_csv(H/'results/policies.csv');oracles=pd.read_csv(H/'results/oracles.csv');checked=0;oracle_count=0
 for dataset,d in [('ToxCast',tox),('FS_Mol',fs)]:
  for (method,campaign),g in d.groupby(['method','campaign'],sort=True):
   g=g.sort_values(['assay','key']).reset_index(drop=True);pool=g.assay.to_numpy();key=g.key.to_numpy();score=g.score.to_numpy();y=g.y.to_numpy();z=expected[(expected.dataset==dataset)&(expected.method==method)&(expected.campaign==campaign)]
   for row in z.itertuples():
    result,ix,_=simulate(score,pool,key,y,int(row.B),row.algorithm,11)
    for k in ['K','C','coverage','baseline_coverage','baseline_lost']:assert result[k]==getattr(row,k),(dataset,campaign,method,row.B,row.algorithm,k)
    checked+=1
   names=sorted(set(pool));group=np.array([names.index(x) for x in pool])
   for row in oracles[(oracles.dataset==dataset)&(oracles.method==method)&(oracles.campaign==campaign)].itertuples():
    base=np.zeros(len(g),bool)
    for j in range(len(names)):
     ix=sorted(np.flatnonzero(group==j),key=lambda i:(-score[i],key[i]));base[ix[:int(row.B)]]=True
    value=hindsight_value(group,base,np.full(len(g),-1),int(base.sum()),y);assert value==row.certified_hindsight;oracle_count+=1
   print('REPLAY',dataset,method,campaign,checked,flush=True)
 out=dict(status='PASS',policy_values_replayed=checked,oracle_values_replayed=oracle_count,source_query_labels_reconstructed=64639+5498,seconds=time.perf_counter()-start,old_primary_results_not_recomputed_or_modified=True)
 (H/'checks').mkdir(exist_ok=True);(H/'checks/public_replay.json').write_text(json.dumps(out,indent=2)+'\n');print(out)
if __name__=='__main__':main()
