"""Research-exposed matched-policy audit; old primary tests remain immutable."""
from pathlib import Path
import json,hashlib,datetime,time,sys
import numpy as np,pandas as pd
from constrained import ALGORITHMS,simulate,hindsight_value
H=Path(__file__).resolve().parent;R=H.parents[1]
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def main():
 plan=json.loads((H/'analysis_plan.json').read_text())
 for name,value in plan['source_hashes'].items():assert sha(H/name)==value
 rows=[];oracles=[];pairwise=[]
 ext=R/'experiments/52_multisource_randomized_20261028';fs=R/'experiments/50_discovery_allocation_20261028'
 t=pd.read_csv(ext/'data/scores_before_labels.csv').merge(pd.read_csv(ext/'data/query_labels.csv'),on=['assay','key'],validate='one_to_one');t['method']='Morgan2048_RF';t['campaign']=t.unit;t['seed']=11
 f=pd.read_csv(fs/'data/new_test_scores_before_labels.csv');f=f[f.seed.eq(11)].merge(pd.read_csv(fs/'data/new_test_query_labels.csv'),on=['assay','key'],validate='many_to_one');f['provider']='FS_Mol'
 for dataset,d,quotas in [('ToxCast',t,[1,4,8,16,32,64]),('FS_Mol',f,[1,4,8,16,32])]:
  for (method,campaign),g in d.groupby(['method','campaign'],sort=True):
   g=g.sort_values(['assay','key']).reset_index(drop=True);names=sorted(g.assay.unique());group=np.array([names.index(x) for x in g.assay]);y=g.y.to_numpy();score=g.score.to_numpy();key=g.key.to_numpy();pool=g.assay.to_numpy()
   for B in quotas:
    order=[np.array(sorted(np.flatnonzero(group==j),key=lambda i:(-score[i],key[i])),int) for j in range(len(names))];base=np.zeros(len(g),bool)
    for ix in order:base[ix[:B]]=True
    K=int(base.sum());oracle=hindsight_value(group,base,np.full(len(g),-1),K,y);Z=sum(min(B,len(ix)) for ix in order if not y[ix].sum());escape=any(min(B,len(ix))>=2 and bool(y[ix[:B]].sum()) for ix in order)
    oracles.append(dict(dataset=dataset,method=method,campaign=campaign,provider=g.provider.iloc[0],B=B,K=K,unconstrained_hindsight=min(K,int(y.sum())),certified_hindsight=oracle,unavoidable_negative_checks=Z,escape=escape))
    selected={}
    for algorithm in ALGORITHMS:
     if algorithm=='shield_search32' and B==64:continue
     start=time.perf_counter();res,ix,_=simulate(score,pool,key,y,B,algorithm,11);seconds=time.perf_counter()-start;assert res['baseline_lost']==0 and res['C']<=oracle
     if B==1:assert set(ix)==set(np.flatnonzero(base))
     rows.append(dict(dataset=dataset,method=method,campaign=campaign,provider=g.provider.iloc[0],B=B,algorithm=algorithm,seconds=seconds,oracle_gap=oracle-res['C'],**res));selected[algorithm]=set(ix)
    assert selected['recycling']==selected['shield_fixed']
    for alg,ix in selected.items():pairwise.append(dict(dataset=dataset,method=method,campaign=campaign,B=B,algorithm=alg,symmetric_set_difference=len(ix^selected['recycling'])))
   pd.DataFrame(rows).to_csv(H/'results/policies.csv',index=False);pd.DataFrame(oracles).to_csv(H/'results/oracles.csv',index=False);pd.DataFrame(pairwise).to_csv(H/'results/selected_set_differences.csv',index=False);print('COMPLETED',dataset,method,campaign,'rows',len(rows),flush=True)
 for name,value in json.loads((H/'checks/frozen_guards.json').read_text()).items():assert sha(R/name)==value
 out=dict(status='PASS',policy_values=len(rows),oracle_values=len(oracles),all_baseline_discoveries_protected=True,all_counts_below_exact_safe_path_oracle=True,all_quota1_sets_equal_baseline=True,all_static_shield_sets_equal_DPQR=True,research_exposed_reanalysis=True,no_new_confirmatory_p_values=True,no_new_source_outcomes=True,finished=datetime.datetime.now().astimezone().isoformat());(H/'checks/empirical.json').write_text(json.dumps(out,indent=2)+'\n');print(out)
if __name__=='__main__':main()
