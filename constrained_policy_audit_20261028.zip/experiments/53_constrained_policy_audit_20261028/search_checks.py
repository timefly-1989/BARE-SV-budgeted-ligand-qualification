"""Verify the certificate-aware lookahead against full-world and batch enumeration."""
from pathlib import Path
import itertools,json,numpy as np
from constrained import ConstrainedPolicy
from policies import GRID,WEIGHTS
H=Path(__file__).resolve().parent
u=np.array([.9,.6,.2,.8,.3,.1]);group=np.array([0,0,0,1,1,1]);worlds=np.array(list(itertools.product([0,1],repeat=6)));p0=ConstrainedPolicy(u,group,np.arange(6),2,'shield_search32');prior=np.ones(64)
for j in [0,1]:
 ix=np.flatnonzero(group==j);likes=np.ones((64,len(GRID)))
 for i in ix:likes*=np.where(worlds[:,i,None],p0.likelihood[i],1-p0.likelihood[i])
 prior*=likes@WEIGHTS
assert abs(prior.sum()-1)<1e-12
states=0;actions=0
for state in itertools.product([-1,0,1],repeat=6):
 state=np.array(state);active=state<0;r=4-int((~active).sum())
 if r<=0:continue
 p=ConstrainedPolicy(u,group,np.arange(6),2,'shield_search32')
 for i in np.flatnonzero(~active):p.reveal(int(i),int(state[i]))
 O=p.obligations();h=int(O.sum())
 if h>r:continue
 post=prior*np.all((worlds==state)|active,axis=1);post/=post.sum();q=post@worlds;assert np.max(np.abs(q[active]-p.mean()[active]))<1e-12
 allowed=np.flatnonzero(active&((h<r)|O));values={}
 for i in allowed:
  tail=[]
  for y in [0,1]:
   pr=post*(worlds[:,i]==y);prob=pr.sum();pr/=prob;qq=pr@worlds;oo=O.copy();oo[i]=False
   if y:oo[group==group[i]]=False
   remain=np.flatnonzero(active&(np.arange(6)!=i));score=-1.
   for batch in itertools.combinations(remain,r-1):
    if len(set(batch)-set(np.flatnonzero(oo)))<=r-1-int(oo.sum()):score=max(score,float(qq[list(batch)].sum()))
   assert score>=0;tail.append(score)
  values[i]=q[i]+(1-q[i])*tail[0]+q[i]*tail[1];actions+=1
 maximum=max(values.values());expected=min([i for i,v in values.items() if v>=maximum-1e-12],key=lambda i:(str(group[i]),str(i)));observed=p.action();assert observed==expected,(state,observed,expected,values);states+=1
out=dict(status='PASS',posterior_states=states,exhaustively_verified_candidate_values=actions,full_world_probability=prior.sum(),unchecked_labels_not_policy_inputs=True)
(H/'checks/search_verification.json').write_text(json.dumps(out,indent=2)+'\n');print(out)
