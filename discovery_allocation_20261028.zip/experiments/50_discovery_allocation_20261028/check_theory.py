"""Exhaustive finite checks complement analytic proofs; never prove generality."""
from pathlib import Path
import itertools,json
import numpy as np
from policies import simulate
H=Path(__file__).resolve().parent
def main():
    n=6;pool=np.array(['a']*3+['b']*3);u=np.array([.9,.5,.1,.8,.4,.2]);keys=np.array([str(i) for i in range(n)])
    certificate=0;price=0
    for y in itertools.product([0,1],repeat=n):
        for B in [1,2,3]:
            r,ix,_=simulate(u,pool,keys,y,B,'recycling');K=r['K'];G=np.argsort(-u,kind='stable')[:K]
            M=ix[:r['pilot_calls']];outside=set(M)-set(G);removed=set(G)-set(ix)
            assert len(outside)==len(removed)
            assert abs(u[G].sum()-u[ix].sum()-sum(u[list(removed)])+sum(u[list(outside)]))<1e-12
            certificate+=1;price+=1
    # No-prefix terminal certificate: every baseline pool is either hit, or
    # all of its baseline candidates are queried. Verify all unseen completions.
    U={0,1,3,4};transcripts=0
    for Sbits in itertools.product([0,1],repeat=n):
        S={i for i,b in enumerate(Sbits) if b};unknown=sorted(set(range(n))-S)
        for observed in itertools.product([0,1],repeat=len(S)):
            known=dict(zip(sorted(S),observed));hits={pool[i] for i in S if known[i]}
            criterion=all(p in hits or {i for i in U if pool[i]==p}<=S for p in set(pool))
            safe=True
            for values in itertools.product([0,1],repeat=len(unknown)):
                yy={**known,**dict(zip(unknown,values))};base={pool[i] for i in U if yy[i]}
                if not base<=hits:safe=False;break
            assert criterion==safe;transcripts+=1
    # All depth-two deterministic policies on four points, without queue
    # restrictions. A universal baseline-discovery guarantee can have ratio0.
    P=np.array(['a','a','b','b']);U={0,2};safe_policies=0
    for first in range(4):
        rest=[i for i in range(4) if i!=first]
        for second0,second1 in itertools.product(rest,repeat=2):
            valid=True
            for y in itertools.product([0,1],repeat=4):
                ix=[first,second1 if y[first] else second0]
                if not {P[i] for i in U if y[i]}<={P[i] for i in ix if y[i]}:valid=False;break
            if valid:
                y=[0,1,0,1];ix=[first,second1 if y[first] else second0]
                assert sum(y[i] for i in ix)==0;safe_policies+=1
    assert safe_policies>0
    out=dict(status='PASS',coverage_cases=certificate,price_cases=price,unrestricted_terminal_transcripts=transcripts,
        all_depth_two_policies=36,universally_safe_policies=safe_policies,worst_case_safe_recovery=0,worst_case_unconstrained_oracle=2,
        caveat='Finite exhaustive implementation checks, not originality certification or a replacement for analytic proofs')
    (H/'checks/theory_checks.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
if __name__=='__main__':main()
