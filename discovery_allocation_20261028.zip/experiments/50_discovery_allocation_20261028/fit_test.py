"""Fit on support activities only; freeze predictions before query evaluation."""
import os
for k in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','VECLIB_MAXIMUM_THREADS']:os.environ[k]='1'
from pathlib import Path
import datetime,gzip,hashlib,json,tarfile,time
import numpy as np,pandas as pd
from rdkit import Chem,DataStructs,RDLogger
from rdkit.Chem import rdFingerprintGenerator
from sklearn.ensemble import RandomForestClassifier
from catboost import CatBoostClassifier
import joblib
H=Path(__file__).resolve().parent;A=H.parent/'49_real_endpoint_readiness_20261027'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def main():
    RDLogger.DisableLog('rdApp.*');start=time.perf_counter()
    d=pd.read_csv(H/'data/new_test_partition.csv');s=d[d.role.eq('support')].copy();q=d[d.role.eq('query')].copy()
    permitted={(r.assay,int(r.source_row)) for r in s.itertuples()};labels={}
    source_members=pd.read_csv(A/'sources/test_member_checksums.csv').set_index('assay').member.to_dict()
    with tarfile.open(A/'raw/fsmol.tar') as z:
        for assay in sorted(set(s.assay)):
            raw=gzip.decompress(z.extractfile(source_members[assay]).read())
            for n,line in enumerate(raw.splitlines(),1):
                if (assay,n) in permitted:
                    obj=json.loads(line);labels[(assay,n)]=int(float(obj['Property']))
    s['y']=[labels[(r.assay,int(r.source_row))] for r in s.itertuples()]
    s[['assay','key','y']].to_csv(H/'data/support_labels.csv',index=False)
    gen=rdFingerprintGenerator.GetMorganGenerator(radius=2,fpSize=2048)
    fps={g:gen.GetFingerprint(Chem.MolFromSmiles(sm)) for g,sm in d[['graph_key','smiles']].drop_duplicates('graph_key').itertuples(index=False,name=None)}
    rows=[];timings=[];support_audit=[]
    for assay in sorted(set(d.assay)):
        t=s[s.assay.eq(assay)].sort_values('key');v=q[q.assay.eq(assay)].sort_values('key')
        assert len(t)>0 and len(v)>0
        x=np.stack([np.asarray(fps[k],dtype=np.uint8) for k in t.graph_key]);xx=np.stack([np.asarray(fps[k],dtype=np.uint8) for k in v.graph_key]);y=t.y.to_numpy(int)
        support_audit.append(dict(assay=assay,support=len(t),support_actives=int(y.sum()),query=len(v),single_class=len(set(y))<2))
        for seed in [11,23,37]:
            for method in ['Morgan2048_RF','Morgan2048_CatBoost','active_neighbour']:
                t0=time.perf_counter()
                if method=='active_neighbour':
                    pos=[fps[k] for k,a in zip(t.graph_key,y) if a]
                    p=np.array([max(DataStructs.BulkTanimotoSimilarity(fps[k],pos)) if pos else 0. for k in v.graph_key]);model=None
                elif len(set(y))<2:p=np.full(len(v),(int(y.sum())+1)/(len(y)+2));model=None
                else:
                    if method.endswith('_RF'):model=RandomForestClassifier(n_estimators=256,min_samples_leaf=2,max_features='sqrt',n_jobs=4,random_state=seed)
                    else:model=CatBoostClassifier(iterations=400,depth=5,learning_rate=.05,l2_leaf_reg=5,loss_function='Logloss',random_seed=seed,verbose=False,thread_count=4,allow_writing_files=False)
                    model.fit(x,y);p=model.predict_proba(xx)[:,list(model.classes_).index(1)]
                if model is not None:joblib.dump(model,H/f'models/{assay}_{method}_{seed}.joblib')
                for r,score in zip(v.itertuples(),p):rows.append(dict(campaign=r.campaign,assay=assay,key=r.key,graph_key=r.graph_key,method=method,seed=seed,score=float(score)))
                timings.append(dict(assay=assay,method=method,seed=seed,seconds=time.perf_counter()-t0))
        print('SCORED',assay,len(v),'query rows; no query labels used',flush=True)
    out=pd.DataFrame(rows);path=H/'data/new_test_scores_before_labels.csv';out.to_csv(path,index=False)
    pd.DataFrame(timings).to_csv(H/'timing/model_fit_predict.csv',index=False)
    pd.DataFrame(support_audit).to_csv(H/'results/support_audit.csv',index=False)
    freeze=dict(timestamp_local=datetime.datetime.now().astimezone().isoformat(),scores_sha256=sha(path),protocol_sha256=sha(H/'new_test_protocol.json'),
      partition_sha256=sha(H/'data/new_test_partition.csv'),support_labels_sha256=sha(H/'data/support_labels.csv'),
      fit_script_sha256=sha(__file__),query_labels_read=False,query_labels_exported=False,
      score_rows=len(out),unique_queries=len(q),seconds=time.perf_counter()-start)
    (H/'prediction_freeze.json').write_text(json.dumps(freeze,indent=2)+'\n');print('PREDICTIONS_FROZEN',freeze['scores_sha256'],flush=True)
if __name__=='__main__':main()
