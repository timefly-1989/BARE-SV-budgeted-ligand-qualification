"""Replay the new locked test from public scores and official FS-Mol labels.

Usage: python replay_public.py --archive /path/to/fsmol.tar [--all]
Raw source structures/activities are restored locally, never bundled for
redistribution. Without --all the complete primary scorer/seed is replayed.
"""
from pathlib import Path
import argparse,gzip,hashlib,json,tarfile,time
import numpy as np,pandas as pd
from policies import simulate
H=Path(__file__).resolve().parent
def restore(archive):
    rows=pd.read_csv(H/'data/partition_rows.csv');wanted={(r.assay,int(r.source_row)):r for r in rows.itertuples()}
    members=pd.read_csv(H/'sources/test_member_checksums.csv').set_index('assay').member.to_dict()
    objrows=[];labels=[]
    with tarfile.open(archive) as z:
        for assay in sorted(set(rows.assay)):
            for n,line in enumerate(gzip.decompress(z.extractfile(members[assay]).read()).splitlines(),1):
                if (assay,n) not in wanted:continue
                r=wanted[(assay,n)];o=json.loads(line)
                objrows.append({**r._asdict(),'smiles':o['SMILES']})
                if r.role=='query':labels.append(dict(assay=assay,key=r.key,y=int(float(o['Property']))))
    d=pd.DataFrame(objrows).drop(columns=['Index'],errors='ignore');y=pd.DataFrame(labels)
    assert len(d)==len(rows) and len(y)==5498
    return d,y
def refit_primary(d,archive):
    from rdkit import Chem,RDLogger
    from rdkit.Chem import rdFingerprintGenerator
    from sklearn.ensemble import RandomForestClassifier
    RDLogger.DisableLog('rdApp.*');gen=rdFingerprintGenerator.GetMorganGenerator(radius=2,fpSize=2048)
    train=d[d.role.eq('support')];wanted={(r.assay,int(r.source_row)) for r in train.itertuples()};labels={}
    members=pd.read_csv(H/'sources/test_member_checksums.csv').set_index('assay').member.to_dict()
    with tarfile.open(archive) as z:
        for assay in sorted(set(train.assay)):
            for n,line in enumerate(gzip.decompress(z.extractfile(members[assay]).read()).splitlines(),1):
                if (assay,n) in wanted:labels[(assay,n)]=int(float(json.loads(line)['Property']))
    saved=pd.read_csv(H/'data/new_test_scores_before_labels.csv');saved=saved[saved.method.eq('Morgan2048_RF')&saved.seed.eq(11)].set_index('key').score
    worst=0.;models=0
    for assay,g in d.groupby('assay'):
        t=g[g.role.eq('support')].sort_values('key');q=g[g.role.eq('query')].sort_values('key')
        x=np.stack([np.asarray(gen.GetFingerprint(Chem.MolFromSmiles(s)),dtype=np.uint8) for s in t.smiles]);v=np.stack([np.asarray(gen.GetFingerprint(Chem.MolFromSmiles(s)),dtype=np.uint8) for s in q.smiles])
        y=np.array([labels[(r.assay,int(r.source_row))] for r in t.itertuples()])
        if len(set(y))<2:p=np.full(len(v),(int(y.sum())+1)/(len(y)+2))
        else:
            model=RandomForestClassifier(n_estimators=256,min_samples_leaf=2,max_features='sqrt',n_jobs=4,random_state=11);model.fit(x,y);p=model.predict_proba(v)[:,list(model.classes_).index(1)]
        error=float(np.max(np.abs(p-saved.loc[q.key].to_numpy())));assert error<1e-12,(assay,error)
        worst=max(worst,error);models+=1
    return dict(refitted_primary_models=models,max_probability_error=worst)
def main():
    parser=argparse.ArgumentParser();parser.add_argument('--archive',type=Path,required=True);parser.add_argument('--all',action='store_true');parser.add_argument('--refit-primary',action='store_true');a=parser.parse_args();start=time.perf_counter()
    partition,labels=restore(a.archive)
    ycheck=json.loads((H/'evaluation_opened.json').read_text())['labels_sha256']
    # Saved source order is assay/source_row; restoration uses that same order.
    encoded=labels.to_csv(index=False).encode();assert hashlib.sha256(encoded).hexdigest()==ycheck
    s=pd.read_csv(H/'data/new_test_scores_before_labels.csv').merge(labels,on=['assay','key'],validate='many_to_one')
    expected=pd.read_csv(H/'results/new_campaigns.csv')
    if not a.all:expected=expected[expected.method.eq('Morgan2048_RF')&expected.seed.eq(11)]
    groups={key:g.sort_values(['assay','key']).reset_index(drop=True) for key,g in s.groupby(['campaign','method','seed'])}
    checked=0;trace=[]
    for r in expected.itertuples():
        g=groups[(r.campaign,r.method,r.seed)];out,ix,_=simulate(g.score,g.assay,g.key,g.y,int(r.B),r.algorithm,int(r.seed))
        for k in ['C','coverage','baseline_lost','K']:assert out[k]==getattr(r,k),(r.campaign,r.algorithm,k)
        assert abs(out['score_sum']-r.score_sum)<1e-9
        if r.algorithm=='recycling':assert out['pilot_calls']==int(r.pilot_calls)
        if r.method=='Morgan2048_RF' and r.seed==11 and r.B==4:
            for t,i in enumerate(ix,1):trace.append(dict(campaign=r.campaign,algorithm=r.algorithm,step=t,assay=g.assay.iloc[i],key=g.key.iloc[i]))
        checked+=1
    result=dict(status='PASS',source_labels_sha256_verified=True,policy_values_replayed=checked,decision_trace_rows=len(trace),seconds=time.perf_counter()-start)
    if a.refit_primary:result.update(refit_primary(partition,a.archive))
    (H/'checks/public_replay.json').write_text(json.dumps(result,indent=2)+'\n');pd.DataFrame(trace).to_csv(H/'results/new_primary_selected_keys.csv',index=False)
    print(json.dumps(result),flush=True)
if __name__=='__main__':main()
