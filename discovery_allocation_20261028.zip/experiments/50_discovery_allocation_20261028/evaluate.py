"""Locked complete-campaign evaluation; labels revealed only to simulator."""
from pathlib import Path
import argparse,datetime,gzip,hashlib,itertools,json,tarfile,time
import numpy as np,pandas as pd
from policies import CONTROLS,simulate
H=Path(__file__).resolve().parent;E=H.parent
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def lock():
    files=['policies.py','evaluate.py','design_test.py','fit_test.py']
    target=H/'policy_lock.json'
    obj=dict(timestamp_local=datetime.datetime.now().astimezone().isoformat(),sha256={n:sha(H/n) for n in files},
        budgets=[1,2,4,8,16,32],primary_saved_budget=8,primary_new_budget=4,
        controls=CONTROLS,ENS_style_max_cap=8,ENS_style_predictor='Reference scorer in saved qualification; primary RF seed11 in new test',
        sequential_controls_other_predictors=False,
        positive_support_selection=False,campaigns_redefined_after_outcomes=False)
    if target.exists():
        old=json.loads(target.read_text());assert old['sha256']==obj['sha256'],'Frozen policy source changed'
    else:target.write_text(json.dumps(obj,indent=2)+'\n')
    print('POLICY_LOCKED',sha(target),flush=True)
def extract_test_labels():
    f=json.loads((H/'prediction_freeze.json').read_text());assert sha(H/'data/new_test_scores_before_labels.csv')==f['scores_sha256']
    d=pd.read_csv(H/'data/new_test_partition.csv');q=d[d.role.eq('query')];permitted={(r.assay,int(r.source_row)):r.key for r in q.itertuples()};rows=[]
    a=E/'49_real_endpoint_readiness_20261027';members=pd.read_csv(a/'sources/test_member_checksums.csv').set_index('assay').member.to_dict()
    with tarfile.open(a/'raw/fsmol.tar') as z:
        for assay in sorted(set(q.assay)):
            for n,line in enumerate(gzip.decompress(z.extractfile(members[assay]).read()).splitlines(),1):
                if (assay,n) in permitted:
                    obj=json.loads(line);rows.append(dict(assay=assay,key=permitted[(assay,n)],y=int(float(obj['Property']))))
    y=pd.DataFrame(rows);assert len(y)==len(q);y.to_csv(H/'data/new_test_query_labels.csv',index=False)
    (H/'evaluation_opened.json').write_text(json.dumps(dict(timestamp_local=datetime.datetime.now().astimezone().isoformat(),
        prediction_freeze_sha256=sha(H/'prediction_freeze.json'),policy_lock_sha256=sha(H/'policy_lock.json'),labels_sha256=sha(H/'data/new_test_query_labels.csv'),
        predictions_unchanged_before_label_export=True,public_existing_activity_not_new_wetlab=True),indent=2)+'\n')
    return y
def policies_for(primary,B):
    seq={'latent_greedy','latent_TS','latent_UCB','score_conservative_UCB','ENS_style32'}
    return [a for a in CONTROLS if (primary or a not in seq) and (a!='ENS_style32' or B<=8)]
def campaign(g,scope,identity,method,seed,primary,rows):
    g=g.sort_values(['pool','key']).reset_index(drop=True)
    for B in [1,2,4,8,16,32]:
        for a in policies_for(primary,B):
            start=time.perf_counter();r,ix,_=simulate(g.score,g.pool,g.key,g.y,B,a,seed)
            rows.append(dict(scope=scope,campaign=identity,method=method,seed=seed,B=B,algorithm=a,**r,
                positives=int(g.y.sum()),positive_pools=int(g.groupby('pool').y.sum().gt(0).sum()),pools=g.pool.nunique(),seconds=time.perf_counter()-start))
def saved():
    source=E/'35_stage_evidence_upgrade_20261027/results/analysis_scores.csv';d=pd.read_csv(source);rows=[]
    for cohort,x in d.groupby('cohort',sort=True):
        parts=list(x.groupby('fold')) if cohort=='development' else [(cohort,x)]
        for cid,g in parts:
            for method in ['chemeleon_compact_qualification','morgan_conditional','strict_catboost_conditional','rf_joint']:
                z=g[['pocket_id','candidate_id','y',method]].rename(columns={'pocket_id':'pool','candidate_id':'key',method:'score'})
                campaign(z,cohort,str(cid),method,11,method=='chemeleon_compact_qualification',rows)
            print('SAVED_CAMPAIGN',cohort,cid,flush=True)
            pd.DataFrame(rows).to_csv(H/'results/saved_campaigns.csv',index=False)
    # Previously exposed activity campaign; all saved scores retained, with
    # sequential controls on the preselected scorer/seed only.
    s=pd.read_csv(E/'36_external_activity_benchmark_20261027/results/scores_before_labels.csv')
    y=pd.read_csv(E/'36_external_activity_benchmark_20261027/data/evaluation_labels.csv');s=s.merge(y,on=['assay','key'],validate='many_to_one')
    methods=[c for c in s if c not in ['assay','key','protocol','seed','y']]
    for (condition,seed),g in s.groupby(['protocol','seed']):
        for method in methods:
            z=g[['assay','key','y',method]].rename(columns={'assay':'pool',method:'score'})
            campaign(z,'LIT-PCBA_replay',condition,method,int(seed),False,rows)
        print('ACTIVITY_REPLAY',condition,seed,flush=True);pd.DataFrame(rows).to_csv(H/'results/saved_campaigns.csv',index=False)
    return rows
def new():
    if (H/'data/new_test_query_labels.csv').exists():y=pd.read_csv(H/'data/new_test_query_labels.csv')
    else:y=extract_test_labels()
    s=pd.read_csv(H/'data/new_test_scores_before_labels.csv');s=s.merge(y,on=['assay','key'],validate='many_to_one');rows=[]
    for (cid,method,seed),g in s.groupby(['campaign','method','seed']):
        z=g[['assay','key','y','score']].rename(columns={'assay':'pool'})
        campaign(z,'FS-Mol_locked_test',cid,method,int(seed),method=='Morgan2048_RF' and seed==11,rows)
        pd.DataFrame(rows).to_csv(H/'results/new_campaigns.csv',index=False)
        print('NEW_CAMPAIGN',cid,method,seed,flush=True)
    return rows
def primary_test():
    d=pd.read_csv(H/'results/new_campaigns.csv');q=d[d.method.eq('Morgan2048_RF')&d.seed.eq(11)&d.B.eq(4)]
    p=q.pivot(index='campaign',columns='algorithm',values=['C','baseline_lost'])
    deltas=[(p['C']['recycling']-p['C']['uniform']).to_numpy(),(p['baseline_lost']['global']-p['baseline_lost']['recycling']).to_numpy()]
    tests=[]
    for name,v in zip(['Recovery: recycling minus uniform','Baseline discovery losses: global minus recycling'],deltas):
        values=np.array([sum(s*x for s,x in zip(sign,v)) for sign in itertools.product([-1,1],repeat=len(v))])
        pval=float(np.mean(np.abs(values)>=abs(v.sum())-1e-12))
        tests.append(dict(contrast=name,differences=v.astype(int).tolist(),campaigns=len(v),nonzero=int(np.count_nonzero(v)),p=pval))
    order=np.argsort([r['p'] for r in tests]);last=0.
    for rank,j in enumerate(order):last=max(last,min(1.,(len(tests)-rank)*tests[j]['p']));tests[j]['Holm_p']=last
    report=dict(primary_budget=4,primary_predictor='Morgan2048_RF',primary_seed=11,tests=tests,
        interpretation='Conditional campaign-level paired sign-flip analysis; independent symmetric differences assumed, seven provenance-blocked constructed campaigns are not certified independent biological families.',
        secondary_budgets_and_predictors='Exploratory; no unadjusted confirmatory claims',public_data_test_not_prospective_acquisition=True)
    (H/'results/new_primary_tests.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report),flush=True)
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--mode',choices=['lock','new','saved','test'],required=True);args=p.parse_args()
    if args.mode=='lock':lock()
    elif args.mode=='new':new();primary_test()
    elif args.mode=='saved':saved()
    else:primary_test()
