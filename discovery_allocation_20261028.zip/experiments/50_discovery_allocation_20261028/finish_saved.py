"""Complete available-score historical controls; never impute missing scores.

All new development policies were already run before the original driver's
missing-score assertion. Preserve those outputs and skip absent historical
CatBoost/RF columns. Existing full LIT-PCBA replay remains experiment45.
"""
from pathlib import Path
import json
import pandas as pd
from evaluate import campaign
H=Path(__file__).resolve().parent;E=H.parent
def main():
    target=H/'results/saved_campaigns.csv';old=pd.read_csv(target);rows=old[old.scope.eq('development')].to_dict('records');audit=[]
    d=pd.read_csv(E/'35_stage_evidence_upgrade_20261027/results/analysis_scores.csv')
    for cohort,g in d[~d.cohort.eq('development')].groupby('cohort',sort=True):
        for method in ['chemeleon_compact_qualification','morgan_conditional','strict_catboost_conditional','rf_joint']:
            if not g[method].notna().all():
                audit.append(dict(cohort=cohort,method=method,status='NOT_AVAILABLE',reason='No complete archived scores; no imputation or refitting'))
                continue
            z=g[['pocket_id','candidate_id','y',method]].rename(columns={'pocket_id':'pool','candidate_id':'key',method:'score'})
            campaign(z,cohort,cohort,method,11,method=='chemeleon_compact_qualification',rows)
        pd.DataFrame(rows).to_csv(target,index=False);print('HISTORICAL_COMPLETE',cohort,flush=True)
    (H/'checks/saved_scope.json').write_text(json.dumps(dict(missing_historical_scores=audit,
       lit_pcba='Existing experiment45 all1,470 values retained; not recomputed by the new driver',
       change='Data-availability handling only; frozen policy code and new-test specification unchanged'),indent=2)+'\n')
if __name__=='__main__':main()
