"""Freeze a new activity allocation test using inputs, never query activities."""
from pathlib import Path
import csv,datetime,hashlib,json

H=Path(__file__).resolve().parent; R=H.parents[1]; A=R/'experiments/49_real_endpoint_readiness_20261027'
SALT='DPQR|test|20261028|'
def digest(s): return hashlib.sha256(s.encode()).hexdigest()
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def main():
    groups=list(csv.DictReader((A/'results/provenance_groups.csv').open()))
    reps=[]
    for g in groups:
        name=min(g['names'].split('|'),key=lambda n:digest(SALT+n))
        reps.append(dict(assay=name,source_panel_group=g['source_panel_group']))
    reps.sort(key=lambda x:digest(SALT+'campaign|'+x['assay']))
    for i,x in enumerate(reps): x['campaign']=f'FS_campaign_{i//4+1:02d}'
    lookup={x['assay']:x for x in reps}
    inputs=[];seen=set()
    for row in csv.DictReader((A/'data/test_inputs_only.csv').open()):
        if row['assay'] not in lookup: continue
        k=(row['assay'],row['graph_key'])
        if k in seen: continue
        seen.add(k);inputs.append({**row,**lookup[row['assay']]})
    # A graph has one global support/query role. Shared query connectivities
    # have one campaign owner selected by hashing, without inspecting labels.
    owners={}
    for x in inputs:
        g=x['graph_key'];owners.setdefault(g,set()).add(x['campaign'])
    owners={g:min(v,key=lambda c:digest(SALT+'owner|'+g+'|'+c)) for g,v in owners.items()}
    for x in inputs:
        x['key']=digest(x['assay']+'|'+x['graph_key'])
        x['role']='support_eligible' if int(digest(SALT+'role|'+x['graph_key']),16)%4==0 else 'query'
        if x['role']=='query' and x['campaign']!=owners[x['graph_key']]: x['role']='other_campaign_owner'
    for assay in lookup:
        s=sorted((x for x in inputs if x['assay']==assay and x['role']=='support_eligible'),key=lambda x:digest(SALT+'support|'+x['graph_key']))
        for i,x in enumerate(s): x['role']='support' if i<32 else 'support_unused'
    p=H/'data/new_test_partition.csv'
    with p.open('w') as f:
        w=csv.DictWriter(f,fieldnames=list(inputs[0]));w.writeheader();w.writerows(inputs)
    assert len(lookup)==28 and len({x['campaign'] for x in reps})==7
    query=[x for x in inputs if x['role']=='query'];support=[x for x in inputs if x['role']=='support']
    assert not {x['graph_key'] for x in query}&{x['graph_key'] for x in support}
    graph_campaign={}
    for x in query: graph_campaign.setdefault(x['graph_key'],set()).add(x['campaign'])
    assert all(len(v)==1 for v in graph_campaign.values())
    protocol=dict(timestamp_local=datetime.datetime.now().astimezone().isoformat(),
        analysis='New locked public-activity allocation test, not prospective wet-lab acquisition or full D/V/Q qualification',
        source='Official FS-Mol test split; assay-median activity labels supplied by dataset',
        selection='One SHA256-selected assay per previously input-audited provenance component; no activity-based eligibility',
        campaigns='Seven hash-partitioned campaigns of four source-disjoint representative assays; no assertion of independent protein families',
        support='At most 32 globally hash-designated support graphs per assay, no class stratification',
        query='Every remaining designated query; first source row per connectivity; shared query graphs assigned to one campaign',
        endpoint='Official Property; balanced few-shot QSAR endpoint, not naturally sparse forward screening',
        source_license='FS-Mol source metadata has differing license notices; raw structures excluded from redistribution',
        primary_predictor='Morgan2048_RF',primary_seed=11,primary_cap=4,
        seeds=[11,23,37],other_predictors=['Morgan2048_CatBoost','active_neighbour'],
        budgets=[1,2,4,8,16,32],
        controls=['uniform','global','forecast_coverage_lambda_grid','observed_coverage_lambda_grid',
          'latent_greedy','latent_TS','latent_UCB','score_conservative_UCB','ENS_style_shortlist32'],
        coverage_weights=[0.25,1,4,16,64],latent_grid=[-3,-2.5,-2,-1.5,-1,-.5,0,.5,1,1.5,2,2.5,3],
        latent_prior_sd=1,conservative_alpha=0,
        primary_comparisons=['recycling versus uniform recovery','recycling versus global retention of baseline discoveries'],
        primary_inference='Seven complete campaign differences; exact paired sign flips plus Holm for two primary tests; no seeds-as-replicates',
        score_freeze_before_query_label_export=True,all_selected_campaigns_retained=True,
        assay_count=28,campaign_count=7,query_rows=len(query),support_rows=len(support),
        partition_sha256=sha(p),source_input_sha256=sha(A/'data/test_inputs_only.csv'),
        source_group_sha256=sha(A/'results/provenance_groups.csv'),script_sha256=sha(__file__))
    (H/'new_test_protocol.json').write_text(json.dumps(protocol,indent=2)+'\n')
    (H/'data/campaign_design.json').write_text(json.dumps(reps,indent=2)+'\n')
    print('LOCKED',len(query),'queries',len(support),'support rows; 28 assays / 7 campaigns',flush=True)
if __name__=='__main__': main()
