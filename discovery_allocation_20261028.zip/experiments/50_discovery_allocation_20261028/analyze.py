"""Generate manuscript tables and editable vector figures from complete runs."""
from pathlib import Path
import json
import numpy as np,pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch,FancyArrowPatch
H=Path(__file__).resolve().parent
REF='chemeleon_compact_qualification'
NAMES={'uniform':'Uniform prefixes','global':'Global top-K','recycling':'Discovery-preserving recycling',
 'forecast_4':'Forecast coverage (4)','observed_4':'Observed coverage (4)','latent_greedy':'Posterior greedy',
 'latent_TS':'Pool-latent Thompson','latent_UCB':'Pool-latent UCB','score_conservative_UCB':'Score-conservative UCB','ENS_style32':'ENS-style shortlist search'}
ORDER=list(NAMES)
COLORS={'uniform':'#596c80','global':'#db7b2b','recycling':'#177c80','forecast_4':'#7c64aa','observed_4':'#b04765',
 'latent_greedy':'#566b2f','latent_TS':'#668dc3','latent_UCB':'#9a6033','score_conservative_UCB':'#a386ac','ENS_style32':'#292e3b'}
PLOT={**NAMES,'recycling':'DPQR','latent_TS':'Thompson','latent_UCB':'Posterior UCB','ENS_style32':'ENS-style (32)'}
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':12,'axes.spines.top':False,'axes.spines.right':False,
 'pdf.fonttype':42,'ps.fonttype':42,'svg.fonttype':'none','savefig.bbox':'tight'})
def export(fig,name):
 for ext in ['pdf','svg','png']:fig.savefig(H/f'figures/{name}.{ext}',dpi=200)
 plt.close(fig)
def aggregate(d):return d.groupby(['B','algorithm'],sort=False)[['C','coverage','baseline_lost','K','pilot_calls']].sum().reset_index()
def make_table(path,caption,label,headers,rows,note):
 s='\\begin{table}[!htbp]\\centering\n\\caption{'+caption+'}\\label{'+label+'}\n\\small\n'
 s+='\\begin{tabular}{l'+'r'*(len(headers)-1)+'}\\toprule\n'+' & '.join(headers)+' \\\\\\midrule\n'
 s+='\n'.join(' & '.join(str(v) for v in row)+' \\\\' for row in rows)+'\n\\bottomrule\\end{tabular}\n'
 s+='\\par\\vspace{3pt}\\footnotesize '+note+'\n\\end{table}\n';path.write_text(s)
def main():
 saved=pd.read_csv(H/'results/saved_campaigns.csv');new=pd.read_csv(H/'results/new_campaigns.csv')
 dev=aggregate(saved[saved.scope.eq('development')&saved.method.eq(REF)])
 test=aggregate(new[new.method.eq('Morgan2048_RF')&new.seed.eq(11)])
 dev.to_csv(H/'results/development_reference_summary.csv',index=False);test.to_csv(H/'results/new_primary_summary.csv',index=False)
 qdev=dev[dev.B.eq(8)].set_index('algorithm');qtest=test[test.B.eq(4)].set_index('algorithm')
 rows=[]
 for a in ORDER:
  r=qdev.loc[a];s=qtest.loc[a];rows.append([NAMES[a],f'{int(r.C)}/{int(r.coverage)}/{int(r.baseline_lost)}',f'{int(s.C)}/{int(s.coverage)}/{int(s.baseline_lost)}'])
 note=r'Entries are recovered positives / discovered pools / lost baseline-discovered pools ($C/\mathrm{Cov}/L_U$). Development sums five held-out campaigns at 672 checks; the new activity test sums seven complete campaigns at 112 checks. Each column fixes its predictor and scores. The sequential controls are declared finite-pool adaptations; their source-paper regret guarantees are not transferred.'
 make_table(H/'tables/allocation_controls.tex','Matched allocation controls at the designated budgets.','tab:allocation-controls',['Policy','Development','New activity test'],rows,note)
 make_table(H/'tables/allocation_controls_zh.tex','指定预算下的匹配分配对照。','tab:allocation-controls',['策略','开发集','新活性测试'],rows,
 '数值依次为回收阳性/发现池/丢失的基线发现池。开发集汇总五个留出活动，共672次检查；新活性测试汇总七个完整活动，共112次检查。每列固定预测器及得分。顺序对照为声明的有限候选池适配，不沿用来源论文的遗憾保证。')
 z=new[new.method.eq('Morgan2048_RF')&new.seed.eq(11)&new.B.eq(4)]
 p=z.pivot(index='campaign',columns='algorithm',values=['C','coverage','baseline_lost'])
 rows=[]
 for i,c in enumerate(p.index,1):
  rows.append([i,int(p.loc[c,('C','uniform')]),int(p.loc[c,('C','recycling')]),int(p.loc[c,('C','global')]),int(p.loc[c,('coverage','uniform')]),int(p.loc[c,('coverage','recycling')]),int(p.loc[c,('coverage','global')])])
 make_table(H/'tables/new_campaigns.tex','Complete campaigns in the locked public-activity test.','tab:new-campaigns',
 ['Campaign',r'$C_U$',r'$C_R$',r'$C_G$',r'$\mathrm{Cov}_U$',r'$\mathrm{Cov}_R$',r'$\mathrm{Cov}_G$'],rows,
 'Each campaign contains four prespecified assays and spends 16 query checks. Subscripts denote uniform, recycling and global policies. Support activities are excluded from query recovery and query-budget accounting. No campaign was selected or discarded using query activities.')
 make_table(H/'tables/new_campaigns_zh.tex','冻结公共活性测试中的完整活动。','tab:new-campaigns',
 ['活动',r'$C_U$',r'$C_R$',r'$C_G$',r'$\mathrm{Cov}_U$',r'$\mathrm{Cov}_R$',r'$\mathrm{Cov}_G$'],rows,
 '每个活动由四个预先规定的测定构成，使用16次查询检查。下标依次为统一、回收、全局策略。支持集活性不计入查询回收量和查询预算。没有按查询活性选择或排除活动。')
 # Empirical Pareto membership at each fixed budget; no claim about unseen policies.
 fronts=[]
 for scope,d in [('development',dev),('new_activity',test)]:
  for B,g in d.groupby('B'):
   for r in g.itertuples():
    dominated=any(t.C>=r.C and t.coverage>=r.coverage and (t.C>r.C or t.coverage>r.coverage) for t in g.itertuples())
    fronts.append(dict(scope=scope,B=B,algorithm=r.algorithm,C=r.C,coverage=r.coverage,baseline_lost=r.baseline_lost,empirically_nondominated=not dominated))
 pd.DataFrame(fronts).to_csv(H/'results/empirical_pareto.csv',index=False)
 fig,axes=plt.subplots(1,3,figsize=(9.4,3.8),sharex=True,sharey=True)
 for ax,B in zip(axes,[4,8,16]):
  g=dev[dev.B.eq(B)]
  ax.scatter(g.coverage,g.C,c='#c4cbd0',s=25,label='Other declared controls')
  for a in ['uniform','global','recycling','observed_4','forecast_4','ENS_style32']:
   q=g[g.algorithm.eq(a)]
   if len(q):ax.scatter(q.coverage,q.C,c=COLORS[a],marker={'uniform':'s','global':'^','recycling':'D'}.get(a,'o'),s=55,label=PLOT[a])
  front=[r for r in g.itertuples() if not any(t.C>=r.C and t.coverage>=r.coverage and (t.C>r.C or t.coverage>r.coverage) for t in g.itertuples())]
  points=sorted(set((r.coverage,r.C) for r in front));ax.plot([x for x,y in points],[y for x,y in points],'--',c='#718088',lw=1,zorder=0)
  ax.set_title(f'Quota B = {B}');ax.set_xlim(0,29);ax.set_ylim(0,220);ax.set_xlabel('Discovered pockets');ax.grid(alpha=.16)
 axes[0].set_ylabel('Recovered joint positives');handles,labels=axes[1].get_legend_handles_labels();fig.legend(handles,labels,loc='lower center',bbox_to_anchor=(.5,-.29),ncol=3,frameon=False,fontsize=10);fig.tight_layout();export(fig,'development_pareto')
 fig,axes=plt.subplots(1,3,figsize=(9.4,3.8))
 baseline=test[test.algorithm.eq('uniform')].set_index('B').C
 for a in ['uniform','global','recycling','observed_4','latent_UCB','ENS_style32']:
  g=test[test.algorithm.eq(a)].sort_values('B');style={'marker':'D' if a=='recycling' else 'o','linestyle':'-','markersize':5 if a=='recycling' else 4,'zorder':20 if a=='recycling' else 2}
  axes[0].plot(g.B,[r.C-baseline.loc[r.B] for r in g.itertuples()],c=COLORS[a],label=PLOT[a],**style);axes[1].plot(g.B,g.baseline_lost,c=COLORS[a],**style)
 for ax in axes[:2]:ax.set_xscale('log',base=2);ax.set_xticks([1,2,4,8,16,32],labels=['1','2','4','8','16','32']);ax.set_xlabel('Baseline quota per assay');ax.grid(alpha=.16)
 axes[0].set_ylabel('Actives gained over uniform');axes[1].set_ylabel('Lost baseline discoveries')
 xx=np.arange(1,8)
 for a,shift in [('uniform',-.24),('recycling',0),('global',.24)]:axes[2].bar(xx+shift,p['C'][a],width=.23,color=COLORS[a],label=NAMES[a])
 axes[2].set_xticks(xx);axes[2].set_xlabel('Complete campaign');axes[2].set_ylabel('Actives at 16 checks');axes[2].set_ylim(0,17)
 handles,labels=axes[0].get_legend_handles_labels();fig.legend(handles,labels,loc='lower center',bbox_to_anchor=(.5,-.26),ncol=3,frameon=False,fontsize=10);fig.tight_layout();export(fig,'new_activity_campaigns')
 fig,axes=plt.subplots(1,2,figsize=(9,3.5))
 g=test[test.B.eq(4)]
 axes[0].scatter(g.coverage,g.C,c='#c4cbd0',s=25,label='Other coverage weights');axes[1].scatter(g.baseline_lost,g.C,c='#c4cbd0',s=25)
 for a in ORDER:
  q=g[g.algorithm.eq(a)];axes[0].scatter(q.coverage,q.C,c=COLORS[a],s=55,marker={'uniform':'s','global':'^','recycling':'D'}.get(a,'o'),label=PLOT[a]);axes[1].scatter(q.baseline_lost,q.C,c=COLORS[a],s=55,marker={'uniform':'s','global':'^','recycling':'D'}.get(a,'o'))
 for ax,field in zip(axes,['coverage','baseline_lost']):
  front=[r for r in g.itertuples() if not any(t.C>=r.C and (t.coverage>=r.coverage if field=='coverage' else t.baseline_lost<=r.baseline_lost) and (t.C>r.C or (t.coverage>r.coverage if field=='coverage' else t.baseline_lost<r.baseline_lost)) for t in g.itertuples())]
  points=sorted(set((getattr(r,field),r.C) for r in front));ax.plot([x for x,y in points],[y for x,y in points],'--',c='#718088',lw=1,zorder=0)
 axes[0].set_xlabel('Discovered assays');axes[1].set_xlabel('Lost baseline-discovered assays')
 for ax in axes:ax.set_ylabel('Recovered actives');ax.set_ylim(0,113);ax.grid(alpha=.16)
 axes[0].set_xlim(0,29);axes[1].set_xlim(-.6,20)
 handles,labels=axes[0].get_legend_handles_labels();fig.legend(handles,labels,loc='lower center',bbox_to_anchor=(.5,-.46),ncol=2,frameon=False,fontsize=11);fig.tight_layout();export(fig,'new_activity_pareto')
 # Editable, task-general method diagram.
 fig,ax=plt.subplots(figsize=(11.2,4.1));ax.set_xlim(0,11.2);ax.set_ylim(0,4.1);ax.axis('off')
 boxes=[(.1,2.2,2.55,1.55,'Fixed input','Pool scores\nBaseline queues U\nCheck budget K'),(3.0,2.2,3.9,1.55,'Discovery pilot','Follow each baseline prefix\nStop that pool at its first hit\nor at its quota'),(7.3,2.2,3.8,1.55,'Global completion','Spend K - |M| checks on\nhighest unused fixed scores\nReturn the union S')]
 for x,y,w,h,title,text in boxes:
  ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle='round,pad=.03',facecolor='#f0f5f6',edgecolor='#51777f',lw=1.2));ax.text(x+.12,y+h-.25,title,fontsize=14.5,weight='bold',va='top');ax.text(x+.12,y+h-.7,text,fontsize=13,va='top',linespacing=1.3)
 for x1,x2 in [(2.67,2.98),(6.94,7.28)]:ax.add_patch(FancyArrowPatch((x1,2.95),(x2,2.95),arrowstyle='-|>',mutation_scale=15,color='#51777f'))
 ax.text(4.95,1.8,'Only returned selected labels control stopping',ha='center',fontsize=13,color='#37535b')
 ax.add_patch(FancyBboxPatch((.13,.18),10.94,1.08,boxstyle='round,pad=.03',facecolor='#e8f2ee',edgecolor='#177c80',lw=1.2))
 ax.text(.32,.98,'Finite-outcome certificate',fontsize=14,weight='bold',va='top',color='#176168')
 ax.text(.32,.58,'Every baseline-discovered pool remains discovered at the same terminal check budget.',fontsize=13,va='center')
 ax.text(.32,.28,'Recovered count and protection cost are distinct quantities.',fontsize=13,color='#43535b',va='center')
 export(fig,'allocation_method')
 labels=pd.read_csv(H/'data/new_test_query_labels.csv')
 rep=dict(new_queries=len(labels),new_actives=int(labels.y.sum()),new_positive_assays=int(labels.groupby('assay').y.sum().gt(0).sum()),
    new_primary={a:{k:int(qtest.loc[a,k]) for k in ['C','coverage','baseline_lost','K','pilot_calls']} for a in ORDER},
    development_primary={a:{k:int(qdev.loc[a,k]) for k in ['C','coverage','baseline_lost','K']} for a in ORDER},
    new_policy_values=len(new),saved_policy_values=len(saved),all_new_recycling_certificates=int(new.algorithm.eq('recycling').sum()),
    new_seed_C_at_primary={a:{str(k):int(v) for k,v in values.items() if pd.notna(v)} for a,values in new[new.method.eq('Morgan2048_RF')&new.B.eq(4)].groupby(['seed','algorithm']).C.sum().unstack().to_dict().items()})
 sensitivity=[]
 t=new[new.B.eq(4)&new.algorithm.isin(['uniform','recycling','global'])].groupby(['method','seed','algorithm'])[['C','coverage','baseline_lost']].sum()
 for method,seed in sorted(set((a,b) for a,b,c in t.index)):
  name={'Morgan2048_RF':'Morgan--RF','Morgan2048_CatBoost':'Morgan--CatBoost','active_neighbour':'Active neighbour'}[method]
  values=[name,seed]
  for a in ['uniform','recycling','global']:
   v=t.loc[(method,seed,a)];values.append(f'{int(v.C)}/{int(v.coverage)}/{int(v.baseline_lost)}')
  sensitivity.append(values)
 make_table(H/'tables/new_sensitivity.tex','Prespecified new-test scorer and seed sensitivity at 112 checks.','tab:new-sensitivity',['Scorer','Seed','Uniform','Recycling','Global'],sensitivity,
  r'Entries are $C/\mathrm{Cov}/L_U$. Repeated seeds share one set of campaigns. The active-neighbour scorer is deterministic, so its seed rows are identical by design. No alternative was selected as a replacement primary predictor after query outcomes.')
 make_table(H/'tables/new_sensitivity_zh.tex','112次检查下预定的新测试评分器及种子敏感性。','tab:new-sensitivity',['评分器','种子','统一','回收','全局'],sensitivity,
  '数值为回收/覆盖/基线发现损失。种子共用相同活动；活性邻居是确定性评分，其种子行按设计相同。不按查询终点重新选择主要评分器。')
 budgetrows=[]
 for B in [1,2,4,8,16,32]:
  values=[B]
  for a in ['uniform','recycling','global']:
   v=test[test.B.eq(B)&test.algorithm.eq(a)].iloc[0];values.append(f'{int(v.C)}/{int(v.coverage)}/{int(v.baseline_lost)}')
  budgetrows.append(values)
 make_table(H/'tables/new_budgets.tex','Complete prespecified budget range for the new-test primary scorer.','tab:new-budgets',['Quota','Uniform','Recycling','Global'],budgetrows,
  r'Entries are $C/\mathrm{Cov}/L_U$. The primary quota is four; all other quotas are sensitivity analyses. At quota 32 recycling retains all 28 baseline discoveries while recovering 22 fewer actives than uniform.')
 make_table(H/'tables/new_budgets_zh.tex','新测试主评分器的完整预定预算范围。','tab:new-budgets',['配额','统一','回收','全局'],budgetrows,
  '数值为回收/覆盖/基线发现损失。主要配额为四，其余为敏感性分析。配额32时回收法保留全部28个基线发现，但比统一少回收22个活性。')
 (H/'results/manuscript_numbers.json').write_text(json.dumps(rep,indent=2,allow_nan=False)+'\n');print('TABLES_AND_FIGURES_COMPLETE',len(new),len(saved),flush=True)
if __name__=='__main__':main()
