"""Reconstruct labels by canonical graph; replay frozen assigned and full policies."""
from pathlib import Path
import argparse,hashlib,json,sys,time
import numpy as np,pandas as pd
from rdkit import Chem,RDLogger
sys.path.insert(0,str(Path(__file__).resolve().parent.parent/'51_certificate_shield_20261028'))
from shield import simulate
from randomization import analyze
H=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def main():
    parser=argparse.ArgumentParser();parser.add_argument('--archive',type=Path,required=True);parser.add_argument('--refit',action='store_true');a=parser.parse_args();start=time.perf_counter();RDLogger.DisableLog('rdApp.*')
    p=json.loads((H/'protocol_lock.json').read_text());assert sha(a.archive)==p['raw_sha256']
    for name,value in p['source_sha256'].items():assert sha(H/name)==value
    for name,value in p['frozen_policy_sha256'].items():assert sha(H.parents[1]/name)==value
    assert sha(H/'data/random_assignment.csv')==p['random_assignment_sha256']
    for f in ['protocol_lock','partition_freeze','prediction_freeze','evaluation_opened']:
        pass
    locks=[json.loads((H/(f+'.json')).read_text())['timestamp'] for f in ['protocol_lock','partition_freeze','prediction_freeze','evaluation_opened']];assert locks==sorted(locks)
    raw=pd.read_csv(a.archive);raw['key']=None;graphs={};first={}
    for idx,sm in raw.smiles.items():
        mol=Chem.MolFromSmiles(sm)
        if mol is None:continue
        Chem.RemoveStereochemistry(mol);g=Chem.MolToSmiles(mol,canonical=True,isomericSmiles=False);k=hashlib.sha256(g.encode()).hexdigest()
        if k not in first:first[k]=idx;graphs[k]=g
    # Independent key-based lookup, instead of evaluation's source-row lookup.
    by_key=raw.loc[list(first.values())].copy();by_key.index=list(first.keys())
    path=H/'data/row_map.csv';partition=pd.read_csv(path if path.exists() else H/'data/partition.csv')
    def labels(d):return np.array([int(by_key.loc[k,a]) for k,a in zip(d.key,d.assay)],int)
    scores=pd.read_csv(H/'data/scores_before_labels.csv');assert sha(H/'data/scores_before_labels.csv')==json.loads((H/'prediction_freeze.json').read_text())['scores_sha256'];scores['y']=labels(scores)
    local_labels=H/'data/query_labels.csv'
    if local_labels.exists():
        z=pd.read_csv(local_labels).set_index(['assay','key']);assert np.array_equal(scores.y,z.loc[list(zip(scores.assay,scores.key)),'y'].to_numpy())
    assert not set(partition[partition.role.eq('support')].key)&set(scores.key)
    assert scores.groupby(['provider','key']).unit.nunique().max()==1
    arows=pd.read_csv(H/'data/random_assignment.csv');expected=pd.read_csv(H/'results/assigned_primary.csv');observed=[]
    for r in expected.itertuples():
        g=scores[scores.unit.eq(r.unit)].sort_values(['assay','key']);res,_,_=simulate(g.score,g.assay,g.key,g.y,32,r.policy,11)
        for k in ['K','C','coverage','baseline_coverage','baseline_lost']:assert res[k]==getattr(r,k)
        observed.append(dict(trial=r.trial,unit=r.unit,outcome=res[r.metric]))
    primary,_=analyze(arows,pd.DataFrame(observed),p['providers']);assert primary==json.loads((H/'results/primary_randomization.json').read_text())
    expected=pd.read_csv(H/'results/policy_results.csv');n=0;setchecks=0
    for (scope,unit,B),rows in expected.groupby(['scope','unit','B'],sort=True):
        g=scores[scores.unit.eq(unit) if scope=='library' else scores.provider.eq(unit)].sort_values(['assay','key']);sets={}
        for row in rows.itertuples():
            res,ix,_=simulate(g.score,g.assay,g.key,g.y,int(B),row.algorithm,11)
            for k in ['K','C','coverage','baseline_coverage','baseline_lost']:assert res[k]==getattr(row,k),(unit,B,row.algorithm,k)
            if row.algorithm in ['recycling','shield_global','shield_latent_greedy']:assert res['baseline_lost']==0
            sets[row.algorithm]=set(ix);n+=1
        assert sets['recycling']==sets['shield_global'];setchecks+=1
    errors=[]
    if a.refit:
        from rdkit.Chem import rdFingerprintGenerator
        from sklearn.ensemble import RandomForestClassifier
        gen=rdFingerprintGenerator.GetMorganGenerator(radius=2,fpSize=2048);fps={k:np.asarray(gen.GetFingerprint(Chem.MolFromSmiles(graphs[k])),np.uint8) for k in partition.key.unique()}
        for assay,g in partition.groupby('assay',sort=True):
            s=g[g.role.eq('support')].sort_values('key');q=g[g.role.eq('query')].sort_values('key');y=labels(s)
            if len(set(y))<2:v=np.full(len(q),(y.sum()+1)/(len(y)+2))
            else:
                model=RandomForestClassifier(n_estimators=256,min_samples_leaf=2,max_features='sqrt',class_weight=None,random_state=11,n_jobs=4);model.fit(np.stack([fps[k] for k in s.key]),y);v=model.predict_proba(np.stack([fps[k] for k in q.key]))[:,1]
            z=scores[scores.assay.eq(assay)].set_index('key');err=float(np.max(np.abs(v-z.loc[q.key,'score'].to_numpy())));assert err<1e-12;errors.append(err)
        print('REFIT',len(errors),max(errors),flush=True)
    guards=H/'checks/scientific_guards_before.json'
    if guards.exists():
        for x in json.loads(guards.read_text()):assert sha(H.parents[1]/x['path'])==x['sha256']
    result=dict(status='PASS',policy_values_replayed=n,assigned_policy_values_replayed=len(observed),static_set_checks=setchecks,query_labels_checked_by_canonical_key=len(scores),support_labels_reconstructed=len(partition[partition.role.eq('support')]),models_refitted=len(errors),maximum_probability_error=max(errors,default=None),locks_in_temporal_order=True,seconds=time.perf_counter()-start)
    (H/'checks').mkdir(exist_ok=True);(H/'checks/public_replay.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
if __name__=='__main__':main()
