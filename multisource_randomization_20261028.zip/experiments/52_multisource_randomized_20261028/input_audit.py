"""External-source input availability only; never cast or summarize activity signs."""
from pathlib import Path
import csv,gzip,hashlib,json,datetime
import numpy as np,pandas as pd
from rdkit import Chem,RDLogger
H=Path(__file__).resolve().parent
PROVIDERS={'ACEA':'ACEA Biosciences','APR':'Apredica','ATG':'Attagene','BSK':'BioSeek','CEETOX':'CeeTox','CLD':'CellzDirect','NVS':'NovaScreen','OT':'Odyssey Thera','Tanguay':'Oregon State University Tanguay laboratory'}
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def digest(s):return hashlib.sha256(s.encode()).hexdigest()
def main():
    RDLogger.DisableLog('rdApp.*');rows=[];seen=set();invalid=[];availability={}
    with gzip.open(H/'raw/toxcast_data.csv.gz','rt') as f:
        reader=csv.DictReader(f);columns=reader.fieldnames;assays=[a for a in columns if a.split('_')[0] in PROVIDERS]
        for n,row in enumerate(reader,1):
            mol=Chem.MolFromSmiles(row['smiles'])
            if mol is None:invalid.append(n);continue
            Chem.RemoveStereochemistry(mol);smiles=Chem.MolToSmiles(mol,canonical=True,isomericSmiles=False);key=digest(smiles)
            if key in seen:continue
            seen.add(key);support=int(digest('role|'+key),16)%5==0;block=int(digest('TOXCAST|block|'+key),16)%8
            rows.append(dict(source_row=n,key=key,smiles=smiles,role='support' if support else 'query',block=block))
            availability[n]=[a for a in assays if row[a].strip()!='']
    d=pd.DataFrame(rows);d.to_csv(H/'data/input_graphs.csv',index=False)
    stats=[]
    for assay in assays:
        v=d[d.source_row.isin([n for n,cols in availability.items() if assay in cols])]
        counts={L:[int((v.role.eq('query')&(v.block%L).eq(i)).sum()) for i in range(L)] for L in [2,4,8]}
        stats.append(dict(assay=assay,provider=assay.split('_')[0],support=int(v.role.eq('support').sum()),query_blocks=counts,eligible={L:min(counts[L])>=32 and int(v.role.eq('support').sum())>=32 for L in [2,4,8]}))
    (H/'sources/input_availability.json').write_text(json.dumps(stats,indent=2)+'\n')
    (H/'data/input_availability_map.json').write_text(json.dumps(availability,separators=(',',':')))
    out=dict(timestamp=datetime.datetime.now().astimezone().isoformat(),raw_sha256=sha(H/'raw/toxcast_data.csv.gz'),source_columns=columns,input_graphs_sha256=sha(H/'data/input_graphs.csv'),
        availability_sha256=sha(H/'sources/input_availability.json'),source_rows=n,valid_unique_graphs=len(d),invalid_rows=invalid,activity_signs_inspected=False,
        providers={p:dict(name=PROVIDERS[p],assays=sum(x['provider']==p for x in stats),eligible_assays={L:sum(x['provider']==p and x['eligible'][L] for x in stats) for L in [2,4,8]}) for p in PROVIDERS})
    (H/'input_audit.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items() if k!='source_columns'},indent=2))
if __name__=='__main__':main()
