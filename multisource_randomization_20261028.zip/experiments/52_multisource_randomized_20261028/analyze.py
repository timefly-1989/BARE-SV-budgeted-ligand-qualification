"""Post-evaluation descriptive summaries; no changes to locked analyses."""
from pathlib import Path
import json
import pandas as pd,numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
H=Path(__file__).resolve().parent
P=json.loads((H/'protocol_lock.json').read_text());d=pd.read_csv(H/'results/policy_results.csv');q=pd.read_csv(H/'data/query_labels.csv');sc=pd.read_csv(H/'data/scores_before_labels.csv').merge(q,on=['assay','key']);primary=json.loads((H/'results/primary_randomization.json').read_text())
z=d[(d.scope=='library')&(d.B==32)];source=[]
for s,g in z.groupby('provider',sort=True):
 a=g.groupby('algorithm')[['C','coverage','baseline_lost','K']].sum();m=len(P['providers'][s]['assays']);L=P['providers'][s]['library_blocks'];v=sc[sc.provider.eq(s)]
 source.append(dict(provider=s,name=P['providers'][s]['name'],endpoints=m,libraries=L,query_records=len(v),positives=int(v.y.sum()),uniform=int(a.loc['uniform','C']),DPQR=int(a.loc['recycling','C']),global_C=int(a.loc['global','C']),baseline_discoveries=int(a.loc['uniform','coverage']),DPQR_coverage=int(a.loc['recycling','coverage']),global_loss=int(a.loc['global','baseline_lost']),effect_per_endpoint=float((a.loc['recycling','C']-a.loc['uniform','C'])/(m*L)),global_loss_per_endpoint=float(a.loc['global','baseline_lost']/(m*L))))
s=pd.DataFrame(source);s.to_csv(H/'results/provider_summary.csv',index=False)
aggregate=d.groupby(['scope','B','algorithm'])[['K','C','coverage','baseline_lost']].sum().reset_index();aggregate.to_csv(H/'results/full_panel_summary.csv',index=False)
rows=[]
for prov in s.provider:rows.append(dict(omitted_provider=prov,finite_panel_effect=float(s[s.provider!=prov].effect_per_endpoint.mean())))
pd.DataFrame(rows).to_csv(H/'results/leave_one_provider_out.csv',index=False)
full=z.groupby('algorithm')[['K','C','coverage','baseline_lost']].sum().astype(int).to_dict('index');whole=aggregate[(aggregate.scope=='whole_provider')&(aggregate.B==32)].set_index('algorithm')[['K','C','coverage','baseline_lost']].astype(int).to_dict('index')
summary=dict(full_panel_effect_per_endpoint=float(s.effect_per_endpoint.mean()),full_panel_loss_contrast=float(s.global_loss_per_endpoint.mean()),all_provider_effects_positive=bool((s.effect_per_endpoint>0).all()),leave_one_provider_out_range=[min(x['finite_panel_effect'] for x in rows),max(x['finite_panel_effect'] for x in rows)],full_panel=full,whole_provider=whole,primary=primary,full_recovery_percent=100*(full['recycling']['C']/full['uniform']['C']-1))
(H/'results/manuscript_numbers.json').write_text(json.dumps(summary,indent=2)+'\n')
for zh in [False,True]:
 cap=('各提供方的固定面板结果。统一配额与DPQR使用相同得分及候选预算；覆盖以“端点—库”为单位，不是独立实验室重复。最后列为全局合并丢失的基线发现。' if zh else 'Fixed-panel results by documented assay provider. Uniform and DPQR use the same scores and candidate budget. Discoveries count endpoint--library pairs, not independent laboratory replicates. The last column is baseline discoveries lost by global pooling.')
 head=('提供方 & 端点/库 & 查询/阳性 & 统一 & DPQR & 基线发现 & 全局丢失' if zh else 'Provider & Endpoints/libraries & Queries/positives & Uniform & DPQR & Baseline & Global loss')
 lines=[r'\begin{table}[!htbp]\centering\small',r'\caption{'+cap+r'}\label{tab:multisource}',r'\resizebox{\linewidth}{!}{\begin{tabular}{lrrrrrr}\toprule',head+r'\\\midrule']
 for x in source:lines.append(f"{x['provider']} & {x['endpoints']}/{x['libraries']} & {x['query_records']:,}/{x['positives']:,} & {x['uniform']} & {x['DPQR']} & {x['baseline_discoveries']} & {x['global_loss']}"+r'\\')
 lines += [r'\midrule',('合计' if zh else 'Total')+r' & 66/64 & 64,639/7,072 & 3,265 & 3,876 & 416 & 67\\',r'\bottomrule\end{tabular}}\end{table}']
 (H/'tables'/('multisource_zh.tex' if zh else 'multisource.tex')).write_text('\n'.join(lines)+'\n')
 lines=[r'\begin{table}[!htbp]\centering\small',r'\caption{'+('新外部固定面板的全部预定策略，14,848次检查。全反事实回放属于描述性分析；主检验仅使用随机分配的策略结果。' if zh else 'All prespecified policies on the external fixed panel at 14,848 checks. Complete counterfactual replay is descriptive; primary tests use assigned-policy outcomes only.')+r'}\label{tab:external-controls}',r'\begin{tabular}{lrrr}\toprule',('策略 & 回收 & 发现 & 基线丢失' if zh else 'Policy & Recovery & Discoveries & Baseline losses')+r'\\\midrule']
 for alg,label in [('uniform','Uniform'),('recycling','DPQR'),('shield_global','Static shield'),('shield_latent_greedy','Posterior shield'),('global','Global pooling'),('observed_4','Observed coverage (4)'),('latent_greedy','Posterior greedy'),('latent_UCB','Posterior UCB')]:
  v=full[alg];lines.append(f"{label} & {v['C']:,} & {v['coverage']} & {v['baseline_lost']}"+r'\\')
 lines += [r'\bottomrule\end{tabular}\end{table}'];(H/'tables'/('controls_zh.tex' if zh else 'controls.tex')).write_text('\n'.join(lines)+'\n')
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9,'axes.spines.top':False,'axes.spines.right':False,'svg.fonttype':'none','pdf.fonttype':42})
fig,ax=plt.subplots(1,3,figsize=(12,3.65),layout='constrained');colors={'uniform':'#777777','recycling':'#007d82','global':'#c66b2b','observed_4':'#694e9f'}
for alg,label in [('uniform','Uniform'),('recycling','DPQR'),('global','Global pooling'),('observed_4','Observed coverage')]:
 g=aggregate[(aggregate.scope=='library')&(aggregate.algorithm==alg)];ax[0].plot(g.B,g.C,'o-',label=label,color=colors[alg],ms=3);ax[2].plot(g.B,g.baseline_lost,'o-',label=label,color=colors[alg],ms=3)
ax[0].set(xlabel='Uniform reference quota per endpoint',ylabel='Recovered response-positive records',title='A  Fixed-panel recovery');ax[0].legend(frameon=False,fontsize=8)
ax[1].barh(s.provider,s.effect_per_endpoint,color='#007d82');ax[1].set(xlabel='DPQR − uniform, per endpoint/library',title='B  All nine providers retained');ax[1].invert_yaxis()
ax[2].set(xlabel='Uniform reference quota per endpoint',ylabel='Baseline discoveries lost',title='C  Particular discoveries retained')
for a in [ax[0],ax[2]]:a.set_xticks([4,8,16,32,64]);a.grid(alpha=.18)
for ext in ['pdf','svg','png']:fig.savefig(H/'figures'/('external_providers.'+ext),dpi=180)
plt.close(fig)
# The exact primary null reference distribution, not a biological-sampling CI.
from collections import Counter
fig,ax=plt.subplots(1,2,figsize=(9,3.25),layout='constrained')
for a,t in zip(ax,sorted(primary['tests'],key=lambda v:v['trial'],reverse=True)):
 dist=Counter({0:1})
 for v in t['integer_differences']:
  nxt=Counter()
  for k,n in dist.items():nxt[k+v]+=n;nxt[k-v]+=n
  dist=nxt
 x=np.array(sorted(dist));y=np.array([dist[k]/2**32 for k in x]);a.plot(x,y,color='#777777',lw=1);obs=abs(t['observed_sum']);a.fill_between(x,0,y,where=abs(x)>=obs,color='#c66b2b',alpha=.6);a.axvline(t['observed_sum'],color='#007d82',ls='--');a.set(title=t['trial'].replace('_',' ').capitalize(),xlabel='Integer-scaled assigned contrast',ylabel='Sharp-null assignment mass');a.text(.02,.96,f"Holm p = {t['Holm_p']:.6g}",transform=a.transAxes,va='top')
for ext in ['pdf','svg','png']:fig.savefig(H/'figures'/('randomization_reference.'+ext),dpi=180)
print(json.dumps(summary,indent=2))
