"""Exact assigned-policy Fisher tests; no outcome independence assumption."""
from collections import Counter
from math import lcm
import numpy as np
def exact_sign_randomization(values):
    values=[int(v) for v in values];counts=Counter({0:1})
    for v in values:
        nxt=Counter()
        for total,n in counts.items():nxt[total+v]+=n;nxt[total-v]+=n
        counts=nxt
    obs=abs(sum(values));numerator=sum(n for value,n in counts.items() if abs(value)>=obs);denominator=2**len(values)
    return dict(p=numerator/denominator,numerator=numerator,denominator=denominator,observed_sum=sum(values),reference_states=len(counts))
def analyze(assignment,observed,providers):
    scale=lcm(*(len(m['assays'])*m['library_blocks'] for m in providers.values()));tests=[];pair_rows=[]
    for trial,a in assignment.groupby('trial',sort=True):
        values=[];metrics=[]
        for r in a.itertuples():
            z=observed[observed.trial.eq(trial)].set_index('unit');ya=int(z.loc[r.unit_a,'outcome']);yb=int(z.loc[r.unit_b,'outcome']);raw=(2*int(r.recycling_in_a)-1)*(ya-yb)
            if trial=='discovery_loss':raw=-raw
            meta=providers[r.provider];weight=scale//(len(meta['assays'])*meta['library_blocks']);values.append(raw*weight)
            pair_rows.append(dict(trial=trial,provider=r.provider,pair=r.pair,raw_difference=raw,integer_weight=weight,weighted_difference=raw*weight))
        exact=exact_sign_randomization(values);tests.append(dict(trial=trial,pairs=len(values),**exact,integer_differences=values,source_balanced_effect_estimate=2*sum(values)/(len(providers)*scale)))
    order=np.argsort([t['p'] for t in tests]);previous=0.
    for rank,j in enumerate(order):previous=max(previous,min(1.,(len(tests)-rank)*tests[j]['p']));tests[j]['Holm_p']=previous
    return dict(tests=tests,integer_scale=scale,null='Sharp no-policy-effect null for each fixed library; assignment-based, not a sign-symmetric sampling model',estimand='Source-balanced fixed-panel average contrast per assay at32 checks; no source-population inference'),pair_rows
