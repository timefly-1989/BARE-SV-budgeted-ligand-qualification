"""Lock external-provider panels and genuine randomized policy assignment."""
from pathlib import Path
import datetime,hashlib,json,math,secrets
import pandas as pd
H=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def rank(s):return hashlib.sha256(('MULTISOURCE|20261028|'+s).encode()).hexdigest()
def main():
    assert not (H/'protocol_lock.json').exists(),'Never redraw assignments or overwrite a lock'
    audit=json.loads((H/'input_audit.json').read_text());available=json.loads((H/'sources/input_availability.json').read_text());providers={};selected=[];assignment=[]
    for source,meta in audit['providers'].items():
        target=min(8,meta['assays']);L=next((b for b in [8,4,2] if meta['eligible_assays'][str(b)]>=target),None)
        if L is None:continue
        assays=sorted([a['assay'] for a in available if a['provider']==source and a['eligible'][str(L)]],key=rank)[:target]
        assert len(assays)>=2
        providers[source]=dict(name=meta['name'],library_blocks=L,assays=assays);selected.extend(assays)
        for pair in range(L//2):
            for trial,control,metric in [('recovery','uniform','C'),('discovery_loss','global','baseline_lost')]:
                coin=secrets.randbits(1)
                assignment.append(dict(trial=trial,provider=source,pair=f'{source}-P{pair+1:02}',unit_a=f'{source}-L{pair*2+1:02}',unit_b=f'{source}-L{pair*2+2:02}',recycling_in_a=coin,control=control,metric=metric))
    pd.DataFrame(assignment).to_csv(H/'data/random_assignment.csv',index=False)
    obj=dict(timestamp=datetime.datetime.now().astimezone().isoformat(),dataset='DeepChem MoleculeNet ToxCast',source_url='https://deepchemdata.s3-us-west-1.amazonaws.com/datasets/toxcast_data.csv.gz',raw_sha256=audit['raw_sha256'],
        provenance_url='https://www.epa.gov/system/files/documents/2022-12/ToxCast%20Assay%20Platform%20Descriptions%2008112017.pdf',provenance_sha256=sha(H/'sources/epa_platform_descriptions.pdf'),
        input_audit_sha256=sha(H/'input_audit.json'),input_graphs_sha256=audit['input_graphs_sha256'],activity_signs_inspected=False,
        provider_rule='All9 named nonfederal/academic assay-provider prefixes in the archived file (ACEA,APR,ATG,BSK,CEETOX,CLD,NVS,OT,Tanguay); no TOX21/NCCT/NHEERL',
        panel_rule='Largest L in8,4,2 with min(8,number_of_source_endpoints) assays having32 support records and32 queries in every input-only hash block; SHA256 first eligible endpoints; all sources retained without activity-based exclusion',
        providers=providers,selected_assays=selected,units=sum(p['library_blocks'] for p in providers.values()),pairs=sum(p['library_blocks']//2 for p in providers.values()),
        support='Same canonical-graph role hash as experiment51: SHA256(role|key)mod5==0; label-blind cap2048 per endpoint',
        query='Other canonical graphs; SHA256(TOXCAST|block|key)mod8 then modulo source L; cap4096 per endpoint/library without class stratification; no duplicate graph across libraries within a provider',
        missing='Use published 0/1 activity; unavailable remains missing; first source row per nonstereochemical graph; invalid structures removed before activity inspection',
        randomization='Independent secrets.randbits(1) for each matched pair and each of2 virtual trials; assignment generated once before support-label fitting/query evaluation; vector saved, never redrawn',
        random_assignment_sha256=sha(H/'data/random_assignment.csv'),primary_quota=32,secondary_quotas=[4,8,16,64],
        scorer=dict(method='Morgan2048_RF',radius=2,n_estimators=256,min_samples_leaf=2,max_features='sqrt',class_weight=None,random_state=11,n_jobs=4),single_class='Laplace constant; no outcome-based removal',
        algorithms=['uniform','global','recycling','shield_global','shield_latent_greedy','latent_greedy','latent_UCB','observed_4'],
        primary_tests=['Assigned DPQR-minus-uniform recovery','Assigned global-minus-DPQR baseline-discovery loss'],
        primary_statistic='Source-balanced within-pair contrast: 2/S sum_pairs[(metric_treatment-metric_control)/(m_source L_source)], with sign reversed for loss; exact integer scaling and convolution over actual randomized assignments; two-sided sharp-null p, Holm across2',
        primary_null='Fisher sharp null: each fixed library has identical metric under the two assigned policies; not the weak zero-average-effect null and not source-superpopulation inference',
        primary_estimand='Finite-panel source-balanced average effect per endpoint at quota32; libraries are randomization units, not independent biological or laboratory replicates',
        no_interference='Frozen fits; each library/trial has separate policy state; no query feedback, model update or budget shared between libraries or trials. Shared compounds/targets may correlate potential outcomes and do not invalidate assignment-based sharp-null inference',
        secondary='Full-table paired differences and whole-provider campaigns, all8 policies; no significance claims obtained by splitting providers or relocking older outcomes',
        source_sampling='Nine assay providers, not a random sample of laboratories; no independent-source or 80% power guarantee',
        source_sha256={n:sha(H/n) for n in ['input_audit.py','protocol.py','prepare.py','fit.py','evaluate.py','randomization.py']},
        frozen_policy_sha256={str(p.relative_to(H.parent.parent)):sha(p) for p in [H.parent/'50_discovery_allocation_20261028/policies.py',H.parent/'51_certificate_shield_20261028/shield.py']})
    (H/'protocol_lock.json').write_text(json.dumps(obj,indent=2)+'\n');print('LOCKED',sha(H/'protocol_lock.json'),'providers',len(providers),'assays',len(selected),'units',obj['units'],'pairs',obj['pairs'],flush=True)
if __name__=='__main__':main()
