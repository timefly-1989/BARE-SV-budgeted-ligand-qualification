"""Verify exact convolution against enumeration and sharp-null type-I control."""
from pathlib import Path
import itertools,json
import numpy as np
from randomization import exact_sign_randomization
H=Path(__file__).resolve().parent
def main():
    rng=np.random.default_rng(521028);cases=0;validity=[]
    for n in range(1,11):
        for _ in range(5):
            v=rng.integers(-8,9,n).tolist();observed=abs(sum(v));ref=[abs(sum(a*b for a,b in zip(sign,v))) for sign in itertools.product([-1,1],repeat=n)]
            assert abs(exact_sign_randomization(v)['p']-float(np.mean(np.array(ref)>=observed)))<1e-15;cases+=1
    # Arbitrary fixed (perfectly related) pair outcomes; only assignments random.
    fixed=[1,1,2,2,4,4,8,8];pvals=[]
    for sign in itertools.product([-1,1],repeat=len(fixed)):
        pvals.append(exact_sign_randomization([a*b for a,b in zip(sign,fixed)])['p'])
    for alpha in [.01,.025,.05,.1]:
        rate=float(np.mean(np.array(pvals)<=alpha));assert rate<=alpha+1e-15;validity.append(dict(alpha=alpha,rejection_probability=rate))
    out=dict(status='PASS',convolution_enumeration_cases=cases,sharp_null_assignments=256,sharp_null_validity=validity,not_a_new_randomization_theorem=True)
    (H/'checks/randomization_tests.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
if __name__=='__main__':main()
