"""Open queries after prediction/assignment freeze; primary assigned outcomes first."""
from pathlib import Path
import sys,csv,gzip,datetime,hashlib,json,time
import numpy as np,pandas as pd
sys.path.insert(0,str(Path(__file__).resolve().parent.parent/'51_certificate_shield_20261028'))
from shield import simulate
from randomization import analyze
H=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def main():
    p=json.loads((H/'protocol_lock.json').read_text());assert sha(__file__)==p['source_sha256']['evaluate.py'];assert not (H/'evaluation_opened.json').exists()
    f=json.loads((H/'prediction_freeze.json').read_text());assert sha(H/'data/scores_before_labels.csv')==f['scores_sha256'];assert sha(H/'data/random_assignment.csv')==p['random_assignment_sha256']
    d=pd.read_csv(H/'data/scores_before_labels.csv');permitted={(int(r.source_row),r.assay):r.key for r in d.itertuples()};labels=[]
    with gzip.open(H/'raw/toxcast_data.csv.gz','rt') as stream:
        for n,row in enumerate(csv.DictReader(stream),1):
            for assay in p['selected_assays']:
                if (n,assay) in permitted:labels.append(dict(assay=assay,key=permitted[(n,assay)],y=int(float(row[assay]))))
    y=pd.DataFrame(labels);assert set(y.y)<=set([0,1]);y.to_csv(H/'data/query_labels.csv',index=False)
    (H/'evaluation_opened.json').write_text(json.dumps(dict(timestamp=datetime.datetime.now().astimezone().isoformat(),prediction_freeze_sha256=sha(H/'prediction_freeze.json'),labels_sha256=sha(H/'data/query_labels.csv'),assignment_sha256=sha(H/'data/random_assignment.csv')),indent=2)+'\n')
    d=d.merge(y,on=['assay','key'],validate='one_to_one');a=pd.read_csv(H/'data/random_assignment.csv');assigned=[]
    # Only the assigned policy metric enters each primary test.
    for row in a.itertuples():
        for unit,arm in [(row.unit_a,'recycling' if row.recycling_in_a else row.control),(row.unit_b,row.control if row.recycling_in_a else 'recycling')]:
            g=d[d.unit.eq(unit)].sort_values(['assay','key']).reset_index(drop=True);res,_,_=simulate(g.score,g.assay,g.key,g.y,32,arm,11)
            assigned.append(dict(trial=row.trial,provider=row.provider,pair=row.pair,unit=unit,policy=arm,outcome=res[row.metric],metric=row.metric,**res))
    observed=pd.DataFrame(assigned);observed.to_csv(H/'results/assigned_primary.csv',index=False);tests,pairs=analyze(a,observed,p['providers']);pd.DataFrame(pairs).to_csv(H/'results/assigned_pair_differences.csv',index=False)
    (H/'results/primary_randomization.json').write_text(json.dumps(tests,indent=2)+'\n');print('PRIMARY_RANDOMIZATION',json.dumps(tests),flush=True)
    results=[]
    for unit,g in d.groupby('unit',sort=True):
        g=g.sort_values(['assay','key']).reset_index(drop=True)
        for B in [4,8,16,32,64]:
            for algorithm in p['algorithms']:
                t=time.perf_counter();res,_,_=simulate(g.score,g.assay,g.key,g.y,B,algorithm,11);results.append(dict(scope='library',provider=g.provider.iloc[0],unit=unit,B=B,algorithm=algorithm,**res,seconds=time.perf_counter()-t))
        print('LIBRARY',unit,flush=True)
        pd.DataFrame(results).to_csv(H/'results/policy_results.csv',index=False)
    for source,g in d.groupby('provider',sort=True):
        g=g.sort_values(['assay','key']).reset_index(drop=True)
        for algorithm in p['algorithms']:
            t=time.perf_counter();res,_,_=simulate(g.score,g.assay,g.key,g.y,32,algorithm,11);results.append(dict(scope='whole_provider',provider=source,unit=source,B=32,algorithm=algorithm,**res,seconds=time.perf_counter()-t))
        print('WHOLE_PROVIDER',source,flush=True)
        pd.DataFrame(results).to_csv(H/'results/policy_results.csv',index=False)
    summary=dict(query_records=len(d),query_positives=int(d.y.sum()),prevalence=float(d.y.mean()),assays=d.assay.nunique(),providers=d.provider.nunique(),libraries=d.unit.nunique(),pairs=p['pairs'],primary_randomization=tests,
        no_new_wetlab=True,no_independent_source_sampling_claim=True,NCGC_primary_records_unchanged=True)
    (H/'results/summary.json').write_text(json.dumps(summary,indent=2)+'\n');print('SUMMARY',json.dumps(summary),flush=True)
if __name__=='__main__':main()
