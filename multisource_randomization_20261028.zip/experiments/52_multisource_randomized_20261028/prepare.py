"""Build frozen source/library partitions from input-only data."""
from pathlib import Path
import datetime,hashlib,json
import pandas as pd
H=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def main():
    p=json.loads((H/'protocol_lock.json').read_text());assert sha(__file__)==p['source_sha256']['prepare.py'];assert not (H/'partition_freeze.json').exists()
    d=pd.read_csv(H/'data/input_graphs.csv');a={int(k):set(v) for k,v in json.loads((H/'data/input_availability_map.json').read_text()).items()};rows=[]
    for source,meta in p['providers'].items():
        for assay in meta['assays']:
            g=d[d.source_row.isin([n for n,available in a.items() if assay in available])].copy();g['provider']=source;g['assay']=assay;g['library']=g.block%meta['library_blocks']
            g['cap_hash']=g.key.map(lambda k:hashlib.sha256(('cap|'+k).encode()).hexdigest());g=g.sort_values(['cap_hash','source_row'])
            rows.append(g[g.role.eq('support')].head(2048))
            for b in range(meta['library_blocks']):rows.append(g[g.role.eq('query')&g.library.eq(b)].head(4096))
    out=pd.concat(rows,ignore_index=True).drop(columns=['cap_hash']);out['unit']=[f'{s}-L{1+int(b):02}' for s,b in zip(out.provider,out.library)];out.to_csv(H/'data/partition.csv',index=False)
    q=out[out.role.eq('query')];s=out[out.role.eq('support')];assert not set(q.key)&set(s.key);assert q.groupby(['provider','key']).unit.nunique().max()==1
    assert q.groupby(['assay','unit']).size().min()>=32
    f=dict(timestamp=datetime.datetime.now().astimezone().isoformat(),partition_sha256=sha(H/'data/partition.csv'),protocol_sha256=sha(H/'protocol_lock.json'),query_records=len(q),support_records=len(s),query_activity_signs_inspected=False)
    (H/'partition_freeze.json').write_text(json.dumps(f,indent=2)+'\n');print('PARTITION',f,flush=True)
if __name__=='__main__':main()
