"""Only support activities enter fits; freeze predictions before query export."""
import os
for k in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','VECLIB_MAXIMUM_THREADS']:os.environ[k]='1'
from pathlib import Path
import csv,gzip,datetime,hashlib,json,time
import numpy as np,pandas as pd
from rdkit import Chem,RDLogger
from rdkit.Chem import rdFingerprintGenerator
from sklearn.ensemble import RandomForestClassifier
H=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def main():
    p=json.loads((H/'protocol_lock.json').read_text());assert sha(__file__)==p['source_sha256']['fit.py'];assert not (H/'prediction_freeze.json').exists();RDLogger.DisableLog('rdApp.*');start=time.perf_counter()
    d=pd.read_csv(H/'data/partition.csv');s=d[d.role.eq('support')];q=d[d.role.eq('query')];permitted={(int(r.source_row),r.assay):r.key for r in s.itertuples()};labels={}
    with gzip.open(H/'raw/toxcast_data.csv.gz','rt') as stream:
        for n,row in enumerate(csv.DictReader(stream),1):
            for assay in p['selected_assays']:
                if (n,assay) in permitted:labels[(assay,permitted[(n,assay)])]=int(float(row[assay]))
    gen=rdFingerprintGenerator.GetMorganGenerator(radius=2,fpSize=2048);fps={k:np.asarray(gen.GetFingerprint(Chem.MolFromSmiles(sm)),np.uint8) for k,sm in d[['key','smiles']].drop_duplicates('key').itertuples(index=False,name=None)};rows=[];audits=[]
    for assay in sorted(p['selected_assays']):
        a=s[s.assay.eq(assay)].sort_values('key');v=q[q.assay.eq(assay)].sort_values('key');y=np.array([labels[(assay,k)] for k in a.key],int);assert set(y)<=set([0,1])
        if len(set(y))<2:prob=np.full(len(v),(y.sum()+1)/(len(y)+2))
        else:
            model=RandomForestClassifier(**{k:v for k,v in p['scorer'].items() if k not in ['method','radius']});model.fit(np.stack([fps[k] for k in a.key]),y);prob=model.predict_proba(np.stack([fps[k] for k in v.key]))[:,1]
        for r,score in zip(v.itertuples(),prob):rows.append(dict(provider=r.provider,assay=assay,unit=r.unit,key=r.key,source_row=r.source_row,score=float(score)))
        audits.append(dict(assay=assay,provider=a.provider.iloc[0],support=len(a),support_positives=int(y.sum()),queries=len(v),single_class=len(set(y))<2));print('SCORED',assay,len(v),flush=True)
    pd.DataFrame(rows).to_csv(H/'data/scores_before_labels.csv',index=False);pd.DataFrame(audits).to_csv(H/'results/support_audit.csv',index=False)
    pd.DataFrame([dict(assay=a,key=k,y=v) for (a,k),v in labels.items()]).to_csv(H/'data/support_labels.csv',index=False)
    f=dict(timestamp=datetime.datetime.now().astimezone().isoformat(),scores_sha256=sha(H/'data/scores_before_labels.csv'),partition_sha256=sha(H/'data/partition.csv'),protocol_sha256=sha(H/'protocol_lock.json'),assignment_sha256=sha(H/'data/random_assignment.csv'),query_labels_used=False,query_labels_exported=False,seconds=time.perf_counter()-start)
    (H/'prediction_freeze.json').write_text(json.dumps(f,indent=2)+'\n');print('PREDICTIONS_FROZEN',f,flush=True)
if __name__=='__main__':main()
