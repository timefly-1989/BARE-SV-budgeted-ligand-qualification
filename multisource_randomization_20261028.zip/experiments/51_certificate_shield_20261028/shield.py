"""Exact discovery-certificate shield, independent of probability calibration.

Proposals use only fixed inputs and outcomes previously returned by reveal().
The historical experiment50 code is imported unchanged as a matched control.
"""
from pathlib import Path
import sys
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parent.parent/'50_discovery_allocation_20261028'))
from policies import Policy,simulate as old_simulate

class ShieldPolicy(Policy):
    def __init__(self,score,pool,key,B,algorithm,seed=11):
        self.proposal=algorithm.removeprefix('shield_')
        super().__init__(score,pool,key,B,self.proposal,seed)
        self.is_baseline=np.zeros(len(self.u),bool);self.is_baseline[self.uniform]=True
        self.interventions=0;self.free_steps=0
    def obligations(self):
        return self.active & self.is_baseline & ~np.isin(self.group,list(self.hits))
    def action(self):
        obligated=self.obligations();h=int(obligated.sum());r=self.K-len(self.selected)
        assert h<=r
        proposed=super().action()
        if h<r:
            self.free_steps+=1;return proposed
        if obligated[proposed]:return proposed
        self.interventions+=1
        if self.proposal=='global':v=self.u
        elif self.proposal=='latent_greedy':v=self.mean()
        else:raise ValueError('No untested shield fallback')
        return self.tie(v,np.flatnonzero(obligated))

def simulate(score,pool,key,y,B,algorithm,seed=11,trace=False):
    if not algorithm.startswith('shield_'):return old_simulate(score,pool,key,y,B,algorithm,seed,trace)
    p=ShieldPolicy(score,pool,key,B,algorithm,seed);y=np.asarray(y,int);events=[]
    for t in range(p.K):
        before=int(p.obligations().sum());r=p.K-t;i=p.action();p.reveal(i,int(y[i]))
        assert int(p.obligations().sum())<=r-1
        if trace:events.append(dict(step=t+1,index=int(i),key=str(p.key[i]),pool=str(p.pool[i]),y=int(y[i]),obligations_before=before,remaining_before=r,slack_before=r-before))
    ix=np.asarray(p.selected,int);base={p.pool[i] for i in p.uniform if y[i]};hits={p.pool[i] for i in ix if y[i]}
    assert base<=hits
    return dict(K=p.K,C=int(y[ix].sum()),coverage=len(hits),baseline_coverage=len(base),baseline_lost=0,score_sum=float(p.u[ix].sum()),pilot_calls=None,interventions=p.interventions,free_steps=p.free_steps),ix,events
