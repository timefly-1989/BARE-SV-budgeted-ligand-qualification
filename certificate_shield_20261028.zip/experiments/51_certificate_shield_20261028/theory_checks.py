"""Exhaustive completion feasibility and safe-action iff checks, plus Bellman DP."""
from pathlib import Path
from functools import lru_cache
import itertools,json
import numpy as np
H=Path(__file__).resolve().parent

def main():
    # 6 candidates, 3 pools, 3 nonempty baseline quotas, 4 checks.
    group=np.array([0,0,1,1,2,2]);U=set([0,1,2,4]);K=4;n=6
    states=actions=batches=0
    @lru_cache(None)
    def viable(state,r):
        S={i for i,y in enumerate(state) if y>=0};hits={group[i] for i in S if state[i]==1}
        if r==0:return all(group[i] in hits or i in S for i in U)
        for a in range(n):
            if a in S:continue
            branches=[]
            for y in [0,1]:
                s=list(state);s[a]=y;branches.append(viable(tuple(s),r-1))
            if all(branches):return True
        return False
    for state in itertools.product([-1,0,1],repeat=n):
        t=sum(y>=0 for y in state)
        if t>K:continue
        r=K-t;hits={group[i] for i,y in enumerate(state) if y==1}
        O={i for i in U if state[i]<0 and group[i] not in hits};h=len(O)
        assert viable(state,r)==(h<=r);states+=1
        if not r or h>r:continue
        for a in range(n):
            if state[a]>=0:continue
            exact=True
            for y in [0,1]:
                s=list(state);s[a]=y;exact &= viable(tuple(s),r-1)
            assert exact==(h<r or a in O);actions+=1
        remaining=[i for i,y in enumerate(state) if y<0]
        for m in range(1,r+1):
            for A in itertools.combinations(remaining,m):
                exact=True
                for values in itertools.product([0,1],repeat=m):
                    s=list(state)
                    for i,y in zip(A,values):s[i]=y
                    exact &= viable(tuple(s),r-m)
                assert exact==(len(set(A)-O)<=r-h);batches+=1
    # Arbitrary-dependence exact posterior: expectation over a finite outcome law.
    rng=np.random.default_rng(11028);examples=[]
    for _ in range(12):
        p=rng.uniform(.05,.95,n)
        @lru_cache(None)
        def value(state,r,safe):
            if r==0:return 0.
            hits={group[i] for i,y in enumerate(state) if y==1}
            O={i for i in U if state[i]<0 and group[i] not in hits};h=len(O)
            allowed=[i for i,y in enumerate(state) if y<0 and (not safe or h<r or i in O)]
            vals=[]
            for i in allowed:
                s0=list(state);s1=list(state);s0[i]=0;s1[i]=1
                vals.append(p[i]+(1-p[i])*value(tuple(s0),r-1,safe)+p[i]*value(tuple(s1),r-1,safe))
            return max(vals)
        v=value((-1,)*n,K,True);w=value((-1,)*n,K,False)
        assert v<=w+1e-12
        examples.append(dict(p=p.tolist(),safe_optimum=v,unrestricted_optimum=w,model_protection_price=w-v))
    out=dict(status='PASS',completion_states=states,safe_action_checks=actions,batch_feasibility_checks=batches,bellman_models=examples,not_originality_or_large_scale_optimality_proof=True)
    (H/'checks/theory.json').write_text(json.dumps(out,indent=2));print({k:v for k,v in out.items() if k!='bellman_models'})
if __name__=='__main__':main()
