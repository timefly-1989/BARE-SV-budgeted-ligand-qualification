"""Read structures and activity-availability masks, without casting activity signs."""
from pathlib import Path
import csv,datetime,gzip,hashlib,json,time
import numpy as np,pandas as pd
from rdkit import Chem,RDLogger
H=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def key(s):return hashlib.sha256(s.encode()).hexdigest()
def main():
    RDLogger.DisableLog('rdApp.*');p=json.loads((H/'new_sparse_protocol.json').read_text());assert sha(H/'raw/pcba.csv.gz')==p['raw_sha256']
    amendment=json.loads((H/'source_amendment_before_labels.json').read_text())
    assert sha(__file__)==amendment['corrected_prepare_sha256'];a=p['campaign_assignments'];assays=sorted(a);rows=[];invalid=[];seen=set();start=time.perf_counter()
    with gzip.open(H/'raw/pcba.csv.gz','rt') as f:
        r=csv.reader(f);cols=next(r);idx=[cols.index(s) for s in assays];ic=cols.index('mol_id');ism=cols.index('smiles')
        for n,row in enumerate(r,1):
            if not row:continue  # Preserve source-row numbering while ignoring blank CSV records.
            assert len(row)==len(cols),(n,len(row),len(cols))
            mol=Chem.MolFromSmiles(row[ism])
            if mol is None:invalid.append(n);continue
            Chem.RemoveStereochemistry(mol);graph=Chem.MolToSmiles(mol,canonical=True,isomericSmiles=False)
            g=key(graph);support=int(key('role|'+g),16)%5==0;owner=1+int(key('owner|'+g),16)%16;cap=key('cap|'+g)
            for assay,j in zip(assays,idx):
                # Presence only. No float/int cast and no activity-value selection.
                if not row[j].strip():continue
                if not support and a[assay]!=f'PCBA-C{owner:02}':continue
                ident=(assay,g)
                if ident in seen:continue
                seen.add(ident);rows.append((assay,a[assay],g,row[ic],n,'support' if support else 'query',cap,graph))
            if n%50000==0:print('INPUT_ROWS',n,flush=True)
    d=pd.DataFrame(rows,columns=['assay','campaign','key','source_mol_id','source_row','role','cap_hash','smiles'])
    d=d.sort_values(['assay','role','cap_hash','source_row'])
    d=d[d.groupby(['assay','role'],sort=False).cumcount()<np.where(d.role.eq('support'),2048,4096)].reset_index(drop=True)
    d=d.drop(columns=['cap_hash'])
    d.to_csv(H/'data/sparse_partition.csv',index=False)
    q=d[d.role.eq('query')];s=d[d.role.eq('support')]
    assert not set(s.key)&set(q.key)
    assert q.groupby('key').campaign.nunique().max()==1
    out=dict(timestamp=datetime.datetime.now().astimezone().isoformat(),partition_sha256=sha(H/'data/sparse_partition.csv'),protocol_sha256=sha(H/'new_sparse_protocol.json'),
        total_source_rows=n,invalid_source_rows=invalid,kept_records=len(d),support_records=len(s),query_records=len(q),query_graphs=q.key.nunique(),
        query_activity_signs_inspected=False,seconds=time.perf_counter()-start)
    (H/'partition_freeze.json').write_text(json.dumps(out,indent=2)+'\n');print('PARTITION',out,flush=True)
if __name__=='__main__':main()
