"""Numerical/code release only; no unsubmitted manuscript or source activity rows."""
from pathlib import Path
import hashlib,json,shutil,zipfile
import pandas as pd
H=Path(__file__).resolve().parent;R=H.parents[1];O=H.parent/'50_discovery_allocation_20261028'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def main():
    dest=H/'release/certificate_shield_20261028';dest.mkdir(parents=True,exist_ok=True)
    files=[H/n for n in ['shield.py','theory_checks.py','development.py','sparse_protocol.py','get_metadata.py','sparse_prepare.py','sparse_fit.py','sparse_evaluate.py','validate_evidence.py','replay_public.py','figures_and_analysis.py','build_numerical_release.py']]
    files += [H/n for n in ['new_sparse_protocol.json','source_amendment_before_labels.json','partition_freeze.json','sparse_prediction_freeze.json','sparse_evaluation_opened.json']]
    files += [p for p in (H/'results').glob('*.csv') if p.name!='shield_primary_traces.csv']+list((H/'results').glob('*.json'))
    files += [H/'data/sparse_scores_before_labels.csv',H/'sources/metadata_summary.json',H/'checks/theory.json',H/'checks/evidence_validation.json',H/'checks/public_replay.json']
    files += list((H/'figures').glob('*.svg'))
    files += [O/'policies.py',O/'requirements.txt']
    for source in files:
        target=dest/source.relative_to(R);target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,target)
    local=dest/H.relative_to(R);(local/'checks').mkdir(exist_ok=True);shutil.copy2(O/'requirements.txt',local/'requirements.txt')
    d=pd.read_csv(H/'data/sparse_partition.csv');d.drop(columns=['smiles']).to_csv(local/'data/sparse_row_map.csv',index=False)
    text='''# Certificate-constrained allocation: sparse activity evidence (28 October 2026)

This numerical release accompanies a local manuscript revision. It does not
include or publish the unsubmitted manuscript. Runtime shielding and Bellman
recursion are established principles; no priority or journal-readiness claim is
made by this release.

Primary result: 16 constructed four-assay PCBA campaigns, 242,888 queries and
3,466 measured actives (1.426995%). At 2,048 checks, uniform / DPQR / global
recover 252 / 374 / 438; baseline discoveries lost are 0 / 0 / 15. Both two-test
Holm-adjusted campaign sign flips are 0.00537109375. Inference is conditional on
independent, sign-symmetric differences. All selected assays record NCGC as
their source; neither family nor laboratory independence is certified. Capped
query panels are not complete original HTS campaigns. Support cost is common
and excluded from the query budget. No new wet-lab or chemical qualification
outcomes were acquired. The earlier frozen FS-Mol primary p=.0625 is unchanged.

The new protocol, source hashes and parsing amendment precede query activity
export. The original protocol is preserved. The source CSV contains blank
records; a dated implementation correction preserves consistent source rows
without changing groups, caps, models, endpoints or comparisons.

## Source and replay

Download the original PCBA CSV from the DeepChem distribution:
https://deepchemdata.s3-us-west-1.amazonaws.com/datasets/pcba.csv.gz
SHA256 b429a13ff6310aabb2d5ae1f41ea9d9c025e2c73fbf733cea33a62b4f163db19
Original benchmark: Wu et al., Chemical Science 9 (2018), 513-530,
doi:10.1039/C7SC02664A. Assay descriptions: PubChem PUG REST, description/JSON.
Source assay/compound records retain provider attribution and terms. This
package redistributes scores and derived row mappings, not raw source SMILES
or row-level source activity labels. They are reconstructed from the source.

From the extracted package root:
```
uv run --no-project --python 3.12 --with-requirements experiments/51_certificate_shield_20261028/requirements.txt python experiments/51_certificate_shield_20261028/replay_public.py --archive /absolute/path/pcba.csv.gz --refit
uv run --no-project --python 3.12 --with-requirements experiments/51_certificate_shield_20261028/requirements.txt python experiments/51_certificate_shield_20261028/theory_checks.py
```
The first command replays all640 values and refits64 forests if --refit is set.
No checkpoint, planner stock/template or clinical/binding affinity claim is
included. Complete earlier FS-Mol and chemical evidence remains in prior releases.
'''
    (dest/'README.md').write_text(text)
    hashes={str(p.relative_to(dest)):sha(p) for p in dest.rglob('*') if p.is_file() and p.name!='SHA256SUMS.json'}
    (dest/'SHA256SUMS.json').write_text(json.dumps(hashes,indent=2)+'\n')
    target=H/'release/certificate_shield_20261028.zip'
    with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for p in sorted(dest.rglob('*')):
            if p.is_file():z.write(p,p.relative_to(dest))
    out=dict(path=str(target.relative_to(R)),bytes=target.stat().st_size,sha256=sha(target),payload_files=len(hashes),contains_unsubmitted_manuscript=False,contains_source_activity_rows=False)
    (H/'release/archive_manifest.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
if __name__=='__main__':main()
