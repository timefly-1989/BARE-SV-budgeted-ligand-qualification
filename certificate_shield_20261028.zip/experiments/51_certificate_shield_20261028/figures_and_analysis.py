"""Transparent reporting from locked outcomes. No policy or grouping selection."""
from pathlib import Path
import json
import numpy as np,pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch,FancyArrowPatch
H=Path(__file__).resolve().parent
NAMES={'uniform':'Uniform','global':'Global','recycling':'DPQR','shield_global':'Shield / fixed','shield_latent_greedy':'Shield / posterior','latent_greedy':'Posterior greedy','latent_UCB':'Posterior UCB','observed_4':'Observed coverage (4)'}
COLORS={'uniform':'#526579','global':'#d97a25','recycling':'#147d83','shield_latent_greedy':'#9561a4','latent_greedy':'#638c40','latent_UCB':'#b35465','observed_4':'#367db2'}
def export(fig,name):
    for ext in ['pdf','svg','png']:fig.savefig(H/f'figures/{name}.{ext}',dpi=190,bbox_inches='tight')
    plt.close(fig)
def table(path,caption,label,heads,rows,note):
    s='\\begin{table}[!htbp]\\centering\n\\caption{'+caption+'}\\label{'+label+'}\n\\small\n\\begin{tabular}{l'+'r'*(len(heads)-1)+'}\\toprule\n'+' & '.join(heads)+' \\\\\\midrule\n'
    s+='\n'.join(' & '.join(map(str,row))+' \\\\' for row in rows)+'\n\\bottomrule\\end{tabular}\n\\par\\vspace{3pt}\\footnotesize '+note+'\n\\end{table}\n';path.write_text(s)
def main():
    for n in ['figures','tables']:(H/n).mkdir(exist_ok=True)
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':11,'pdf.fonttype':42,'svg.fonttype':'none','axes.spines.top':False,'axes.spines.right':False})
    fig,ax=plt.subplots(figsize=(11,4));ax.set_xlim(0,11);ax.set_ylim(0,4);ax.axis('off')
    boxes=[(.05,2.05,3.0,1.65,'Observed history','Baseline U; budget K\nSelected candidates + labels\nUnresolved obligations O'),(3.5,2.05,3.1,1.65,'Exact action mask','Checks left r; obligations h\nIf h < r: all unchecked items\nIf h = r: obligations only'),(7.05,2.05,3.85,1.65,'Protected adaptive query','Rank admissible candidates\nCheck once; observe outcome\nUpdate obligations and posterior')]
    for x,y,w,h,title,body in boxes:
        ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle='round,pad=.03',facecolor='#eff5f6',edgecolor='#51757c',lw=1.1));ax.text(x+.13,y+h-.18,title,fontsize=12.5,weight='bold',va='top');ax.text(x+.13,y+h-.62,body,fontsize=10.5,va='top',linespacing=1.5)
    for x1,x2 in [(3.1,3.45),(6.65,7.0)]:ax.add_patch(FancyArrowPatch((x1,2.87),(x2,2.87),arrowstyle='-|>',mutation_scale=15,color='#51757c'))
    ax.plot([8.7,8.7,1.55],[2.0,1.3,1.3],c='#51757c',lw=1.2)
    ax.add_patch(FancyArrowPatch((1.55,1.3),(1.55,2.0),arrowstyle='->',mutation_scale=13,color='#51757c'))
    ax.text(5.1,1.45,'Selected-outcome feedback',ha='center',fontsize=11)
    ax.text(.1,.75,'Feasibility: h ≤ r at every step. Terminal r = 0 implies no unresolved obligations.',fontsize=12,weight='bold',color='#176970')
    ax.text(.1,.23,'Fixed-score greedy = DPQR terminal set. Posterior proposals may adapt; protection remains pathwise.',fontsize=11)
    export(fig,'certificate_shield')
    d=pd.read_csv(H/'results/sparse_campaigns.csv');stats=json.loads((H/'results/sparse_primary_tests.json').read_text())
    g=d.groupby(['B','algorithm'])[['K','C','coverage','baseline_lost']].sum().reset_index();g.to_csv(H/'results/sparse_budget_summary.csv',index=False)
    q=g[g.B.eq(32)].set_index('algorithm');rows=[[NAMES[a],int(q.loc[a,'C']),int(q.loc[a,'coverage']),int(q.loc[a,'baseline_lost'])] for a in NAMES]
    table(H/'tables/sparse_controls.tex','Locked sparse-HTS test at 2,048 query checks.','tab:sparse-controls',['Policy',r'$C$',r'Cov',r'$L_U$'],rows,'The same primary Morgan random forest supplies all scores. Results sum 16 prespecified four-assay campaigns; the 64 query pools were selected and capped without inspecting activity signs. Fixed-score shielding is an implementation-equivalent control. Posterior and soft-coverage comparisons are secondary.')
    table(H/'tables/sparse_controls_zh.tex','冻结稀疏HTS测试：2,048次查询检查。','tab:sparse-controls',['策略',r'$C$',r'Cov',r'$L_U$'],rows,'所有策略共用主Morgan随机森林得分，汇总16个预定四测定活动。64个查询池的选择及上限不使用活性符号。固定得分约束器是实现等价对照，后验及软覆盖比较为次要分析。')
    z=d[d.B.eq(32)].pivot(index='campaign',columns='algorithm',values=['C','coverage','baseline_lost']);rows=[]
    for i,c in enumerate(z.index,1):rows.append([i,*[int(z.loc[c,('C',a)]) for a in ['uniform','recycling','global']],int(z.loc[c,('coverage','uniform')]),int(z.loc[c,('coverage','global')]),int(z.loc[c,('C','recycling')]-z.loc[c,('C','uniform')])])
    table(H/'tables/sparse_campaigns.tex','All locked sparse-HTS campaigns at 128 query checks each.','tab:si-sparse-campaigns',['Campaign',r'$C_U$',r'$C_R$',r'$C_G$',r'Cov$_U$',r'Cov$_G$',r'$C_R-C_U$'],rows,'Each campaign contains four fixed assays. DPQR retains every uniform-baseline discovery in every campaign. All campaigns, including ties and the negative recovery difference, are retained.')
    table(H/'tables/sparse_campaigns_zh.tex','全部冻结稀疏HTS活动，每活动128次查询检查。','tab:si-sparse-campaigns',['活动',r'$C_U$',r'$C_R$',r'$C_G$',r'Cov$_U$',r'Cov$_G$',r'$C_R-C_U$'],rows,'每活动四个固定测定，DPQR在各活动保留全部统一基线发现。所有活动均保留，包括平局及负回收差。')
    fig,axes=plt.subplots(1,3,figsize=(10.6,3.5));base=g[g.algorithm.eq('uniform')].set_index('B').C
    for a in COLORS:
        z=g[g.algorithm.eq(a)].sort_values('B');axes[0].plot(z.B,z.C,c=COLORS[a],marker='o',ms=3,label=NAMES[a]);axes[1].plot(z.B,z.baseline_lost,c=COLORS[a],marker='o',ms=3)
    for ax in axes[:2]:ax.set_xscale('log',base=2);ax.set_xticks([4,8,16,32,64],labels=['4','8','16','32','64']);ax.set_xlabel('Quota per assay');ax.grid(alpha=.16)
    axes[0].set_ylabel('Recovered measured actives');axes[1].set_ylabel('Lost baseline-discovered assays')
    z=d[d.B.eq(32)].pivot(index='campaign',columns='algorithm',values='C');delta=z.recycling-z.uniform;x=np.arange(1,17)
    axes[2].bar(x,delta,color='#147d83');axes[2].axhline(0,c='#526579',lw=.8);axes[2].set_xticks([1,4,8,12,16]);axes[2].set_xlabel('Prespecified complete campaign');axes[2].set_ylabel('DPQR minus uniform recovery')
    handles,labels=axes[0].get_legend_handles_labels();fig.legend(handles,labels,loc='lower center',bbox_to_anchor=(.5,-.25),ncol=4,frameon=False,fontsize=9.5);fig.tight_layout();export(fig,'sparse_activity')
    # Conditional descriptive campaign bootstrap; it does not establish biological independence.
    rng=np.random.default_rng(28011);v=delta.to_numpy();b=rng.choice(v,size=(20000,len(v)),replace=True).sum(1)
    stats['descriptive_total_recovery_difference_interval']=np.quantile(b,[.025,.975]).tolist()
    stats['primary_aggregate']={a:{k:int(q.loc[a,k]) for k in ['K','C','coverage','baseline_lost']} for a in NAMES}
    stats['DPQR_campaign_wins_ties_losses']=[int((v>0).sum()),int((v==0).sum()),int((v<0).sum())]
    (H/'results/manuscript_sparse_numbers.json').write_text(json.dumps(stats,indent=2)+'\n')
    print(json.dumps(stats,indent=2))
if __name__=='__main__':main()
