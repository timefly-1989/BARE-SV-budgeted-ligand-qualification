"""Development only: shielded policies on already research-exposed outcomes."""
from pathlib import Path
import pandas as pd
from shield import simulate
H=Path(__file__).resolve().parent
def main():
    d=pd.read_csv(H.parent/'35_stage_evidence_upgrade_20261027/results/analysis_scores.csv');d=d[d.cohort.eq('development')];out=[]
    for fold,g in d.groupby('fold'):
        for B in [4,8,16]:
            for a in ['uniform','global','recycling','shield_global','shield_latent_greedy','latent_greedy']:
                r,ix,_=simulate(g.chemeleon_compact_qualification,g.pocket_id,g.candidate_id,g.y,B,a)
                out.append(dict(fold=fold,B=B,algorithm=a,**r))
        print('DONE_FOLD',fold,flush=True)
    s=pd.DataFrame(out);s.to_csv(H/'results/shield_development.csv',index=False)
    print(s.groupby(['B','algorithm'])[['C','coverage','baseline_lost']].sum().to_string(),flush=True)
if __name__=='__main__':main()
