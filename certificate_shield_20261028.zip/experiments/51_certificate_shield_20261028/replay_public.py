"""Replay new sparse activity results from the official raw source; optionally refit RF.

uv run --no-project --python 3.12 --with-requirements experiments/51_certificate_shield_20261028/requirements.txt python experiments/51_certificate_shield_20261028/replay_public.py --archive /path/pcba.csv.gz --refit
"""
from pathlib import Path
import argparse,hashlib,json,time
import numpy as np,pandas as pd
from shield import simulate
H=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def main():
    parser=argparse.ArgumentParser();parser.add_argument('--archive',type=Path,required=True);parser.add_argument('--refit',action='store_true');a=parser.parse_args();start=time.perf_counter()
    protocol=json.loads((H/'new_sparse_protocol.json').read_text());assert sha(a.archive)==protocol['raw_sha256']
    path=H/'data/sparse_row_map.csv';partition=pd.read_csv(path if path.exists() else H/'data/sparse_partition.csv',dtype={'source_mol_id':str})
    raw=pd.read_csv(a.archive,usecols=protocol['selected_assays']+['mol_id','smiles'],dtype={'mol_id':str}).set_index('mol_id');assert raw.index.is_unique
    def labels(frame):return np.array([int(raw.loc[c,assay]) for c,assay in zip(frame.source_mol_id,frame.assay)],int)
    scores=pd.read_csv(H/'data/sparse_scores_before_labels.csv');assert sha(H/'data/sparse_scores_before_labels.csv')==json.loads((H/'sparse_prediction_freeze.json').read_text())['scores_sha256']
    q=partition[partition.role.eq('query')];scores=scores.merge(q[['assay','key','source_mol_id']],on=['assay','key'],validate='one_to_one');scores['y']=labels(scores)
    expected=pd.read_csv(H/'results/sparse_campaigns.csv');count=0
    for cid,g in scores.groupby('campaign'):
        g=g.sort_values(['assay','key']).reset_index(drop=True)
        for B in [4,8,16,32,64]:
            for algorithm in protocol['algorithms']:
                result,_,_=simulate(g.score,g.assay,g.key,g.y,B,algorithm,11)
                row=expected[(expected.campaign==cid)&(expected.B==B)&(expected.algorithm==algorithm)].iloc[0]
                for k in ['K','C','coverage','baseline_coverage','baseline_lost']:assert result[k]==row[k],(cid,B,algorithm,k)
                count+=1
        print('PUBLIC_REPLAY',cid,flush=True)
    errors=[]
    if a.refit:
        from rdkit import Chem,RDLogger
        from rdkit.Chem import rdFingerprintGenerator
        from sklearn.ensemble import RandomForestClassifier
        RDLogger.DisableLog('rdApp.*');gen=rdFingerprintGenerator.GetMorganGenerator(radius=2,fpSize=2048);fps={}
        for r in partition[['key','source_mol_id']].drop_duplicates('key').itertuples(index=False):
            mol=Chem.MolFromSmiles(raw.loc[r.source_mol_id,'smiles']);Chem.RemoveStereochemistry(mol);graph=Chem.MolToSmiles(mol,canonical=True,isomericSmiles=False)
            assert hashlib.sha256(graph.encode()).hexdigest()==r.key
            fps[r.key]=np.asarray(gen.GetFingerprint(Chem.MolFromSmiles(graph)),np.uint8)
        for assay,g in partition.groupby('assay'):
            s=g[g.role.eq('support')].sort_values('key');v=g[g.role.eq('query')].sort_values('key');y=labels(s)
            if len(set(y))<2:p=np.full(len(v),(y.sum()+1)/(len(y)+2))
            else:
                model=RandomForestClassifier(n_estimators=256,min_samples_leaf=2,max_features='sqrt',class_weight=None,random_state=11,n_jobs=4)
                model.fit(np.stack([fps[k] for k in s.key]),y);p=model.predict_proba(np.stack([fps[k] for k in v.key]))[:,1]
            z=scores[scores.assay.eq(assay)].set_index('key');error=float(np.max(np.abs(p-z.loc[v.key,'score'].to_numpy())));assert error<1e-12,(assay,error);errors.append(error)
            print('PUBLIC_REFIT',assay,error,flush=True)
    out=dict(status='PASS',policy_values_replayed=count,models_refitted=len(errors),maximum_probability_error=max(errors,default=None),seconds=time.perf_counter()-start,source_labels_reconstructed_not_redistributed=True)
    (H/'checks').mkdir(exist_ok=True);(H/'checks/public_replay.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
if __name__=='__main__':main()
