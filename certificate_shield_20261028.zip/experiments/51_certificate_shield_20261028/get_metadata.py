"""Input-only PubChem assay descriptions; no compound activity rows."""
from pathlib import Path
import concurrent.futures,csv,gzip,json,time,urllib.request
H=Path(__file__).resolve().parent
def fetch(a):
    p=H/'sources'/f'aid{a}.json'
    if p.exists():return a,True
    for attempt in range(4):
        try:
            req=urllib.request.Request(f'https://pubchem.ncbi.nlm.nih.gov/rest/pug/assay/aid/{a}/description/JSON',headers={'User-Agent':'Scientific allocation benchmark/1.0'})
            with urllib.request.urlopen(req,timeout=60) as f:x=json.load(f)
            p.write_text(json.dumps(x,indent=2));return a,True
        except Exception as e:
            if attempt==3:return a,str(e)
            time.sleep(2+attempt)
def main():
    with gzip.open(H/'raw/pcba.csv.gz','rt') as f:columns=next(csv.reader(f))
    aids=[int(c.split('-')[1]) for c in columns if c.startswith('PCBA-')]
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex:
        for a,ok in ex.map(fetch,aids):print(a,ok,flush=True)
    out=[]
    for a in aids:
        p=H/'sources'/f'aid{a}.json'
        if not p.exists():continue
        d=json.loads(p.read_text())['PC_AssayContainer'][0]['assay']['descr']
        genes=sorted({int(v['xref']['gene']) for v in d.get('xref',[]) if 'gene' in v.get('xref',{})})
        targets=sorted({str(t.get('mol_id','')) for t in d.get('target',[]) if t.get('mol_id')})
        out.append(dict(assay=f'PCBA-{a}',name=d.get('name'),source=d.get('aid_source'),genes=genes,targets=targets))
    (H/'sources/metadata_summary.json').write_text(json.dumps(out,indent=2))
    print('DESCRIPTIONS',len(out),flush=True)
if __name__=='__main__':main()
