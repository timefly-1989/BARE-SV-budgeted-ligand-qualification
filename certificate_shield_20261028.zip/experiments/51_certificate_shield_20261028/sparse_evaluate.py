"""Open query labels after score freeze; evaluate the unchanged locked campaign design."""
from pathlib import Path
import csv,datetime,gzip,hashlib,itertools,json,time
import numpy as np,pandas as pd
from shield import simulate
H=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def main():
    p=json.loads((H/'new_sparse_protocol.json').read_text());am=json.loads((H/'source_amendment_before_labels.json').read_text());assert sha(__file__)==am['corrected_source_sha256']['sparse_evaluate.py']
    f=json.loads((H/'sparse_prediction_freeze.json').read_text());assert sha(H/'data/sparse_scores_before_labels.csv')==f['scores_sha256']
    d=pd.read_csv(H/'data/sparse_scores_before_labels.csv');permitted={(int(r.source_row),r.assay):r.key for r in d.itertuples()};labels=[]
    with gzip.open(H/'raw/pcba.csv.gz','rt') as stream:
        reader=csv.reader(stream);cols=next(reader)
        for n,raw in enumerate(reader,1):
            if not raw:continue
            row=dict(zip(cols,raw))
            for assay in p['selected_assays']:
                if (n,assay) in permitted:labels.append(dict(assay=assay,key=permitted[(n,assay)],y=int(float(row[assay]))))
    y=pd.DataFrame(labels);y.to_csv(H/'data/sparse_query_labels.csv',index=False)
    (H/'sparse_evaluation_opened.json').write_text(json.dumps(dict(timestamp=datetime.datetime.now().astimezone().isoformat(),prediction_freeze_sha256=sha(H/'sparse_prediction_freeze.json'),query_labels_sha256=sha(H/'data/sparse_query_labels.csv')),indent=2)+'\n')
    d=d.merge(y,on=['assay','key'],validate='one_to_one');rows=[];trace=[]
    for cid,g in d.groupby('campaign',sort=True):
        g=g.sort_values(['assay','key']).reset_index(drop=True)
        for B in [4,8,16,32,64]:
            for algorithm in p['algorithms']:
                t=time.perf_counter();res,ix,events=simulate(g.score,g.assay,g.key,g.y,B,algorithm,11,trace=B==32 and algorithm.startswith('shield_'))
                rows.append(dict(campaign=cid,B=B,algorithm=algorithm,**res,seconds=time.perf_counter()-t))
                trace.extend(dict(campaign=cid,algorithm=algorithm,**e) for e in events)
        pd.DataFrame(rows).to_csv(H/'results/sparse_campaigns.csv',index=False);print('EVALUATED',cid,flush=True)
    pd.DataFrame(trace).to_csv(H/'results/shield_primary_traces.csv',index=False)
    z=pd.DataFrame(rows);primary=z[z.B.eq(32)];pivot=primary.pivot(index='campaign',columns='algorithm',values=['C','baseline_lost']);tests=[]
    for title,v in [(p['primary_contrasts'][0],pivot.C.recycling-pivot.C.uniform),(p['primary_contrasts'][1],pivot.baseline_lost['global']-pivot.baseline_lost.recycling)]:
        a=v.to_numpy(int);sums=np.array([sum(s*x for s,x in zip(sign,a)) for sign in itertools.product([-1,1],repeat=len(a))]);pv=float(np.mean(np.abs(sums)>=abs(a.sum())-1e-12))
        tests.append(dict(contrast=title,differences=a.tolist(),raw_p=pv,campaigns=len(a),nonzero=int(np.count_nonzero(a))))
    order=np.argsort([r['raw_p'] for r in tests]);prev=0.
    for rank,i in enumerate(order):prev=max(prev,min(1.,(len(tests)-rank)*tests[i]['raw_p']));tests[i]['Holm_p']=prev
    summary=primary.groupby('algorithm')[['K','C','coverage','baseline_lost']].sum().reset_index();summary.to_csv(H/'results/sparse_primary_summary.csv',index=False)
    stats=dict(queries=len(d),query_actives=int(d.y.sum()),prevalence=float(d.y.mean()),positive_assays=int(d.groupby('assay').y.sum().gt(0).sum()),assays=d.assay.nunique(),campaigns=d.campaign.nunique(),primary_quota=32,
        primary_tests=tests,inference_scope=p['primary_analysis'],not_new_wetlab=True,not_entire_original_HTS_panels=True)
    (H/'results/sparse_primary_tests.json').write_text(json.dumps(stats,indent=2)+'\n');print(summary.to_string(index=False));print(json.dumps(stats),flush=True)
if __name__=='__main__':main()
