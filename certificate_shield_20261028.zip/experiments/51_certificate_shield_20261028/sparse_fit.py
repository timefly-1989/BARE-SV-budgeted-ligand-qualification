"""Open only locked support labels, then freeze all query scores."""
import os
for k in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','VECLIB_MAXIMUM_THREADS']:os.environ[k]='1'
from pathlib import Path
import csv,datetime,gzip,hashlib,json,time
import numpy as np,pandas as pd
from rdkit import Chem,RDLogger
from rdkit.Chem import rdFingerprintGenerator
from sklearn.ensemble import RandomForestClassifier
H=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def main():
    RDLogger.DisableLog('rdApp.*');start=time.perf_counter();p=json.loads((H/'new_sparse_protocol.json').read_text());am=json.loads((H/'source_amendment_before_labels.json').read_text());assert sha(__file__)==am['corrected_source_sha256']['sparse_fit.py']
    z=json.loads((H/'partition_freeze.json').read_text());assert sha(H/'data/sparse_partition.csv')==z['partition_sha256']
    d=pd.read_csv(H/'data/sparse_partition.csv');s=d[d.role.eq('support')];q=d[d.role.eq('query')]
    permitted={(int(r.source_row),r.assay):r.key for r in s.itertuples()};labels={}
    with gzip.open(H/'raw/pcba.csv.gz','rt') as f:
        r=csv.reader(f);cols=next(r)
        for n,raw in enumerate(r,1):
            if not raw:continue
            row=dict(zip(cols,raw))
            for assay in p['selected_assays']:
                if (n,assay) in permitted:labels[(assay,permitted[(n,assay)])]=int(float(row[assay]))
    gen=rdFingerprintGenerator.GetMorganGenerator(radius=2,fpSize=2048)
    fps={k:np.asarray(gen.GetFingerprint(Chem.MolFromSmiles(sm)),dtype=np.uint8) for k,sm in d[['key','smiles']].drop_duplicates('key').itertuples(index=False,name=None)}
    out=[];audit=[]
    for assay in sorted(p['selected_assays']):
        t=s[s.assay.eq(assay)].sort_values('key');v=q[q.assay.eq(assay)].sort_values('key');y=np.array([labels[(assay,k)] for k in t.key],int)
        assert set(y)<=set([0,1])
        xx=np.stack([fps[k] for k in v.key]) if len(v) else np.empty((0,2048),np.uint8)
        if len(set(y))<2:pred=np.full(len(v),(y.sum()+1)/(len(y)+2))
        else:
            model=RandomForestClassifier(n_estimators=256,min_samples_leaf=2,max_features='sqrt',class_weight=None,random_state=11,n_jobs=4)
            model.fit(np.stack([fps[k] for k in t.key]),y);pred=model.predict_proba(xx)[:,1] if len(v) else np.array([])
        for row,score in zip(v.itertuples(),pred):out.append(dict(campaign=row.campaign,assay=assay,key=row.key,source_row=row.source_row,score=float(score)))
        audit.append(dict(assay=assay,support=len(t),support_positives=int(y.sum()),query=len(v),single_class=len(set(y))<2));print('SCORED',assay,len(v),flush=True)
    pd.DataFrame(out).to_csv(H/'data/sparse_scores_before_labels.csv',index=False);pd.DataFrame(audit).to_csv(H/'results/sparse_support.csv',index=False)
    pd.DataFrame([dict(assay=a,key=k,y=y) for (a,k),y in labels.items()]).to_csv(H/'data/sparse_support_labels.csv',index=False)
    f=dict(timestamp=datetime.datetime.now().astimezone().isoformat(),scores_sha256=sha(H/'data/sparse_scores_before_labels.csv'),protocol_sha256=sha(H/'new_sparse_protocol.json'),partition_freeze_sha256=sha(H/'partition_freeze.json'),
        support_labels_sha256=sha(H/'data/sparse_support_labels.csv'),query_labels_exported=False,query_labels_used=False,score_rows=len(out),seconds=time.perf_counter()-start)
    (H/'sparse_prediction_freeze.json').write_text(json.dumps(f,indent=2)+'\n');print('PREDICTIONS_FROZEN',f,flush=True)
if __name__=='__main__':main()
