"""Lock a new PCBA activity evaluation before query activity inspection."""
from pathlib import Path
import datetime,hashlib,json
H=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def rank(s):return hashlib.sha256(('DP-CERT|PCBA|20261028|'+s).encode()).hexdigest()
def main():
    assert not (H/'new_sparse_protocol.json').exists(),'Do not replace an existing protocol'
    x=json.loads((H/'sources/metadata_summary.json').read_text());parent={r['assay']:r['assay'] for r in x}
    def root(a):
        while parent[a]!=a:a=parent[a]
        return a
    seen={}
    for r in x:
        for k in ['gene:'+str(g) for g in r['genes']]+['target:'+str(g) for g in r['targets']]:
            if k in seen:parent[root(r['assay'])]=root(seen[k])
            seen[k]=r['assay']
    comp={}
    for r in x:comp.setdefault(root(r['assay']),[]).append(r['assay'])
    reps=[min(v,key=rank) for v in comp.values()];selected=sorted(reps,key=rank)[:64]
    assignments={a:f'PCBA-C{1+i//4:02}' for i,a in enumerate(selected)}
    obj=dict(timestamp=datetime.datetime.now().astimezone().isoformat(),dataset='DeepChem/MoleculeNet PCBA',
        source_url='https://deepchemdata.s3-us-west-1.amazonaws.com/datasets/pcba.csv.gz',raw_sha256=sha(H/'raw/pcba.csv.gz'),
        metadata_sha256=sha(H/'sources/metadata_summary.json'),input_assays=128,target_identifier_components=len(comp),
        selection='One SHA256-selected assay per shared-gene/protein-accession connected component; first64 SHA256-ranked representatives',
        selected_assays=selected,campaign_assignments=assignments,components=sorted([sorted(v) for v in comp.values()]),
        campaigns=16,assays_per_campaign=4,biological_family_independence_certified=False,
        support='Canonical nonstereochemical connectivity SHA256(role|graph) mod5==0; first2048 available distinct graphs by SHA256(cap|graph), without label stratification',
        query='Other graphs; SHA256(owner|graph) mod16 owns one campaign; first4096 per assay by SHA256(cap|graph); known binary activity required, sign not examined in partitioning',
        missing_activity='Missing values are unavailable labels, never negatives; source first valid molecular row per connectivity per assay',
        invalid_structure='Exclude RDKit-invalid SMILES without activity inspection; log source indices',
        binary_activity='Use source 0/1 activity without redefining thresholds or resampling prevalence; no activity-based assay removal',
        support_single_class='Laplace constant (positives+1)/(support+2); never drop assay; no support=0.5',
        representation='Morgan radius2,2048bits,RDKit2023.9.6; no pretrained encoder',
        scorer=dict(name='Morgan2048_RF',n_estimators=256,min_samples_leaf=2,max_features='sqrt',class_weight=None,seed=11,n_jobs=4),
        primary_quota=32,secondary_quotas=[4,8,16,64],
        algorithms=['uniform','global','recycling','shield_global','shield_latent_greedy','latent_greedy','latent_UCB','observed_4'],
        primary_contrasts=['Recovery: recycling minus uniform','Baseline discoveries lost: global minus recycling'],
        primary_analysis='Exact two-sided campaign sign flips on16 fixed campaign differences; Holm across2 contrasts; interpret only conditional on independent sign-symmetric differences; no certified source/family independence',
        secondary_analysis='Shield vs DPQR and all other budgets/controls descriptive; no data-dependent primary replacement',
        uncertainty='Campaign bootstrap descriptive conditional on scores and fixed grouping; no target/molecule/seed pseudo-replication',
        sampling_scope='Label-blind capped subsets of published assay panels; not entire HTS campaigns; assay availability masks may depend on original experiments',
        power='16 constructed campaigns fixed by resource budget; not a guaranteed80% powered design; do not merge/repartition old FS-Mol tests',
        development_shield_results_sha256=sha(H/'results/shield_development.csv'),
        source_sha256={n:sha(H/n) for n in ['shield.py','sparse_protocol.py','sparse_prepare.py','sparse_fit.py','sparse_evaluate.py']},
        labels_read_before_lock=False,query_labels_exported_before_lock=False)
    (H/'new_sparse_protocol.json').write_text(json.dumps(obj,indent=2)+'\n');print('LOCKED',sha(H/'new_sparse_protocol.json'),flush=True)
if __name__=='__main__':main()
