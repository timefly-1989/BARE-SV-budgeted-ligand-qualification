"""Independent CID-based label cross-check, freeze order, policy replay and old guards."""
from pathlib import Path
import datetime,hashlib,json
import numpy as np,pandas as pd
from scipy.stats import binomtest
from shield import simulate
H=Path(__file__).resolve().parent;R=H.parents[1]
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def main():
    p=json.loads((H/'new_sparse_protocol.json').read_text());am=json.loads((H/'source_amendment_before_labels.json').read_text())
    for n,w in p['source_sha256'].items():assert sha(H/n)==am.get('corrected_source_sha256',{}).get(n,w),n
    f=json.loads((H/'sparse_prediction_freeze.json').read_text());e=json.loads((H/'sparse_evaluation_opened.json').read_text())
    assert datetime.datetime.fromisoformat(p['timestamp'])<datetime.datetime.fromisoformat(f['timestamp'])<datetime.datetime.fromisoformat(e['timestamp'])
    assert sha(H/'data/sparse_scores_before_labels.csv')==f['scores_sha256']
    old=json.loads((H/'checks/scientific_guards_before.json').read_text())
    for record in old:assert sha(R/record['path'])==record['sha256'],record['path']
    d=pd.read_csv(H/'data/sparse_partition.csv');q=d[d.role.eq('query')];s=d[d.role.eq('support')]
    assert not set(q.key)&set(s.key);assert q.groupby('key').campaign.nunique().max()==1
    # Independent reader skips blank lines, joins on source PubChem CID rather than CSV row number.
    raw=pd.read_csv(H/'raw/pcba.csv.gz',usecols=p['selected_assays']+['mol_id'],dtype={'mol_id':str})
    assert not raw.mol_id.duplicated().any(),'CID duplication requires explicit cross-check handling'
    raw=raw.set_index('mol_id');checked=0
    for role,name in [('query','sparse_query_labels.csv'),('support','sparse_support_labels.csv')]:
        z=d[d.role.eq(role)].merge(pd.read_csv(H/'data'/name),on=['assay','key'],validate='one_to_one')
        for assay,g in z.groupby('assay'):
            values=raw.loc[g.source_mol_id.astype(str),assay].to_numpy()
            assert np.isfinite(values).all();assert np.array_equal(values.astype(int),g.y.to_numpy(int)),(role,assay)
            checked+=len(g)
    scores=pd.read_csv(H/'data/sparse_scores_before_labels.csv').merge(pd.read_csv(H/'data/sparse_query_labels.csv'),on=['assay','key'],validate='one_to_one')
    expected=pd.read_csv(H/'results/sparse_campaigns.csv');replayed=0
    for cid,g in scores.groupby('campaign',sort=True):
        g=g.sort_values(['assay','key']).reset_index(drop=True)
        for B in [4,8,16,32,64]:
            equivalent=[]
            for algorithm in p['algorithms']:
                res,ix,_=simulate(g.score,g.assay,g.key,g.y,B,algorithm,11)
                r=expected[(expected.campaign==cid)&(expected.B==B)&(expected.algorithm==algorithm)].iloc[0]
                for k in ['K','C','coverage','baseline_coverage','baseline_lost']:assert res[k]==r[k],(cid,B,algorithm,k)
                if algorithm in ['recycling','shield_global']:equivalent.append(set(ix))
                replayed+=1
            assert equivalent[0]==equivalent[1],(cid,B,'static terminal sets differ')
        print('REPLAY',cid,flush=True)
    stats=json.loads((H/'results/sparse_primary_tests.json').read_text());sensitivity=[]
    for test in stats['primary_tests']:
        v=np.array(test['differences']);nonzero=v[v!=0];sensitivity.append(dict(contrast=test['contrast'],two_sided_sign_test=binomtest(int((nonzero>0).sum()),len(nonzero),.5).pvalue))
    out=dict(status='PASS',CID_crosschecked_labels=checked,frozen_sources_checked=len(p['source_sha256']),historical_files_unchanged=len(old),policy_values_replayed=replayed,static_equivalence_cases=80,
        no_support_query_identity_overlap=True,query_campaign_identity_ownership=True,predictions_precede_query_export=True,secondary_sign_test=sensitivity,
        statistical_caveat='Neither exact sign procedure establishes independent biological campaigns; no 80% power claim',chemical_endpoints_added=0)
    (H/'checks/evidence_validation.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
if __name__=='__main__':main()
