"""Partition selected failures into their first failed computational gate."""
from pathlib import Path
import json
import numpy as np,pandas as pd
ROOT=Path(__file__).resolve().parents[3];EX=ROOT/'experiments';cfg=json.loads((ROOT/'project.json').read_text());rows=[];examples=[]
for cohort,sub in [('first48','02_selection48'),('later23','03_confirmation23'),('fresh16','05_fresh16')]:
 d=EX/sub/'data'
 if not (d/'outcomes.csv').exists():continue
 p=pd.read_csv(d/'proposed_predictions.csv');o=pd.read_csv(d/'outcomes.csv');frame=p.merge(o,on=['pocket_id','candidate_id'],validate='one_to_one')
 for pid,g in frame.groupby('pocket_id',sort=False):
  ix=np.lexsort((g.candidate_id.to_numpy(str),-g.score.to_numpy()));selected=g.iloc[ix[:32]]
  for r in selected.itertuples():
   stage='qualified' if r.y else 'route' if not r.D else 'pose' if not r.V else 'score'
   rows.append(dict(cohort=cohort,pocket_id=pid,candidate_id=r.candidate_id,stage=stage,score=r.score,D=r.D,V=r.V,Q=r.Q,y=r.y))
 out=EX/'04_completion/results';pd.DataFrame(rows).groupby(['cohort','stage']).size().rename('selected_count').reset_index().to_csv(out/'selected_failure_partition.csv',index=False)
 pd.DataFrame(rows).to_csv(out/'selected_failure_records.csv',index=False)
print('ERROR_PARTITION_COMPLETE',cfg['name'])
