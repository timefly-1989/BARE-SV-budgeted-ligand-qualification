"""Reproduce this paper's frozen multiplicity correction from its local register."""
from pathlib import Path
import json
import numpy as np,pandas as pd
P=Path(__file__).resolve().parents[3];R=P/'experiments/04_completion/results'
family=json.loads((P/'experiments/00_protocol/joint_test_family.json').read_text())
x=pd.read_csv(R/'fresh_tests_nine.csv');indices=family['displayed_indices'];raw=np.asarray(family['raw_p_values'],float)
assert len(x)==len(indices)==13 and len(raw)==26
assert np.allclose(x.p_raw.to_numpy(),raw[indices],rtol=0,atol=1e-12), 'Current tests differ from the frozen family; revise provenance rather than silently changing the correction.'
order=np.argsort(raw);adj=np.empty(len(raw));previous=0
for rank,index in enumerate(order):
 previous=max(previous,min(1,(len(raw)-rank)*raw[index]));adj[index]=previous
x['p_holm_joint26']=adj[indices]
x.to_csv(R/'fresh_tests_joint26.csv',index=False);x.to_csv(R/'fresh_tests_13.csv',index=False)
print('FROZEN_FAMILY_CORRECTION_PASS')
