"""Cross-check raw PoseBusters columns, scoring logs and candidate identities locally."""
from pathlib import Path
import json,sys,hashlib
import pandas as pd
from rdkit import Chem
P=Path(__file__).resolve().parents[3];E=P/'experiments';F=E/'05_fresh16';sys.path.insert(0,str(E/'verification_code'));import verify_chemistry as vc
out=pd.read_csv(F/'data/outcomes.csv');cand=pd.read_csv(F/'data/fresh_candidates.csv');df=out.merge(cand,on=['pocket_id','candidate_id'],validate='one_to_one');n=fields=stereo_inferred=0
for r in df.itertuples():
 d=F/'chemistry/records'/r.pocket_id/r.candidate_id
 original=Chem.SDMolSupplier(str(F/'chemistry/pools'/r.pocket_id/(r.candidate_id+'.sdf')),removeHs=False)[0]
 declared=Chem.MolFromSmiles(r.smiles);sdf=Chem.RemoveHs(original)
 assert Chem.MolToSmiles(sdf,isomericSmiles=False)==Chem.MolToSmiles(declared,isomericSmiles=False)
 if vc.canonical(Chem.MolToSmiles(sdf))!=vc.canonical(r.smiles):
  assert all(a.GetChiralTag()==Chem.ChiralType.CHI_UNSPECIFIED for a in declared.GetAtoms())
  assert all(b.GetStereo()==Chem.BondStereo.STEREONONE for b in declared.GetBonds())
  stereo_inferred+=1
 route=json.loads((d/'route.json').read_text());assert route['D']==r.D
 if not r.D:assert r.y==0 and pd.isna(r.V) and pd.isna(r.Q);continue
 assert vc.canonical(route['route']['smiles'])==vc.canonical(r.smiles)
 dock=json.loads((d/'docking.json').read_text());assert (dock['V'],dock['Q'],r.y)==(r.V,r.Q,r.D*r.V*r.Q)
 if not dock['dock_success']:continue
 b=pd.read_csv(d/'posebusters.csv');assert len(b)==1
 assert len(dock['pose_checks'])==20
 for key,value in dock['pose_checks'].items():
  assert key in b.columns
  actual=bool(pd.notna(b.iloc[0][key]) and b.iloc[0][key]==True)
  assert actual==value,(r.pocket_id,r.candidate_id,key)
  fields+=1
 assert vc.score_from_stdout((d/'vina.log').read_text())==dock['redocked_score'];n+=1
report={'status':'PASS','rows':len(df),'input_connectivity_checks':len(df),'unspecified_declared_stereo_with_3D_assignments':stereo_inferred,'explicit_stereo_conflicts':0,'route_target_scope':'Archived declared SMILES; no guarantee of stereospecific synthesis of the SDF-assigned pose','successful_docking_records':n,'raw_pose_csv_field_checks':fields,'scope':'Fresh records only; historical route corrections retained separately','outcomes_sha256':hashlib.sha256((F/'data/outcomes.csv').read_bytes()).hexdigest()}
(E/'06_reporting/raw_record_audit.json').write_text(json.dumps(report,indent=2));print('RAW_RECORD_AUDIT_PASS',report)
