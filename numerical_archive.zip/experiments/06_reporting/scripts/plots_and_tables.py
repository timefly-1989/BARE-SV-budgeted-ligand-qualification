"""Scientific vector figures and source-linked tables for a standalone paper."""
from pathlib import Path
import sys
import json,re
import numpy as np,pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
PROJECT=Path(__file__).resolve().parents[3];EX=PROJECT/'experiments';R=EX/'04_completion/results';T=PROJECT/'tables';F=PROJECT/'figures';CFG=json.loads((PROJECT/'project.json').read_text());PROP=CFG['method_display']
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':8.5,'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42,'axes.titleweight':'bold','axes.labelsize':8.5,'xtick.labelsize':7.5,'ytick.labelsize':7.5,'legend.fontsize':7.5,'savefig.bbox':'tight'})
ACCENT='#176b78';COLORS=['#176b78','#c98538','#5b6cb2','#ad5865','#52774e','#7d65a5','#707070']
SHORT={PROP:'Proposed','SA greedy':'SA','Joint classifier (refit)':'Joint refit','Joint classifier (older fit)':'Joint older','TabPFN selected policy':'TabPFN policy','Best static policy':'Best static','TabICLv2 base':'TabICLv2 base','BCE MLP selected policy':'BCE MLP','Budget-ramp ranker':'Budget ramp','Nonbudget RRF':'RRF','CatBoost direct279':'CatBoost279','TabICLv2 direct55':'TabICLv2-55','Random Forest279':'RF279','Extra Trees279':'ExtraTrees279','SA ranking':'SA ranking','Joint policy':'Joint policy','BCE MLP policy':'BCE MLP policy'}

def esc(x):return str(x).replace('_',r'\_').replace('%',r'\%').replace('&',r'\&')

def prose(text):
 saved={}
 def hold(m):
  key='ZZZKEEP'+chr(65+len(saved))+'ZZZ';saved[key]=m.group(0);return key
 text=re.sub(r'\\(?:ref|label|cite|input|texttt)\{[^{}]*\}|TabICLv[12]|F1',hold,text)
 text=re.sub(r'(?<=[A-Za-z])(?=\d)|(?<=\d)(?=[A-Za-z])',' ',text)
 for key,value in saved.items():text=text.replace(key,value)
 return text

def table(name,heads,rows,caption,note=''):
 caption=prose(caption);note=prose(note);heads=[prose(h) for h in heads];rows=[[('--' if str(v)=='nan' else v) for v in row] for row in rows]
 spec='Y'+'r'*(len(heads)-1)
 lines=[r'\par',r'\begin{table}[htbp]\centering\small',r'\setlength{\tabcolsep}{3.5pt}',r'\caption{'+caption+'}'+r'\label{tab:'+name+'}',r'\begin{tabularx}{\linewidth}{'+spec+'}',r'\toprule',' & '.join(heads)+r'\\',r'\midrule']
 lines+=[' & '.join(map(str,row))+r'\\' for row in rows];lines += [r'\bottomrule\end{tabularx}']
 if note:lines += [r'\par\medskip\begin{minipage}{.98\linewidth}\footnotesize '+note+r'\end{minipage}']
 lines += [r'\end{table}',r'\par'];(T/(name+'.tex')).write_text('\n'.join(lines)+'\n')
def save(fig,name):
 fig.savefig(F/(name+'.pdf'));fig.savefig(F/(name+'.png'),dpi=180);plt.close(fig)

def main():
 sys.path.insert(0, str(PROJECT/'scripts'))
 from polish_experiment_figures import plot_ablation, plot_reliability, write_ablation_table
 summary=pd.read_csv(R/'budget_summary.csv');raw=pd.read_csv(R/'all_budget_per_pocket.csv');cohorts=list(summary.cohort.unique());titles={'first48':'Selection: 48 pockets','later23':'Frozen: 23 pockets','fresh16':'New: 16 pockets'}
 shown=[PROP,'SA greedy','Joint classifier (refit)','Budget-ramp ranker','TabICLv2 direct55','Random Forest279','Extra Trees279']
 fig,axes=plt.subplots(1,len(cohorts),figsize=(6.5,3.1),squeeze=False)
 for ax,cohort in zip(axes[0],cohorts):
  for color,method in zip(COLORS,shown):
   q=summary[(summary.cohort==cohort)&(summary.method==method)].sort_values('budget');ax.plot(np.r_[0,q.budget],np.r_[0,q.mean_C],label=SHORT[method],color=color,lw=2 if method==PROP else 1,ls='-' if method==PROP else '--',zorder=5 if method==PROP else 3)
  z=raw[(raw.cohort==cohort)&(raw.method==PROP)];oracle=z.groupby('budget').ceiling.mean();uniform=z.assign(uniform=z.budget*z.pool_positives/z.pool_size).groupby('budget').uniform.mean();ax.plot(oracle.index,oracle.to_numpy(),color='#20262b',lw=.8,ls=':',label='Observed ceiling');ax.plot(uniform.index,uniform.to_numpy(),color='#a5adb1',lw=.8,ls='-.',label='Uniform expectation');ax.set_title(titles[cohort],fontsize=8.5);ax.set_xlim(0,40);ax.set_ylim(bottom=0);ax.set_xticks([0,16,32,40]);ax.axvline(32,color='#d0d4d6',lw=.7,zorder=0);ax.set_xlabel('Candidate budget B')
 axes[0,0].set_ylabel('Mean qualified recovery');handles,labels=axes[0,0].get_legend_handles_labels();fig.legend(handles,labels,loc='lower center',ncol=3,frameon=False,bbox_to_anchor=(.5,-.04));fig.subplots_adjust(left=.09,right=.99,top=.85,bottom=.32,wspace=.33);save(fig,'completion_budget_curves')
 plot_ablation()
 latency=pd.read_csv(R/'latency_summary.csv');order=latency.sort_values('median');fig,ax=plt.subplots(figsize=(6.3,2.65));yy=np.arange(len(order));ax.errorbar(order['median'],yy,xerr=np.vstack([order['median']-order.q25,order.q75-order['median']]),fmt='o',color=ACCENT,capsize=3,ms=4);ax.set_yticks(yy,[SHORT.get(x,x) for x in order.method]);ax.invert_yaxis();ax.set_xscale('log');ax.set_xlabel('Context + prediction time (s, logarithmic axis)');ax.grid(axis='x',color='#e3e6e8',lw=.5);fig.subplots_adjust(left=.25,right=.97,bottom=.22,top=.98);save(fig,'completion_latency')
 plot_reliability()
 audit=pd.read_csv(R/'cohort_audit.csv');table('completion_cohorts',['Cohort','Pockets','Candidates','Route +','Joint +','Positive pools'],[[titles[r.cohort],r.pockets,r.rows,r.D,r.positives,r.positive_pockets] for r in audit.itertuples()],'Chronological evaluation cohorts and observed computational qualification.','Development remains the original84 pockets/4,647 fitting rows. The new cohort uses80--98 candidates per pool and is not pooled with the old64-candidate cohorts.')
 hist=summary[summary.budget.eq(32)&summary.cohort.isin(['first48','later23'])]
 historical=[]
 for method in [PROP]+[x for x in summary.method.unique() if x!=PROP]:
  first=hist[(hist.cohort=='first48')&hist.method.eq(method)].iloc[0];later=hist[(hist.cohort=='later23')&hist.method.eq(method)].iloc[0]
  historical.append([SHORT[method],int(first.total_C),f'{first.recall:.4f}',int(later.total_C),f'{later.recall:.4f}'])
 table('completion_historical_controls',['Policy',r'48: $C_{32}$','48: recall',r'23: $C_{32}$','23: recall'],historical,'Expanded historical main-budget comparison with four added fixed controls.','The original nine policies retain their recorded roles; newly added controls on these exposed cohorts are retrospective diagnostics. Macro recall is defined over positive pools. Neither column is another blind confirmation.')
 if 'fresh16' in cohorts:
  x=summary[(summary.cohort=='fresh16')&summary.budget.eq(32)].set_index('method');rows=[]
  for method in [PROP]+[x for x in summary.method.unique() if x!=PROP]:
   r=x.loc[method];c8=summary[(summary.cohort=='fresh16')&(summary.method==method)&summary.budget.eq(8)].total_C.iloc[0];c16=summary[(summary.cohort=='fresh16')&(summary.method==method)&summary.budget.eq(16)].total_C.iloc[0];rows.append([SHORT[method],round(c8),round(c16),round(r.total_C),f'{r.recall:.4f}',f'{r.f1:.4f}'])
  table('completion_fresh',['Policy','$C_8$','$C_{16}$','$C_{32}$','Macro recall',r'Macro $F_1$'],rows,'Prospectively frozen comparison on16 new, chemically blocked pockets.','Totals are integer observed-label recoveries. All13 controls share the same1,428 endpoint records and distinct-candidate budgets; zero-positive pools are retained for recovery/F1; macro recall averages positive pools only. Recall and F1 use budget 32.')
  tests=pd.read_csv(R/'fresh_tests_joint26.csv');table('completion_fresh_tests',['Control',r'$\Delta\overline C_{32}$',r'95\% paired CI','Joint Holm p','W/T/L'],[[SHORT[r.control],f'{r.difference:+.4f}',f'[{r.ci_low:+.4f}, {r.ci_high:+.4f}]',f'{r.p_holm_joint26:.4f}',f'{r.wins}/{r.ties}/{r.losses}'] for r in tests.itertuples()],'Prespecified fresh-cohort paired contrasts for this manuscript.','Holm correction uses the full26-contrast frozen family; the13 contrasts of this manuscript are displayed. Bootstrap intervals use10,000 pocket resamples and do not replace the corrected decision rule.')
 write_ablation_table()
 seed=pd.read_csv(R/'seed_summary.csv');rows=[]
 for c in cohorts:
  z=seed[(seed.cohort==c)&seed.budget.eq(32)];rows.append([titles[c]]+[str(round(z[z.seed==s].total_C.iloc[0])) for s in [11,23,37]]+[f'{z.total_C.std(ddof=1):.3f}'])
 table('completion_seeds',['Cohort','Seed11','Seed23','Seed37','SD(total)'],rows,'Foundation-view seed stability at budget32.','Only transformed-context ensemble seeds vary; pretrained weights, data, tree fits and mixture coefficients remain fixed. Three seeds measure local transformation sensitivity, not uncertainty across independent foundation pretraining runs.')
 rows=[[SHORT.get(r.method,r.method),str(int(r.count)),f'{r.median:.5f}',f'[{r.q25:.5f}, {r.q75:.5f}]'] for r in latency.itertuples()];table('completion_latency',['Scorer','Repeats','Median s','Interquartile s'],rows,'Repeated local scoring costs on the same1,472-candidate batch.','One warmup precedes10 randomized-order repetitions. MPS calls synchronize. PyTorch CPU threads=4; foundation devices and all trained coefficients remain fixed. Common feature computation and chemical verification are excluded; SA is a sort of existing heuristic values. Deserialization/context fitting is included, and prediction-cache shortcuts are disabled.')
 scores=pd.read_csv(R/'scoring_metrics.csv');rows=[]
 for c in cohorts:
  for r in scores[scores.cohort==c].itertuples():rows.append([SHORT[r.method],c,f'{r.AUC:.4f}',f'{r.AP:.4f}',('--' if pd.isna(r.Brier) else f'{r.Brier:.4f}')])
 # Split into separate tables to avoid a long floating table over one page.
 for c in cohorts:
  table('completion_scoring_'+c,['Policy','Micro AUC','Micro AP','Brier'],[[SHORT[r.method],f'{r.AUC:.4f}',f'{r.AP:.4f}',('--' if pd.isna(r.Brier) else f'{r.Brier:.4f}')] for r in scores[scores.cohort==c].itertuples()],f'Candidate-level scoring diagnostics: {titles[c]}.','AUC/AP pool all candidates and are descriptive. Brier evaluates a bounded joint utility against computed qualification; rank-only SA/RRF utilities have no Brier entry. These are not laboratory-success probabilities.')
 errors=R/'selected_failure_partition.csv'
 if errors.exists():
  counts=pd.read_csv(errors).pivot(index='cohort',columns='stage',values='selected_count').fillna(0)
  table('completion_errors',['Cohort','Route fail','Pose fail','Score fail','Qualified'],[[titles[c]]+[int(counts.loc[c].get(stage,0)) for stage in ['route','pose','score','qualified']] for c in cohorts],'First failed qualification gate among candidates selected at budget 32.','Stages are mutually exclusive: route failure is assigned first, then pose failure, then score failure. Unobserved standalone pose/score labels following route failure are not imputed. Each cohort retains all pockets and exactly 32 selected candidates per pocket.')
 print('PLOTS_TABLES_COMPLETE',CFG['name'],cohorts,flush=True)
if __name__=='__main__':main()
