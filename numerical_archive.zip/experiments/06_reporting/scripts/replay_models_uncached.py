"""Verify frozen predictions with model inference and no score-cache shortcuts."""
from pathlib import Path
import runpy,sys,json,hashlib
P=Path(__file__).resolve().parents[3];E=P/'experiments'
sys.path.insert(0,str(E/'04_completion/scripts'))
import model_utils as mu
original=mu.foundation
def uncached(*args,**kwargs):
 kwargs['cache']=False
 return original(*args,**kwargs)
mu.foundation=uncached
runpy.run_path(str(E/'05_fresh16/scripts/predict_local.py'),run_name='__main__')
r=E/'05_fresh16/results/prediction_replay.json';x=json.loads(r.read_text());x['foundation_cache_disabled']=True;x['frozen_policy_sha256']=hashlib.sha256((E/'05_fresh16/frozen_policy.json').read_bytes()).hexdigest();x['scope']='All 13 controls and the unchanged proposed score; fixed labels/context only'
r.write_text(json.dumps(x,indent=2));print('UNCACHED_FROZEN_REPLAY_PASS')
