"""Local frozen-context inference utilities; no holdout labels used for fitting."""
import os
for k in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','VECLIB_MAXIMUM_THREADS']:os.environ[k]='1'
os.environ['TABPFN_DISABLE_TELEMETRY']='1';os.environ['HF_HUB_DISABLE_TELEMETRY']='1';os.environ['TABPFN_ALLOW_CPU_LARGE_DATASET']='1'
from pathlib import Path
import json,gc,time,hashlib
import numpy as np,pandas as pd,torch,joblib
from scipy.special import expit
from catboost import CatBoostClassifier
from tabicl import TabICLClassifier
from tabpfn import TabPFNClassifier
from torch import nn
BASE=['sa_score','rd_HeavyAtomCount','rd_MolWt','rd_MolLogP','rd_TPSA','rd_NumHDonors','rd_NumHAcceptors','rd_NumRotatableBonds','rd_RingCount','rd_FractionCSP3','rd_NumHeteroatoms','native_raw_margin','size_ratio','pose_feature_missing','reference_success','minimum_nonbonded_distance','raw_clash_fraction']
EXTRA=['raw_score_only','protein_min_distance','protein_mean_distance','protein_clash_fraction','protein_contact_fraction','native_sa','native_heavy_atoms','native_logP','box_volume','vina_intermolecular','vina_internal','vina_torsional']
DEVICE='mps';torch.set_num_threads(4)
def sync():torch.mps.synchronize()
def cleanup():gc.collect();torch.mps.empty_cache()
def clean(df,names):return np.clip(np.nan_to_num(df[names].to_numpy(float),nan=0,posinf=0,neginf=0),-1e6,1e6)
class Prior(nn.Module):
 def __init__(self):super().__init__();self.net=nn.Sequential(nn.Linear(2056,256),nn.ReLU(),nn.Dropout(.1),nn.Linear(256,128),nn.ReLU(),nn.Dropout(.1),nn.Linear(128,1))
 def forward(self,x):return self.net(x).squeeze(-1)
class Scorer(nn.Module):
 def __init__(self,n):super().__init__();self.net=nn.Sequential(nn.Linear(n,128),nn.ReLU(),nn.Dropout(.2),nn.Linear(128,64),nn.ReLU(),nn.Dropout(.2),nn.Linear(64,1))
 def forward(self,x):return self.net(x).squeeze(-1)
def prior(project,df,fp):
 path=project/'experiments/01_development84/prior';stats=np.load(path/'historical_features.npz');x=np.c_[fp,df[['rd_MolWt','rd_MolLogP','rd_TPSA','rd_NumHDonors','rd_NumHAcceptors','rd_NumRotatableBonds','rd_RingCount','rd_FractionCSP3']].to_numpy(np.float32)];x[:,-8:]=(x[:,-8:]-stats['descriptor_mean'])/stats['descriptor_std'];vals=[]
 for seed in [11,23,37]:
  m=Prior().to(DEVICE);m.load_state_dict(torch.load(path/f'prior_{seed}.pt',map_location=DEVICE,weights_only=True));m.eval()
  with torch.no_grad():vals.append(torch.sigmoid(m(torch.tensor(x,dtype=torch.float32,device=DEVICE))).cpu().numpy())
 return np.c_[np.mean(vals,axis=0),np.std(vals,axis=0)]
def matrices(project,df,fp,pp=None):
 pre=joblib.load(project/'experiments/01_development84/models/full/preprocessing.joblib');x=clean(df,pre['names']);emb=pre['svd'].transform(fp);pp=prior(project,df,fp) if pp is None else pp
 return dict(base=x[:,:17],small=np.c_[x[:,:29],emb[:,:24],pp],large=np.c_[x,emb,pp],prior=pp)
def foundation(project,tag,Q,columns=None,seed=11,cache=True):
 root=project/'experiments';candidates=[root/'01_development84/models/full'/f'{tag}_context.joblib',root/'baseline_models/current84'/f'{tag}_context.joblib'];ctx=joblib.load(next(p for p in candidates if p.exists()));params=dict(ctx['constructor_params']);X=ctx['X']
 if columns is not None:X=X[:,columns];Q=Q[:,columns]
 cachepath=root/'04_completion/cache';cachepath.mkdir(exist_ok=True)
 key=hashlib.sha256(tag.encode()+str(seed).encode()+X.tobytes()+Q.tobytes()).hexdigest()
 dest=cachepath/(key+'.npy')
 if cache and dest.exists():return np.load(dest)
 if tag.startswith('tabicl'):
  params.update(random_state=seed,allow_auto_download=False,model_path=str(root/'pretrained'/params['checkpoint_version']));net=TabICLClassifier(**params)
 else:
  params['model_path']=str(next((root/'pretrained').glob('tabpfn*.ckpt')));net=TabPFNClassifier(**params)
 net.fit(X,ctx['y']);v=net.predict_proba(Q)[:,1];sync();del net;cleanup();
 if cache:np.save(dest,v)
 return v

def cat(project,tag,Q,older=False):
 p=project/'experiments/baseline_models'/('older_joint' if older else 'current84');vals=[]
 for seed in ([11,23,37] if older else [11,23]):
  m=CatBoostClassifier();m.load_model(str(p/f'{tag}_{seed}.cbm'));vals.append(m.predict_proba(Q)[:,1])
 return np.mean(vals,axis=0)
def tree_file(path,Q):
 m=joblib.load(path);s=sum(m['learning_rate']*t.predict(Q) for t in m['trees']);return m['calibrator'].predict_proba(s[:,None])[:,1]
def tree(project,Q):
 return np.mean([tree_file(project/'experiments/01_development84/models/full'/f'bce_tree_{s}.joblib',Q) for s in [11,23]],axis=0)
def sa(project,Q,older=False):
 p=project/'experiments/baseline_models'/('older_joint' if older else 'current84');m=joblib.load(p/'sa.joblib');sc=m.named_steps['standardscaler'];lr=m.named_steps['logisticregression'];return expit(((Q[:,:1]-sc.mean_)/sc.scale_)@lr.coef_.T+lr.intercept_).ravel()
def mlp(project,Q):
 p=project/'experiments/baseline_models/current84';z=joblib.load(p/'rank_scaler.joblib').transform(Q).astype(np.float32);v=[]
 for seed in [11,23]:
  m=Scorer(Q.shape[1]).to(DEVICE);m.load_state_dict(torch.load(p/f'bce_{seed}_epoch40.pt',map_location=DEVICE,weights_only=True));m.eval()
  with torch.no_grad():s=m(torch.tensor(z,device=DEVICE)).cpu().numpy()
  v.append(joblib.load(p/f'bce_{seed}_epoch40.calibration.joblib').predict_proba(s[:,None])[:,1])
 return np.mean(v,axis=0)
def all_scores(project,df,M,kind,seed=11):
 mask=df.reference_success.to_numpy();small=M['small'];large=M['large'];base=M['base'];r={}
 r['p_sa']=sa(project,base)*mask;r['p_direct']=cat(project,'direct',base)*mask;r['p_conditional']=cat(project,'conditional_D',large)*cat(project,'conditional_VQ',large)*mask
 r['p_bce40']=mlp(project,large)*mask
 r['p_boost5_100']=np.mean([tree_file(project/'experiments/baseline_models/current84'/f'boost5_{s}_iter100.joblib',large) for s in [11,23]],axis=0)*mask
 r['p_tabicl_v2_base']=foundation(project,'tabicl_v2_base',base)*mask;r['p_tabpfn_aug']=foundation(project,'tabpfn_aug',small)*mask
 rd=foundation(project,'tabicl_v2_route_aug',small,seed=seed) if kind=='conditional' else None
 if kind=='feature':
  # Foundation contexts for this baseline are read from the paper's own baseline bank.
  rd=foundation(project,'tabicl_v2_route_aug',small)
 rv=foundation(project,'tabicl_v2_VQconditional_aug',small,seed=seed if kind=='conditional' else 11)
 r['p_conditional_foundation']=rd*rv*mask
 if kind=='feature':r['p_proposed']=foundation(project,'tabicl_v1_aug',small,seed=seed)*mask
 else:r['p_tree_bce']=tree(project,large)*mask;r['p_proposed']=.25*r['p_tree_bce']+.75*r['p_conditional_foundation'];r['raw_route_probability']=rd;r['raw_pose_probability']=rv
 r['Joint classifier (refit)']=.5*r['p_direct']+.5*r['p_sa'];r['Joint classifier (older fit)']=.5*(cat(project,'direct',base,True)+sa(project,base,True))*mask
 r['TabPFN selected policy']=.5*r['p_tabpfn_aug']+.5*r['p_sa'];r['Best static policy']=r['TabPFN selected policy'];r['TabICLv2 base']=r['p_tabicl_v2_base'];r['BCE MLP selected policy']=.25*r['p_bce40']+.75*r['p_sa'];r['Budget-ramp ranker']=.25*r['p_boost5_100']+.75*r['p_conditional_foundation'];r['SA greedy']=-df.sa_score.to_numpy();rrf=np.zeros(len(df))
 for pid,ix in df.groupby('pocket_id',sort=False).indices.items():
  ids=df.iloc[ix].candidate_id.to_numpy(str)
  for tag,w in [('p_conditional',.25),('p_sa',.25),('p_tabpfn_aug',.5)]:
   order=np.lexsort((ids,-r[tag][ix]));ranks=np.empty(len(ix),int);ranks[order]=np.arange(1,len(ix)+1);rrf[ix]+=w/(60+ranks)
 r['Nonbudget RRF']=rrf*mask;return r
