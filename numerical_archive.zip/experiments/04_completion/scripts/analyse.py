"""Project-local analysis of common endpoints, frozen controls and new diagnostics."""
from pathlib import Path
import json,hashlib,itertools
import numpy as np,pandas as pd
from sklearn.metrics import roc_auc_score,average_precision_score,brier_score_loss
PROJECT=Path(__file__).resolve().parents[3];EX=PROJECT/'experiments';HERE=EX/'04_completion';OUT=HERE/'results';OUT.mkdir(exist_ok=True)
CONTROL=['SA greedy','Joint classifier (refit)','Joint classifier (older fit)','TabPFN selected policy','TabICLv2 base','BCE MLP selected policy','Best static policy','Budget-ramp ranker','Nonbudget RRF','CatBoost direct279','TabICLv2 direct55','Random Forest279','Extra Trees279']
CFG=json.loads((PROJECT/'project.json').read_text());PROP=CFG['method_display']

def baseline_scores(df):
 r={n:df['control_'+key].to_numpy() for n,key in [('Joint classifier (refit)','Joint greedy'),('Joint classifier (older fit)','Prior-frozen Joint greedy'),('TabPFN selected policy','TabPFN greedy'),('BCE MLP selected policy','BCE MLP greedy'),('Best static policy','Best static classifier')]}
 r['SA greedy']=-df.sa_score.to_numpy();r['TabICLv2 base']=df.p_tabicl_v2_base.to_numpy()
 # The original selected budget-ramp comparator needs a conditional foundation term.
 return r

def rank_metrics(df,scores,cohort,budgets=range(1,41)):
 rows=[]
 for pid,ix in df.groupby('pocket_id',sort=False).indices.items():
  g=df.iloc[ix];ids=g.candidate_id.to_numpy(str);y=g.y.to_numpy();P=int(y.sum())
  for method,values in scores.items():
   order=np.lexsort((ids,-np.asarray(values)[ix]));cum=np.cumsum(y[order])
   for B in budgets:
    if B>len(g):continue
    C=float(cum[B-1]);rows.append(dict(cohort=cohort,pocket_id=pid,method=method,budget=B,pool_size=len(g),pool_positives=P,C=C,precision=C/B,recall=C/P if P else np.nan,f1=2*C/(B+P),ceiling=min(B,P)))
 return pd.DataFrame(rows)

def paired(df,a,b,cohort,B=32):
 p=df[(df.cohort==cohort)&(df.budget==B)].pivot(index='pocket_id',columns='method',values='C');d=(p[a]-p[b]).to_numpy();z=d[abs(d)>1e-12];observed=abs(d.sum());sums=np.array([0.])
 for v in z:sums=np.r_[sums+v,sums-v]
 raw=float(np.mean(abs(sums)>=observed-1e-12))
 rng=np.random.default_rng(20261007);boot=d[rng.integers(0,len(d),(10000,len(d)))].mean(1);lo,hi=np.quantile(boot,[.025,.975])
 return dict(cohort=cohort,control=b,difference=float(d.mean()),ci_low=float(lo),ci_high=float(hi),p_raw=raw,wins=int(sum(d>0)),ties=int(sum(d==0)),losses=int(sum(d<0)))

def holm(rows):
 last=0;order=np.argsort([r['p_raw'] for r in rows]);n=len(rows)
 for j,i in enumerate(order):last=max(last,min(1,(n-j)*rows[i]['p_raw']));rows[i]['p_holm']=last

def main():
 allrows=[];cal=[];frames={};component_rows=[];seed_rows=[];catalog=[]
 for cohort,sub in [('first48','02_selection48'),('later23','03_confirmation23'),('fresh16','05_fresh16')]:
  path=EX/sub/'data'
  if not (path/'outcomes.csv').exists():continue
  out=pd.read_csv(path/'outcomes.csv');keys=['pocket_id','candidate_id']
  if cohort=='fresh16':
   pred=pd.read_csv(path/'frozen_predictions.csv');df=pred.merge(out,on=keys,validate='one_to_one');scores={PROP:df.p_proposed.to_numpy()};scores.update({n:df[n].to_numpy() for n in CONTROL})
   df[keys+['p_proposed']].rename(columns={'p_proposed':'score'}).to_csv(path/'proposed_predictions.csv',index=False);df[keys+CONTROL].to_csv(path/'baseline_policy_scores.csv',index=False)
  else:
   pred=pd.read_csv(path/'baseline_predictions.csv');own=pd.read_csv(path/'proposed_predictions.csv');df=pred.merge(own[keys+['score']],on=keys,validate='one_to_one').merge(out,on=keys,validate='one_to_one');scores=baseline_scores(df);scores[PROP]=df.score.to_numpy()
   # Save controls as their actual archived policy scores, using independent local replay inputs.
   legacy=pd.read_csv(PROJECT/'replay'/f'{cohort}_inputs.csv');legacy=legacy.merge(df[keys],on=keys,validate='one_to_one')
   # Conditional component scores were computed without labels in the new diagnostics.
   ab=pd.read_csv(HERE/'data'/f'{cohort}_ablation_predictions.csv') if (HERE/'data'/f'{cohort}_ablation_predictions.csv').exists() else None
   if 'p_conditional_foundation' in legacy:cond=legacy.p_conditional_foundation.to_numpy()
   elif ab is not None and 'conditional_only' in ab:
    cond=df[keys].merge(ab[keys+['conditional_only']],on=keys,validate='one_to_one').conditional_only.to_numpy()
   else:
    extra=pd.read_csv(path/'conditional_baseline_component.csv');cond=df[keys].merge(extra,on=keys,validate='one_to_one').score.to_numpy()
   scores['Budget-ramp ranker']=.25*df.p_boost5_100.to_numpy()+.75*cond
   rrf=np.zeros(len(df))
   for pid,ix in df.groupby('pocket_id',sort=False).indices.items():
    ids=df.iloc[ix].candidate_id.to_numpy(str)
    for col,w in [('p_conditional',.25),('p_sa',.25),('p_tabpfn_aug',.5)]:
     order=np.lexsort((ids,-df.iloc[ix][col].to_numpy()));rank=np.empty(len(ix),int);rank[order]=np.arange(1,len(ix)+1);rrf[ix]+=w/(60+rank)
   scores['Nonbudget RRF']=rrf*df.reference_success.to_numpy()
   extra=pd.read_csv(path/'additional_baseline_predictions.csv');extra=df[keys].merge(extra,on=keys,validate='one_to_one')
   for n in CONTROL[-4:]:scores[n]=extra[n].to_numpy()
   policy=df[keys].copy()
   for n,a in scores.items():
    if n!=PROP:policy[n]=a
   policy.to_csv(path/'baseline_policy_scores.csv',index=False)
  frames[cohort]=df;metrics=rank_metrics(df,scores,cohort);allrows.append(metrics)
  # Validate exact retrieval totals against the former manuscript's local records.
  if cohort!='fresh16':
   old=pd.read_csv(PROJECT/'evidence/per_pocket_metrics.csv');old=old[(old.cohort==cohort)&old.budget.eq(32)];new=metrics[metrics.budget.eq(32)&metrics.method.isin([PROP]+CONTROL[:-4])].merge(old,on=['cohort','pocket_id','method','budget'],suffixes=('_new','_old'),validate='one_to_one');assert len(new)==df.pocket_id.nunique()*10 and np.allclose(new.C_new,new.C_old)
  for n,v in scores.items():
   y=df.y.to_numpy();auc=roc_auc_score(y,v) if len(set(y))>1 else np.nan;ap=average_precision_score(y,v) if sum(y)>0 else np.nan;prob=(n not in ['SA greedy','Nonbudget RRF'])
   cal.append(dict(cohort=cohort,method=n,AUC=auc,AP=ap,Brier=brier_score_loss(y,np.clip(v,0,1)) if prob else np.nan,probability_scope='bounded joint utility; no calibrated-laboratory-success claim' if prob else 'rank-only'))
   if n==PROP:
    bins=np.minimum((np.clip(v,0,1)*10).astype(int),9);r=[]
    for b in range(10):
     m=bins==b
     if m.any():r.append(dict(bin=b,count=int(sum(m)),mean_score=float(np.mean(v[m])),observed_rate=float(np.mean(y[m]))))
    pd.DataFrame(r).to_csv(OUT/f'{cohort}_reliability.csv',index=False)
  abfile=HERE/'data'/f'{cohort}_ablation_predictions.csv'
  if abfile.exists():
   ab=pd.read_csv(abfile);d=df[keys+['y']].merge(ab,on=keys,validate='one_to_one');tags=[n for n in ab if n not in keys and not n.startswith('raw_')];abm=rank_metrics(d,{tag:d[tag].to_numpy() for tag in tags},cohort);component_rows.append(abm)
  for seed in [11,23,37]:
   f=HERE/'data'/f'{cohort}_seed{seed}.csv'
   if not f.exists():continue
   s=pd.read_csv(f);d=df[keys+['y']].merge(s,on=keys,validate='one_to_one');sm=rank_metrics(d,{str(seed):d.score.to_numpy()},cohort,budgets=[8,16,32]);sm['seed']=seed;seed_rows.append(sm)
  catalog.append(dict(cohort=cohort,pockets=df.pocket_id.nunique(),rows=len(df),D=int(df.D.sum()),positives=int(df.y.sum()),positive_pockets=int(df.groupby('pocket_id').y.sum().gt(0).sum()),pool_size_min=int(df.groupby('pocket_id').size().min()),pool_size_max=int(df.groupby('pocket_id').size().max()),C32_ceiling=float(metrics[(metrics.method==PROP)&metrics.budget.eq(32)].ceiling.sum())))
 pd.DataFrame(catalog).to_csv(OUT/'cohort_audit.csv',index=False);full=pd.concat(allrows,ignore_index=True);full.to_csv(OUT/'all_budget_per_pocket.csv',index=False)
 summary=full.groupby(['cohort','method','budget'],sort=False).agg(total_C=('C','sum'),mean_C=('C','mean'),precision=('precision','mean'),recall=('recall','mean'),f1=('f1','mean'),ceiling=('ceiling','sum')).reset_index();summary.to_csv(OUT/'budget_summary.csv',index=False);pd.DataFrame(cal).to_csv(OUT/'scoring_metrics.csv',index=False)
 tests=[paired(full,PROP,c,'fresh16') for c in CONTROL] if 'fresh16' in frames else [];holm(tests)
 pd.DataFrame(tests).to_csv(OUT/'fresh_tests_nine.csv',index=False)
 if component_rows:
  comps=pd.concat(component_rows,ignore_index=True);comps.to_csv(OUT/'ablation_per_pocket.csv',index=False);comps.groupby(['cohort','method','budget'],sort=False).agg(total_C=('C','sum'),mean_C=('C','mean'),recall=('recall','mean'),f1=('f1','mean')).reset_index().to_csv(OUT/'ablation_summary.csv',index=False)
 if seed_rows:
  seeds=pd.concat(seed_rows,ignore_index=True);seeds.groupby(['cohort','seed','budget'],sort=False).agg(total_C=('C','sum'),mean_C=('C','mean'),recall=('recall','mean')).reset_index().to_csv(OUT/'seed_summary.csv',index=False)
 timing=OUT/'repeated_latency.csv'
 if timing.exists():
  t=pd.read_csv(timing);t.groupby('method',sort=False).seconds.agg(['count','mean','median','std','min','max',lambda x:x.quantile(.25),lambda x:x.quantile(.75)]).rename(columns={'<lambda_0>':'q25','<lambda_1>':'q75'}).reset_index().to_csv(OUT/'latency_summary.csv',index=False)
 (OUT/'analysis_receipt.json').write_text(json.dumps(dict(status='PASS',cohorts=list(frames),new_rows=1428 if 'fresh16' in frames else 0,paper=CFG['name'],historical_main_metrics_reproduced=True),ensure_ascii=False,indent=2));print('ANALYSIS_PASS',CFG['name'],list(frames),flush=True)
if __name__=='__main__':main()
