"""Reproduce the proposed ranking from supplied frozen scores and shared labels.

Usage: python replay_saved_scores.py, from this manuscript directory.
Requires NumPy and pandas. Does not train or invoke any chemical verifier.
"""
from pathlib import Path
import json
import numpy as np
import pandas as pd

HERE=Path(__file__).resolve().parent
recipe=json.loads((HERE/'replay/recipe.json').read_text())
metrics=[]
for cohort in ['first48','later23']:
    d=pd.read_csv(HERE/'replay'/f'{cohort}_inputs.csv')
    archived=pd.read_csv(HERE/'replay'/f'{cohort}_selected_candidates.csv')
    per=[]
    for pid,g in d.groupby('pocket_id',sort=False):
        u=sum(weight*g[field].to_numpy() for field,weight in recipe['terms'].items())
        ix=np.lexsort((g.candidate_id.to_numpy(str),-u))
        P=int(g.y.sum())
        for budget in recipe['budgets']:
            sub=g.iloc[ix[:budget]]
            expected=archived[(archived.pocket_id==pid)&(archived.budget==budget)]
            assert set(sub.candidate_id)==set(expected.candidate_id)
            C=int(sub.y.sum())
            assert C==expected.y.sum() and len(sub)==budget
            per.append(dict(pocket_id=pid,budget=budget,C=C,precision=C/budget,recall=C/P if P else np.nan,f1=2*C/(budget+P)))
    per=pd.DataFrame(per)
    for b,g in per.groupby('budget'):
        metrics.append(dict(cohort=cohort,budget=int(b),total_C=int(g.C.sum()),mean_C=float(g.C.mean()),precision=float(g.precision.mean()),macro_recall=float(g.recall.mean()),macro_f1=float(g.f1.mean())))
result=dict(status='PASS',method=recipe['name'],metrics=metrics,model_training=False,chemical_verification=False)
print(json.dumps(result,indent=2))
