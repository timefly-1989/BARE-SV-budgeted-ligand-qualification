#!/usr/bin/env python3
"""Render existing ablation and reliability results at manuscript dimensions.

Reads saved results only. No model fitting, score selection, endpoint acquisition,
new inferential analysis, or modification of experimental CSVs is performed.
"""
from pathlib import Path
import json

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

PROJECT = Path(__file__).resolve().parents[1]
RESULTS = PROJECT / "experiments/04_completion/results"
FIGURES = PROJECT / "figures"
TITLES = {"first48": "Selection: 48 pockets", "later23": "Frozen: 23 pockets", "fresh16": "New: 16 pockets"}
LABELS = {"base17": "Base 17", "minus_extra12": "Without 12 scalars", "minus_svd24": "Without 24 SVD coordinates", "minus_prior2": "Without 2 prior summaries"}
ACCENT = "#176b78"


def style():
    return plt.rc_context({
        "font.family": "DejaVu Sans", "font.size": 7.5,
        "axes.spines.top": False, "axes.spines.right": False,
        "axes.labelsize": 7.5, "axes.titlesize": 8,
        "xtick.labelsize": 7, "ytick.labelsize": 7,
        "pdf.fonttype": 42, "svg.fonttype": "none",
        "savefig.bbox": None, "savefig.facecolor": "white",
    })


def save(fig, name):
    fig.savefig(FIGURES / f"{name}.pdf")
    fig.savefig(FIGURES / f"{name}.png", dpi=300)
    fig.savefig(FIGURES / f"{name}.svg")
    plt.close(fig)


def plot_ablation():
    ab = pd.read_csv(RESULTS / "ablation_per_pocket.csv")
    methods = list(LABELS)
    with style():
        fig, axes = plt.subplots(1, 2, figsize=(160 / 25.4, 76 / 25.4), sharey=True)
        for ax, cohort in zip(axes, ["first48", "fresh16"]):
            p = ab[ab.cohort.eq(cohort) & ab.budget.eq(32)].pivot(index="pocket_id", columns="method", values="C")
            # Preserve the original per-panel seed, method order and resampling.
            rng = np.random.default_rng(20261007)
            rows = []
            for method in methods:
                d = (p["full55"] - p[method]).to_numpy()
                resamples = d[rng.integers(0, len(d), (10000, len(d)))].mean(axis=1)
                low, high = np.quantile(resamples, [0.025, 0.975])
                rows.append((d.mean(), low, high))
            v = np.asarray(rows)
            ax.errorbar(v[:, 0], np.arange(len(methods)), xerr=[v[:, 0] - v[:, 1], v[:, 2] - v[:, 0]],
                        fmt="o", color=ACCENT, ecolor="#607b83", capsize=3, markersize=4)
            ax.axvline(0, color="#8c979c", linewidth=0.8, linestyle="--")
            ax.set_title(TITLES[cohort], fontweight="bold", pad=10)
            ax.set_xlabel("Full 55 minus reduced policy\n(mean recovery per pocket, B = 32)", labelpad=8)
            ax.grid(axis="x", color="#e5e8eb", linewidth=0.5)
        axes[0].set_yticks(range(len(methods)), [LABELS[m] for m in methods])
        axes[0].invert_yaxis()
        axes[0].set_ylim(3.5, -0.5)
        fig.subplots_adjust(left=0.27, right=0.98, top=0.84, bottom=0.27, wspace=0.30)
        save(fig, "completion_ablation_differences")


def plot_reliability():
    with style():
        fig, axes = plt.subplots(2, 3, figsize=(160 / 25.4, 96 / 25.4),
                                 gridspec_kw={"height_ratios": [2.0, 1.0]}, sharex=True)
        for col, cohort in enumerate(TITLES):
            data = pd.read_csv(RESULTS / f"{cohort}_reliability.csv").set_index("bin")
            ax, counts = axes[:, col]
            ax.plot([0, 1], [0, 1], linestyle="--", color="#8c979c", linewidth=0.8)
            ax.scatter(data.mean_score, data.observed_rate, s=22, color=ACCENT, zorder=3)
            ax.set(xlim=(0, 1), ylim=(-0.025, 1.025), yticks=[0, 0.5, 1])
            ax.set_title(TITLES[cohort], fontweight="bold", pad=9)
            ax.tick_params(labelbottom=False)
            n = data["count"].reindex(range(10), fill_value=0).to_numpy()
            centers = (np.arange(10) + 0.5) / 10
            counts.bar(centers[n > 0], n[n > 0], width=0.075, color=ACCENT, alpha=0.85)
            counts.set_yscale("log")
            counts.set_ylim(0.6, 14000)
            counts.set_yticks([1, 100, 10000], ["1", "100", "10,000"])
            counts.set_xticks([0, 0.5, 1])
            counts.set_xlabel("Joint utility bin", labelpad=5)
            for center, value in zip(centers, n):
                counts.text(center, max(value, 0.72) * 1.35, str(int(value)),
                            ha="center", va="bottom", fontsize=6.8, color="#273942")
            if col:
                ax.tick_params(labelleft=False)
                counts.tick_params(labelleft=False)
        axes[0, 0].set_ylabel("Observed joint fraction")
        axes[1, 0].set_ylabel("Candidates (log scale)")
        fig.subplots_adjust(left=0.105, right=0.985, bottom=0.14, top=0.88, hspace=0.23, wspace=0.15)
        save(fig, "completion_reliability")


def write_ablation_table():
    summary = pd.read_csv(RESULTS / "ablation_summary.csv")
    raw = pd.read_csv(RESULTS / "ablation_per_pocket.csv")
    labels = {"full55": "Full 55", **LABELS}
    rows = []
    for method, label in labels.items():
        counts = [int(summary[summary.cohort.eq(c) & summary.method.eq(method) & summary.budget.eq(32)].total_C.iloc[0]) for c in TITLES]
        p = raw[raw.cohort.eq("fresh16") & raw.method.eq(method) & raw.budget.eq(32) & raw.pool_positives.gt(0)]
        recall = p.recall.mean()
        hits = int(p.C.gt(0).sum())
        rows.append(f"{label} & {counts[0]} & {counts[1]} & {counts[2]} & {recall:.4f} & {hits}/{len(p)}" + r"\\")
    text = "\n".join([
        r"\par", r"\begin{table}[htbp]\centering\small",
        r"\setlength{\tabcolsep}{3.5pt}",
        r"\caption{Fixed-context group removals at budget 32, with new-cohort pocket-level diagnostics.}\label{tab:completion_ablation}",
        r"\begin{tabularx}{\linewidth}{Yrrrrr}", r"\toprule",
        r"Representation & 48: total & 23: total & 16: total & 16: recall & 16: coverage\\", r"\midrule",
        *rows, r"\bottomrule\end{tabularx}",
        r"\par\medskip\begin{minipage}{.98\linewidth}\footnotesize Totals count recovered positives over all pockets. Recall averages the eight positive pockets in the new cohort. Coverage counts positive pockets with at least one recovery. The backbone and labelled development examples are fixed. Historical columns are outcome-exposed diagnostics; new-cohort predictions were frozen before qualification. Pocket-level descriptors supplement the unchanged primary recovery endpoint.\end{minipage}",
        r"\end{table}", r"\par", "",
    ])
    (PROJECT / "tables/completion_ablation.tex").write_text(text)


def main():
    plot_ablation()
    plot_reliability()
    write_ablation_table()
    print(json.dumps({"status": "PASS", "sources": "unchanged saved results", "new_models_or_endpoints": False}))


if __name__ == "__main__":
    main()
