"""Export the manuscript's numerical analysis from its own archived records."""
from pathlib import Path
import json
import pandas as pd
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'results';OUT.mkdir(exist_ok=True)
d=pd.read_csv(ROOT/'evidence/per_pocket_metrics.csv')
summary=d.groupby(['cohort','method','budget'],sort=False).agg(total_C=('C','sum'),mean_C=('C','mean'),precision=('precision','mean'),macro_recall=('recall','mean'),macro_f1=('f1','mean')).reset_index()
summary.to_csv(OUT/'metrics_summary.csv',index=False)
summary[summary.budget.eq(32)].to_csv(OUT/'main_budget_comparison.csv',index=False)
for filename in ['paired_tests.csv','ablation_metrics.csv','cost_metrics.csv','two_component_variants.csv']:
    p=ROOT/'evidence'/filename
    if p.exists():pd.read_csv(p).to_csv(OUT/filename,index=False)
print(json.dumps(dict(status='PASS',summary_rows=len(summary),inputs='Project-local recorded scores and metrics',model_training=False,chemical_verification=False)))
