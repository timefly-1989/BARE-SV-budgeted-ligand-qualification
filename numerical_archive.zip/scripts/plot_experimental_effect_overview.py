#!/usr/bin/env python3
"""Plot a descriptive, data-backed overview of the main-budget effects."""

from __future__ import annotations

import argparse
from pathlib import Path

import matplotlib as mpl
import matplotlib.pyplot as plt
import pandas as pd


ROOT = Path(__file__).resolve().parents[1]
ABLATION = ROOT / "experiments/04_completion/results/ablation_summary.csv"
BUDGET = ROOT / "experiments/04_completion/results/budget_summary.csv"
COHORT = ROOT / "experiments/04_completion/results/cohort_audit.csv"

COHORTS = ["first48", "later23", "fresh16"]
METHODS = [
    "full55",
    "base17",
    "minus_extra12",
    "minus_svd24",
    "minus_prior2",
    "budget_ramp",
]

EXPECTED = {
    ("first48", "full55"): 128,
    ("first48", "base17"): 125,
    ("first48", "minus_extra12"): 128,
    ("first48", "minus_svd24"): 127,
    ("first48", "minus_prior2"): 128,
    ("first48", "budget_ramp"): 127,
    ("later23", "full55"): 36,
    ("later23", "base17"): 36,
    ("later23", "minus_extra12"): 36,
    ("later23", "minus_svd24"): 35,
    ("later23", "minus_prior2"): 36,
    ("later23", "budget_ramp"): 36,
    ("fresh16", "full55"): 60,
    ("fresh16", "base17"): 61,
    ("fresh16", "minus_extra12"): 61,
    ("fresh16", "minus_svd24"): 59,
    ("fresh16", "minus_prior2"): 59,
    ("fresh16", "budget_ramp"): 63,
}

COLORS = {
    "full55": "#0B5D6E",
    "base17": "#667085",
    "minus_extra12": "#2E8B8B",
    "minus_svd24": "#526477",
    "minus_prior2": "#705A80",
    "budget_ramp": "#D97706",
}

MARKERS = {
    "full55": "D",
    "base17": "o",
    "minus_extra12": "o",
    "minus_svd24": "o",
    "minus_prior2": "o",
    "budget_ramp": "s",
}


TEXT = {
    "en": {
        "methods": {
            "full55": "Full 55 (proposed)",
            "base17": "Base 17",
            "minus_extra12": "43 inputs: no added scalars",
            "minus_svd24": "31 inputs: no SVD coordinates",
            "minus_prior2": "53 inputs: no prior summaries",
            "budget_ramp": "Budget-ramp control",
        },
        "titles": {
            "first48": "A  Selection\n48 pockets\n133 positives",
            "later23": "B  Frozen follow-up\n23 pockets\n36 positives",
            "fresh16": "C  Chemical block\n16 pockets\n72 positives",
        },
        "callouts": {
            "first48": "Full 55 vs base 17:  +3",
            "later23": "Observed ceiling:  36/36",
            "fresh16": "Full 55 vs base:  −1   ·   vs control:  −3",
        },
        "xlabel": "Observed joint positives recovered at budget 32 (%)",
        "foot": "Labels give recovered/available positives. Percentages are descriptive cohort totals, not macro recall. The 23-pocket endpoint is saturated; no contrast is statistically confirmed after the stated correction.",
    },
    "zh": {
        "methods": {
            "full55": "完整55维（本文方法）",
            "base17": "基础17维",
            "minus_extra12": "43维：移除12个标量",
            "minus_svd24": "31维：移除24个SVD坐标",
            "minus_prior2": "53维：移除2个先验",
            "budget_ramp": "预算斜坡对照",
        },
        "titles": {
            "first48": "A  选择验证\n48个口袋 · 133个阳性",
            "later23": "B  冻结后续队列\n23个口袋 · 36个阳性",
            "fresh16": "C  新化学隔离队列\n16个口袋 · 72个阳性",
        },
        "callouts": {
            "first48": "完整55维相对基础17维：+3",
            "later23": "观测上限：36/36",
            "fresh16": "完整55维相对基础：−1；相对对照：−3",
        },
        "xlabel": "预算32下找回的联合阳性（占该队列全部已观测阳性的百分比）",
        "foot": "标注为找回数/可用阳性总数。百分比是描述性的队列总数，并非宏平均召回率。23口袋终点已饱和；按文中校正规则，尚无比较获得统计学确认。",
    },
}


def load_data() -> pd.DataFrame:
    ab = pd.read_csv(ABLATION)
    ab = ab[(ab["budget"] == 32) & ab["cohort"].isin(COHORTS)].copy()
    ab = ab[ab["method"].isin(METHODS[:-1])][["cohort", "method", "total_C"]]

    bu = pd.read_csv(BUDGET)
    bu = bu[
        (bu["budget"] == 32)
        & bu["cohort"].isin(COHORTS)
        & (bu["method"] == "Budget-ramp ranker")
    ][["cohort", "total_C"]].copy()
    bu["method"] = "budget_ramp"

    co = pd.read_csv(COHORT).set_index("cohort")
    frame = pd.concat([ab, bu], ignore_index=True)
    frame["recovered"] = frame["total_C"].round().astype(int)
    frame["positives"] = frame["cohort"].map(co["positives"]).astype(int)
    frame["percent"] = 100.0 * frame["recovered"] / frame["positives"]
    frame = frame.drop(columns="total_C")

    got = {(r.cohort, r.method): int(r.recovered) for r in frame.itertuples()}
    if got != EXPECTED:
        missing = sorted(set(EXPECTED) - set(got))
        extra = sorted(set(got) - set(EXPECTED))
        wrong = {k: (EXPECTED[k], got.get(k)) for k in EXPECTED if got.get(k) != EXPECTED[k]}
        raise RuntimeError(f"Unexpected plotting data; missing={missing}, extra={extra}, wrong={wrong}")

    frame["source"] = frame["method"].map(
        lambda m: str(ABLATION.relative_to(ROOT)) if m != "budget_ramp" else str(BUDGET.relative_to(ROOT))
    )
    return frame.sort_values(
        ["cohort", "method"],
        key=lambda s: s.map({**{v: i for i, v in enumerate(COHORTS)}, **{v: i for i, v in enumerate(METHODS)}}),
    )


def configure(lang: str) -> None:
    mpl.rcParams.update(
        {
            "font.family": "sans-serif",
            "font.sans-serif": (
                ["Heiti SC", "Noto Sans CJK SC", "Arial Unicode MS", "DejaVu Sans"]
                if lang == "zh"
                else ["DejaVu Sans"]
            ),
            "font.size": 7.5,
            "axes.titlesize": 8,
            "axes.labelsize": 7.5,
            "xtick.labelsize": 7,
            "ytick.labelsize": 7.2,
            "pdf.fonttype": 42,
            "ps.fonttype": 42,
            "svg.fonttype": "none",
            "savefig.bbox": None,
            "savefig.facecolor": "white",
            "axes.unicode_minus": False,
        }
    )


def plot(frame: pd.DataFrame, output: Path, lang: str) -> None:
    configure(lang)
    t = TEXT[lang]
    y = list(range(len(METHODS)))
    # Design at the manuscript's 160 mm width; captions carry scope notes.
    fig, axes = plt.subplots(1, 3, figsize=(160 / 25.4, 80 / 25.4), sharex=True, sharey=True)

    for idx, (ax, cohort) in enumerate(zip(axes, COHORTS)):
        part = frame[frame["cohort"] == cohort].set_index("method").loc[METHODS]
        for yi, method in zip(y, METHODS):
            pct = float(part.loc[method, "percent"])
            recovered = int(part.loc[method, "recovered"])
            positives = int(part.loc[method, "positives"])
            ax.hlines(yi, 78, 102, color="#E6EAEE", linewidth=0.7, zorder=1)
            edge = "white" if method in {"full55", "budget_ramp"} else COLORS[method]
            size = 30 if method == "full55" else 22
            ax.scatter(
                pct,
                yi,
                s=size,
                marker=MARKERS[method],
                color=COLORS[method],
                edgecolor=edge,
                linewidth=0.8,
                zorder=3,
            )
            label = f"{recovered}/{positives}"
            if pct >= 98.6:
                ax.annotate(label, (pct, yi), xytext=(-5, 0), textcoords="offset points", ha="right", va="center", fontsize=7)
            else:
                ax.annotate(label, (pct, yi), xytext=(5, 0), textcoords="offset points", ha="left", va="center", fontsize=7)

        ax.set_title(t["titles"][cohort], loc="left", fontweight="bold", pad=10)
        ax.set_xlim(78, 102)
        ax.set_xticks([80, 90, 100])
        ax.grid(axis="x", color="#D8DEE4", linewidth=0.7, linestyle=(0, (2, 3)))
        ax.axvline(100, color="#8A949E", linewidth=0.9, linestyle=(0, (4, 3)), zorder=0)
        ax.set_axisbelow(True)
        ax.tick_params(axis="y", length=0, pad=6)
        ax.tick_params(axis="x", length=3, color="#667085")
        for spine in ["top", "right", "left"]:
            ax.spines[spine].set_visible(False)
        ax.spines["bottom"].set_color("#667085")
        if idx > 0:
            ax.tick_params(labelleft=False)

    axes[0].set_yticks(y)
    axes[0].set_yticklabels([t["methods"][m] for m in METHODS])
    axes[0].invert_yaxis()
    for tick, method in zip(axes[0].get_yticklabels(), METHODS):
        tick.set_color("#344054")
        if method in {"full55", "budget_ramp"}:
            tick.set_fontweight("bold")

    fig.supxlabel(t["xlabel"], y=0.035, fontsize=7.5, color="#1F2937")
    fig.subplots_adjust(left=0.295 if lang == "en" else 0.29, right=0.98, top=0.79, bottom=0.17, wspace=0.14)

    output.parent.mkdir(parents=True, exist_ok=True)
    frame.to_csv(output.parent / "experimental_effect_overview_data.csv", index=False)
    fig.savefig(output.with_suffix(".pdf"), metadata={"Title": "Main-budget experimental effect overview"})
    fig.savefig(output.with_suffix(".png"), dpi=300)
    fig.savefig(output.with_suffix(".svg"))
    plt.close(fig)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--lang", choices=["en", "zh"], required=True)
    parser.add_argument("--output", type=Path, required=True, help="Output path without extension")
    args = parser.parse_args()
    plot(load_data(), args.output, args.lang)


if __name__ == "__main__":
    main()
