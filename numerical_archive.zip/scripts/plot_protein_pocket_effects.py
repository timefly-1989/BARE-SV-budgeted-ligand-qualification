#!/usr/bin/env python3
"""Replay recorded ranks and compose a protein-pocket experimental results figure."""
from pathlib import Path
import hashlib
import importlib.metadata
import json

import matplotlib as mpl
mpl.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap
from matplotlib.patches import Rectangle
import numpy as np
import pandas as pd
from PIL import Image
from rdkit import Chem

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "figures/protein_pocket_effects"
BUDGET = 32
METHODS = ["full55", "base17", "minus_extra12", "budget_ramp"]
LABELS = ["Full 55 (proposed)", "Base 17", "43: no added scalars", "Budget-ramp control"]
EXPECTED = [60, 61, 61, 63]
TEAL, GRAY, PURPLE = "#0B5D6E", "#697586", "#753BA3"
CASES = [("5t2p__1__1.A__1.G", "c077", "HBV core protein", "Recovery gain"),
         ("3lu6__1__1.A__1.D", "c084", "Human serum albumin", "Missed positive"),
         ("7vjt__1__1.A__1.C", "c015", "Pks13 thioesterase", "Missed positive")]


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def replay():
    inputs = [ROOT / "experiments/05_fresh16/data/outcomes.csv",
              ROOT / "experiments/04_completion/data/fresh16_ablation_predictions.csv",
              ROOT / "experiments/05_fresh16/data/baseline_policy_scores.csv"]
    outcomes, scores, controls = [pd.read_csv(p) for p in inputs]
    keys = ["pocket_id", "candidate_id"]
    assert not any(d.duplicated(keys).any() for d in [outcomes, scores, controls])
    data = outcomes.merge(scores, on=keys, validate="one_to_one").merge(
        controls[keys + ["Budget-ramp ranker"]], on=keys, validate="one_to_one")
    assert len(data) == len(outcomes) == len(scores) == len(controls) == 1428
    assert (data.y == ((data.D == 1) & (data.V == 1) & (data.Q == 1)).astype(int)).all()
    data["budget_ramp"] = data["Budget-ramp ranker"]
    ranks, metrics = [], []
    for pid, pocket in data.groupby("pocket_id", sort=True):
        available = int(pocket.y.sum())
        for method in METHODS:
            ordered = pocket.sort_values([method, "candidate_id"], ascending=[False, True]).copy()
            ordered["rank"] = np.arange(1, len(ordered) + 1)
            ranks.extend({"pocket_id": pid, "candidate_id": row.candidate_id, "method": method,
                          "rank": int(row.rank), "y": int(row.y)}
                         for row in ordered.itertuples())
            recovered = int(ordered.head(BUDGET).y.sum())
            metrics.append({"pocket_id": pid, "pdb_id": pid[:4].upper(), "method": method,
                            "budget": BUDGET, "pool_size": len(pocket), "positives": available,
                            "recovered": recovered, "recall": recovered / available if available else np.nan})
    ranks, metrics = pd.DataFrame(ranks), pd.DataFrame(metrics)
    assert metrics.groupby("method").recovered.sum().reindex(METHODS).tolist() == EXPECTED
    assert outcomes.y.sum() == 72 and outcomes.pocket_id.nunique() == 16
    # Check replayed pocket counts against the existing immutable analysis tables.
    for file, methods in [("ablation_per_pocket.csv", METHODS[:3]),
                          ("all_budget_per_pocket.csv", ["budget_ramp"])]:
        stored = pd.read_csv(ROOT / "experiments/04_completion/results" / file)
        stored = stored[(stored.cohort == "fresh16") & (stored.budget == BUDGET)]
        for method in methods:
            label = "Budget-ramp ranker" if method == "budget_ramp" else method
            a = metrics[metrics.method == method].set_index("pocket_id").recovered.sort_index()
            b = stored[stored.method == label].set_index("pocket_id").C.sort_index()
            assert np.array_equal(a.values, b.values) and a.index.equals(b.index)
    deltas = metrics.pivot(index="pocket_id", columns="method", values="recovered")
    assert (deltas.full55 - deltas.base17).idxmax() == CASES[0][0]
    zeros = metrics[(metrics.method == "full55") & (metrics.positives == 1) & (metrics.recovered == 0)]
    assert set(zeros.pocket_id) == {c[0] for c in CASES[1:]}
    gain_pid, gain_cid = CASES[0][:2]
    rp = ranks[(ranks.pocket_id == gain_pid) & (ranks.y == 1)].pivot(index="candidate_id", columns="method", values="rank")
    eligible = rp[(rp.full55 <= BUDGET) & (rp.base17 > BUDGET)].sort_values(["full55"])
    assert eligible.index[0] == gain_cid
    return inputs, data, ranks, metrics


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    inputs, data, ranks, metrics = replay()
    metrics.to_csv(OUT / "per_pocket_recovery.csv", index=False)
    ranks.to_csv(OUT / "candidate_ranks.csv", index=False)
    cases = []
    for pid, cid, protein, reason in CASES:
        record = data[(data.pocket_id == pid) & (data.candidate_id == cid)].iloc[0]
        assert int(record.y) == 1
        rec = ROOT / "experiments/05_fresh16/chemistry/records" / pid / cid
        pool = ROOT / "experiments/05_fresh16/chemistry/pools" / pid
        docking = json.loads((rec / "docking.json").read_text())
        assert docking["V"] == docking["Q"] == docking["graph_preserved"] == 1
        assert np.isclose(docking["redocked_score"], record.redocked_score)
        # Audit coordinates and pose input identity; do not infer binding contacts.
        mol = Chem.SDMolSupplier(str(rec / "redocked.sdf"), removeHs=True)[0]
        native = Chem.SDMolSupplier(str(pool / "reference.sdf"), removeHs=True)[0]
        assert mol is not None and native is not None
        protein_coords = np.array([[float(line[30:38]), float(line[38:46]), float(line[46:54])]
                                  for line in (pool / "protein.pdb").read_text().splitlines()
                                  if line.startswith("ATOM  ") and line[76:78].strip() != "H"])
        xyz = np.array(mol.GetConformer().GetPositions())
        nearest = np.sqrt(((xyz[:, None] - protein_coords[None]) ** 2).sum(axis=2)).min()
        assert np.isfinite(xyz).all() and 0.8 < nearest < 5.0
        case_ranks = ranks[(ranks.pocket_id == pid) & (ranks.candidate_id == cid)].set_index("method")["rank"].to_dict()
        count = metrics[metrics.pocket_id == pid].set_index("method")
        assert (case_ranks["full55"] <= BUDGET) == (pid == CASES[0][0])
        assert (case_ranks["base17"] <= BUDGET) == (pid != CASES[0][0])
        cases.append({"pocket_id": pid, "pdb_id": pid[:4].upper(), "candidate_id": cid,
                      "protein": protein, "selection_reason": reason, "y": 1,
                      "D": 1, "V": 1, "Q": 1, "ranks": case_ranks,
                      "pool_size": int(count.pool_size.iloc[0]), "positives": int(count.positives.iloc[0]),
                      "recovered": count.recovered.to_dict(), "redocked_score": float(record.redocked_score),
                      "minimum_ligand_protein_heavy_atom_distance_A": float(nearest),
                      "source_sha256": {str(p.relative_to(ROOT)): sha(p) for p in
                                        [pool / "protein.pdb", pool / "reference.sdf", rec / "redocked.sdf", rec / "docking.json"]},
                      "identity_source": f"https://www.rcsb.org/structure/{pid[:4].upper()}"})
    mpl.rcParams.update({"font.family": "DejaVu Sans", "font.size": 8,
                         "pdf.fonttype": 42, "ps.fonttype": 42, "svg.fonttype": "none",
                         "axes.linewidth": .6, "savefig.facecolor": "white"})
    fig = plt.figure(figsize=(160 / 25.4, 142 / 25.4))
    fig.text(.025, .972, "A", fontsize=11, weight="bold")
    fig.text(.068, .972, "Recovery across all 16 prospective pockets (B = 32)", fontsize=9, weight="bold")
    avail = metrics[metrics.method == "full55"].set_index("pocket_id").positives
    pids = sorted(avail[avail > 0].index) + sorted(avail[avail == 0].index)
    counts = metrics.pivot(index="method", columns="pocket_id", values="recovered").loc[METHODS, pids]
    recalls = metrics.pivot(index="method", columns="pocket_id", values="recall").loc[METHODS, pids]
    cmap = LinearSegmentedColormap.from_list("recall_teal", ["#F5F8FA", "#72B5BC", "#0B5D6E"])
    cmap.set_bad("#E9ECF0")
    ax = fig.add_axes([.236, .733, .671, .174])
    im = mpl.cm.ScalarMappable(norm=mpl.colors.Normalize(0, 1), cmap=cmap)
    for i in range(4):
        for j in range(16):
            value = recalls.iloc[i, j]
            ax.add_patch(Rectangle((j - .5, i - .5), 1, 1,
                                   facecolor=cmap(np.ma.masked if np.isnan(value) else value),
                                   edgecolor="white", linewidth=1))
    ax.set_xlim(-.5, 15.5)
    ax.set_ylim(3.5, -.5)
    ax.set_yticks(range(4), LABELS, fontsize=7.4)
    ax.tick_params(length=0, pad=3)
    ax.set_xticks(range(16), [p[:4].upper() for p in pids], rotation=90, fontsize=7)
    for spine in ax.spines.values():
        spine.set_visible(False)
    for j, pid in enumerate(pids):
        for i, method in enumerate(METHODS):
            value = recalls.loc[method, pid]
            ax.text(j, i, f"{counts.loc[method, pid]}/{avail[pid]}", ha="center", va="center",
                    fontsize=6.3, color="white" if value >= .7 else "#263442")
    ax.axvline(7.5, color="white", lw=2.5)
    fig.text(.404, .925, "8 positive pockets", ha="center", fontsize=7.5, color=TEAL)
    fig.text(.739, .925, "8 zero-positive pockets", ha="center", fontsize=7.5, color=GRAY)
    for i, total in enumerate(EXPECTED):
        fig.text(.963, .907 - .174 * (i + .5) / 4, f"{total}/72", ha="center", va="center", fontsize=7.3)
    fig.text(.963, .925, "Total", ha="center", fontsize=7.2)
    cax = fig.add_axes([.27, .642, .20, .010])
    cb = fig.colorbar(im, cax=cax, orientation="horizontal", ticks=[0, .5, 1])
    cb.ax.tick_params(labelsize=6.5, length=2, pad=2)
    cb.outline.set_visible(False)
    fig.text(.025, .645, "Pocket recall", fontsize=7.3)
    fig.text(.515, .644, "Cells: recovered/available; gray 0/0 = undefined recall", fontsize=6.8, color=GRAY)
    for i, case in enumerate(cases):
        left = .025 + i * .329
        fig.text(left, .574, chr(66 + i), fontsize=11, weight="bold")
        fig.text(left + .039, .578, f"{case['pdb_id']}  |  {case['selection_reason']}", fontsize=7.7, weight="bold")
        fig.text(left + .039, .552, case["protein"], fontsize=7.4, color=GRAY)
        image_ax = fig.add_axes([left, .242, .31, .303])
        image_ax.imshow(Image.open(OUT / f"{case['pdb_id'].lower()}_{case['candidate_id']}_pocket.png"))
        image_ax.axis("off")
        fig.text(left + .155, .228, f"{case['candidate_id']}  |  D = V = Q = 1", fontsize=7.5,
                 ha="center", color=PURPLE)
        rank_ax = fig.add_axes([left + .041, .100, .254, .075])
        rank_ax.axvspan(.5, 32.5, color="#E8F1F3", zorder=0)
        rank_ax.axvline(32.5, color=TEAL, linewidth=.8, linestyle="--")
        for y, method, color in [(1, "full55", TEAL), (0, "base17", GRAY)]:
            r = case["ranks"][method]
            rank_ax.scatter(r, y, color=color, s=17, zorder=3)
            rank_ax.text(r + 3, y, str(r), va="center", color=color, fontsize=7.2)
        rank_ax.set_xlim(.5, 104)
        rank_ax.set_ylim(-.5, 1.5)
        rank_ax.set_yticks([1, 0], ["Full", "Base"], fontsize=6.8)
        rank_ax.set_xticks([1, 32, 100], ["1", "32", "100"], fontsize=6.5)
        rank_ax.tick_params(axis="y", length=0, pad=3)
        rank_ax.tick_params(axis="x", length=2, pad=1)
        for name in ["top", "left", "right"]:
            rank_ax.spines[name].set_visible(False)
        rank_ax.spines["bottom"].set_color("#B8C0CB")
        fig.text(left + .156, .065, "Candidate rank (shaded: selected)", ha="center", fontsize=6.7)
        n = case["positives"]
        fig.text(left + .156, .191,
                 f"Pocket recovery: full {case['recovered']['full55']}/{n}; base {case['recovered']['base17']}/{n}",
                 fontsize=7.3, ha="center")
    fig.text(.025, .026, "Teal/gray: archived protein pocket. Purple: qualified candidate. Gray sticks: native reference.", fontsize=6.7, color=GRAY)
    fig.text(.025, .007, "Shared verifier poses illustrate ranking differences; computational qualification does not establish biological activity.", fontsize=6.5, color=GRAY)
    for suffix in ["pdf", "svg", "png"]:
        fig.savefig(OUT / f"protein_pocket_effects.{suffix}", dpi=600)
    plt.close(fig)
    manifest = {"status": "PASS", "budget": BUDGET, "cohort": "fresh16", "candidates": 1428,
                "pockets": 16, "joint_positives": 72, "total_recovered": dict(zip(METHODS, EXPECTED)),
                "macro_recall_positive_pockets": metrics.groupby("method").recall.mean().to_dict(),
                "selection_rule": "Post hoc diagnostic illustrations: pocket with largest full-minus-base recovery gain; lowest full rank among its full-only qualified candidates; both single-positive pockets missed by full and recovered by base.",
                "scope": "Computational qualification and selection, not measured binding or biological activity",
                "ranking_rule": "descending saved score, ascending candidate_id; same candidate pools and B=32",
                "case_selection_used_to_change_predictions": False, "cases": cases,
                "input_sha256": {str(p.relative_to(ROOT)): sha(p) for p in inputs},
                "script_sha256": {str(p.relative_to(ROOT)): sha(p) for p in
                                  [Path(__file__), ROOT / "scripts/render_protein_pocket_cases.py"]},
                "figure_size_mm": [160, 142],
                "python_packages": {x: importlib.metadata.version(x) for x in
                                    ["numpy", "pandas", "matplotlib", "Pillow", "rdkit"]},
                "render_manifest_sha256": sha(OUT / "render_manifest.json"),
                "identity_sources_sha256": {str(p.relative_to(ROOT)): sha(p) for p in
                                            (OUT / "identity_sources").iterdir() if p.is_file()}}
    (OUT / "figure_manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
    print(json.dumps({"status": "PASS", "totals": EXPECTED,
                      "case_ranks": [{"pdb": c["pdb_id"], "ranks": c["ranks"]} for c in cases]}))


if __name__ == "__main__":
    main()
