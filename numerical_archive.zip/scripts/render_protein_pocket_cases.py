"""Render archived verifier coordinates: pymol -cq scripts/render_protein_pocket_cases.py.

No docking, structural alignment, coordinate adjustment or contact inference is run.
"""
from pathlib import Path
import hashlib
import json
from pymol import cmd

ROOT = Path.cwd()
assert (ROOT / "manuscript.tex").is_file(), "Run from the manuscript project directory"
OUT = ROOT / "figures/protein_pocket_effects"
OUT.mkdir(parents=True, exist_ok=True)
CASES = [("5t2p__1__1.A__1.G", "c077"),
         ("3lu6__1__1.A__1.D", "c084"),
         ("7vjt__1__1.A__1.C", "c015")]


def main():
    manifest = {"renderer": "Open-source PyMOL", "version": list(cmd.get_version()),
                "coordinate_operations": "none; display camera only",
                "protein_scope": "archived cropped verifier pocket, not whole protein",
                "ligand_scope": "archived candidate redocking and released native reference",
                "representations": "protein surface and backbone cartoon; ligand heavy-atom sticks",
                "surface_transparency": 0.68, "render_size_px": [2100, 1650],
                "cases": []}
    for pid, cid in CASES:
        cmd.reinitialize()
        cmd.bg_color("white")
        for name, value in [("orthoscopic", 1), ("antialias", 2), ("ray_shadows", 0),
                            ("ambient", .5), ("direct", .7), ("specular", .15),
                            ("shininess", 20), ("depth_cue", 0), ("ray_trace_mode", 0),
                            ("two_sided_lighting", 1), ("cartoon_fancy_helices", 1),
                            ("cartoon_flat_sheets", 1), ("stick_radius", .20),
                            ("ray_opaque_background", 0), ("opaque_background", 0)]:
            cmd.set(name, value)
        cmd.set_color("pocket_teal", [.12, .42, .46])
        cmd.set_color("pocket_surface", [.78, .84, .85])
        cmd.set_color("candidate_purple", [.46, .23, .64])
        cmd.set_color("native_gray", [.48, .51, .55])
        pool = ROOT / "experiments/05_fresh16/chemistry/pools" / pid
        rec = ROOT / "experiments/05_fresh16/chemistry/records" / pid / cid
        sources = {"protein": pool / "protein.pdb", "native": pool / "reference.sdf",
                   "candidate": rec / "redocked.sdf"}
        for obj, path in sources.items():
            cmd.load(str(path), obj)
        cmd.hide("everything", "all")
        cmd.remove("hydro")
        cmd.show("surface", "protein")
        cmd.show("cartoon", "protein")
        cmd.color("pocket_teal", "protein")
        cmd.set("surface_color", "pocket_surface", "protein")
        cmd.set("transparency", .68, "protein")
        for obj, color, radius in [("native", "native_gray", .12),
                                   ("candidate", "candidate_purple", .22)]:
            cmd.show("sticks", obj)
            cmd.color(color, obj)
            cmd.set("stick_radius", radius, obj)
        cmd.orient("native or candidate")
        cmd.turn("y", 22)
        cmd.turn("x", -18)
        cmd.zoom("all", 1.5)
        # Keep the complete archived local receptor in view, in the shared coordinate frame.
        cmd.clip("slab", 80)
        code = pid[:4]
        cmd.png(str(OUT / f"{code}_{cid}_pocket.png"), width=2100, height=1650,
                dpi=600, ray=1, quiet=1)
        cmd.save(str(OUT / f"{code}_{cid}_pocket.pse"))
        manifest["cases"].append({"pocket_id": pid, "candidate_id": cid,
                                  "camera_view": list(cmd.get_view()),
                                  "source_sha256": {str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest()
                                                    for p in sources.values()}})
    (OUT / "render_manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
    cmd.quit()


main()
