"""Check this manuscript project using local files only."""
from pathlib import Path
import hashlib,json,re,subprocess,sys
import numpy as np
import pandas as pd
ROOT=Path(__file__).resolve().parents[1]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
checks=[]
def check(name,ok):
    if not ok:raise AssertionError(name)
    checks.append(name)
cfg=json.loads((ROOT/'project.json').read_text())
manifest=json.loads((ROOT/'evidence/project_input_manifest.json').read_text())
for rel,h in manifest['files'].items():check('input hash '+rel,sha(ROOT/rel)==h)
s=(ROOT/cfg['manuscript']).read_text()
for path in re.findall(r'\\(?:input|includegraphics)(?:\[[^]]*\])?\{([^}]+)\}',s):
    p=ROOT/path
    check('local manuscript asset '+path,p.exists() and p.resolve().is_relative_to(ROOT.resolve()))
expanded=re.sub(r'\\input\{([^}]+)\}',lambda m:(ROOT/m[1]).read_text(),s)
labels=re.findall(r'\\label\{([^}]+)\}',expanded)
check('unique labels',len(labels)==len(set(labels)))
refs=set(re.findall(r'\\(?:ref|eqref)\{([^}]+)\}',expanded))
check('resolved source references',refs.issubset(set(labels)))
bib=set(re.findall(r'@\w+\{([^,]+),',(ROOT/'references.bib').read_text()))
cites=set(k for m in re.findall(r'\\cite\w*\{([^}]+)\}',expanded) for k in m.split(','))
check('all citations local',cites.issubset(bib))
check('no unfinished source tokens','@@' not in expanded)
r=subprocess.run([sys.executable,str(ROOT/'replay_saved_scores.py')],capture_output=True,text=True,check=True)
a=json.loads(r.stdout);check('selected candidate replay',a['status']=='PASS')
for cohort,total in cfg['main_totals'].items():
    m=[x for x in a['metrics'] if x['cohort']==cohort and x['budget']==32][0]
    check(cohort+' main total',m['total_C']==total)
    d=pd.read_csv(ROOT/'evidence/per_pocket_metrics.csv')
    d=d[(d.cohort==cohort)&(d.method==cfg['method_display'])&(d.budget==32)]
    for col,key in [('C','mean_C'),('precision','precision'),('recall','macro_recall'),('f1','macro_f1')]:
        check(cohort+' '+col,np.isclose(d[col].mean(),m[key],atol=1e-12))
check('final PDF retained',sha(ROOT/cfg['final_pdf'])==manifest['final_pdf_sha256'])
result=dict(status='PASS',project=cfg['name'],checks=len(checks),items=checks,all_runtime_inputs_local=True,experiments_started=False)
(ROOT/'evidence/standalone_validation.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
print(json.dumps(dict(status=result['status'],project=result['project'],checks=result['checks'],all_runtime_inputs_local=True),ensure_ascii=False))
